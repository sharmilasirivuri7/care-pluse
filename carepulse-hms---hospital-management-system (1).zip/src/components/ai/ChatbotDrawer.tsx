import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Trash2,
  Sparkles,
  Bot,
  User,
  ArrowRight,
  ShieldAlert,
  Languages,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useHospital } from '../../context/HospitalContext';
import { useTranslation } from '../../i18n/translations';
import { ChatMessage, Language } from '../../types';
import {
  processHospitalQuery,
  speakText,
  stopSpeaking,
} from '../../services/aiVoiceAndChatService';

export const ChatbotDrawer: React.FC = () => {
  const {
    language,
    setLanguage,
    patients,
    doctors,
    appointments,
    beds,
    invoices,
    medicines,
    labTests,
    deletePatient,
    cancelAppointment,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();

  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState(true);
  const [isListening, setIsListening] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Initial welcome message
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text:
        language === 'te'
          ? 'నమస్కారం! నేను మెడికవర్ AI మెడికల్ అసిస్టెంట్‌ని. అపాయింట్‌మెంట్లు, ఖాళీ బెడ్లు, పేషెంట్లు, ల్యాబ్ లేదా బిల్లింగ్ గురించి ఏదైనా అడగవచ్చు.'
          : language === 'hi'
          ? 'नमस्ते! मैं मेडीकवर AI मेडिकल असिस्टेंट हूँ। आप मुझसे अपॉइंटमेंट्स, बेड्स, मरीज़ों, लैब या बिलिंग के बारे में पूछ सकते हैं।'
          : 'Hello! I am your Medicover AI Hospital Assistant. How can I assist you with patient records, bed occupancy, appointments, pharmacy, or billing today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  // Auto scroll to bottom
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  // Setup Web Speech recognition for in-chat mic
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;

        if (language === 'te') recognition.lang = 'te-IN';
        else if (language === 'hi') recognition.lang = 'hi-IN';
        else recognition.lang = 'en-IN';

        recognition.onresult = (e: any) => {
          const spoken = e.results[0][0].transcript;
          setInputText(spoken);
          setIsListening(false);
          handleSendMessage(spoken);
        };

        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);

        recognitionRef.current = recognition;
      } catch (err) {
        console.warn('Chatbot speech init failed', err);
      }
    }
  }, [language]);

  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
          setIsListening(true);
        } catch (e) {}
      }
    }
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      const hospitalData = {
        patients,
        doctors,
        appointments,
        beds,
        invoices,
        medicines,
        labTests,
      };

      const aiResponse = processHospitalQuery(text, language, hospitalData);

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: aiResponse.displayText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: aiResponse.suggestedRoute
          ? [{ label: 'View in System', route: aiResponse.suggestedRoute }]
          : undefined,
        dataPayload: aiResponse.dataPayload,
        isConfirmation: aiResponse.isConfirmation,
        pendingAction: aiResponse.pendingAction,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);

      if (voiceOutputEnabled && aiResponse.spokenText) {
        speakText(aiResponse.spokenText, aiResponse.detectedLang || language);
      }
    }, 350);
  };

  const handleConfirmAction = (msgId: string, pendingAction: ChatMessage['pendingAction']) => {
    if (!pendingAction) return;

    if (pendingAction.actionType === 'delete_patient') {
      deletePatient(pendingAction.targetId);
      addToast('Patient Deleted', 'Patient record deleted via AI Assistant.', 'warning');
    } else if (pendingAction.actionType === 'cancel_appointment') {
      cancelAppointment(pendingAction.targetId);
      addToast('Appointment Cancelled', 'Appointment cancelled via AI Assistant.', 'info');
    }

    setMessages((prev) =>
      prev.map((m) =>
        m.id === msgId
          ? {
              ...m,
              isConfirmation: false,
              pendingAction: undefined,
              text: `${m.text}\n\n✅ **Action Confirmed & Executed**: Completed ${pendingAction.description}`,
            }
          : m
      )
    );
  };

  const clearChat = () => {
    stopSpeaking();
    setMessages([
      {
        id: 'msg-cleared',
        sender: 'assistant',
        text:
          language === 'te'
            ? 'చాట్ చరిత్ర క్లియర్ చేయబడింది. నేను ఇప్పుడు మీకు ఏవిధంగా సహాయపడగలను?'
            : language === 'hi'
            ? 'चैट इतिहास साफ़ हो गया। मैं अब आपकी क्या मदद कर सकता हूँ?'
            : 'Chat history cleared. How may I help you now?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <>
      {/* Floating Chat Trigger Button */}
      <button
        id="floating-ai-chatbot-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-gradient-to-tr from-teal-600 to-sky-600 hover:from-teal-500 hover:to-sky-500 text-white flex items-center justify-center shadow-2xl hover:shadow-teal-500/30 transition-all hover:scale-105 active:scale-95"
        title="Open Vitalora AI Chatbot"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 border-2 border-white dark:border-slate-900 rounded-full animate-pulse" />
      </button>

      {/* Sliding Chat Panel */}
      {isOpen && (
        <div
          id="chatbot-drawer-panel"
          className="fixed bottom-24 right-4 sm:right-6 z-40 w-[calc(100vw-2rem)] sm:w-96 max-w-md h-[560px] max-h-[82vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200"
        >
          {/* Header */}
          <div className="px-4 py-3 bg-gradient-to-r from-teal-600 to-sky-600 text-white flex flex-col gap-2 shrink-0 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                </div>
                <div>
                  <h4 className="text-xs font-bold leading-tight">{t('ai.chat_title')}</h4>
                  <div className="flex items-center gap-1.5 text-[10px] text-teal-100 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping" />
                    <span>Multilingual AI Assistant</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    setVoiceOutputEnabled(!voiceOutputEnabled);
                    if (voiceOutputEnabled) stopSpeaking();
                  }}
                  className={`p-1.5 rounded-lg transition-colors ${
                    voiceOutputEnabled ? 'bg-white/20 text-white' : 'text-teal-200 hover:bg-white/10'
                  }`}
                  title={voiceOutputEnabled ? 'Voice Output ON' : 'Voice Output Muted'}
                >
                  {voiceOutputEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>

                <button
                  onClick={clearChat}
                  className="p-1.5 text-teal-100 hover:bg-white/10 rounded-lg transition-colors"
                  title={t('ai.clear_chat')}
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 text-teal-100 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Language Selector in Chat Drawer: English | తెలుగు | हिन्दी */}
            <div className="flex items-center justify-between bg-black/15 p-1 rounded-xl text-[10px] font-semibold">
              <span className="text-[10px] text-teal-100 flex items-center gap-1 pl-1">
                <Languages className="w-3 h-3 text-teal-200" /> Language:
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setLanguage('en')}
                  className={`px-2 py-0.5 rounded-lg transition-all ${
                    language === 'en'
                      ? 'bg-white text-teal-800 font-bold shadow-xs'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => setLanguage('te')}
                  className={`px-2 py-0.5 rounded-lg transition-all ${
                    language === 'te'
                      ? 'bg-white text-teal-800 font-bold shadow-xs'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  తెలుగు
                </button>
                <button
                  onClick={() => setLanguage('hi')}
                  className={`px-2 py-0.5 rounded-lg transition-all ${
                    language === 'hi'
                      ? 'bg-white text-teal-800 font-bold shadow-xs'
                      : 'text-teal-100 hover:bg-white/10'
                  }`}
                >
                  हिन्दी
                </button>
              </div>
            </div>
          </div>

          {/* Quick Action Suggestion Bar */}
          <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
            {[
              { label: t('ai.quick_today_appt'), query: "Show today's appointments" },
              { label: t('ai.quick_beds'), query: 'How many beds are available?' },
              { label: t('ai.quick_find_patient'), query: 'Find patient Rahul' },
              { label: t('ai.quick_doctors'), query: 'Show available doctors' },
              { label: t('ai.quick_pending_bills'), query: 'Show pending bills' },
              { label: t('ai.quick_pharmacy_low'), query: 'Show low stock pharmacy medicines' },
            ].map((chip) => (
              <button
                key={chip.label}
                onClick={() => handleSendMessage(chip.query)}
                className="px-2.5 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-400 text-slate-700 dark:text-slate-200 hover:text-teal-600 rounded-full text-[10px] font-medium whitespace-nowrap shrink-0 transition-colors shadow-2xs"
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-7 h-7 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs ${
                    msg.sender === 'user'
                      ? 'bg-teal-600 text-white rounded-br-xs shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-xs border border-slate-200/60 dark:border-slate-700/60'
                  }`}
                >
                  <div className="whitespace-pre-line leading-relaxed">{msg.text}</div>

                  {/* Pending Action Card */}
                  {msg.isConfirmation && msg.pendingAction && (
                    <div className="mt-3 p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 rounded-xl space-y-2 text-slate-900 dark:text-white">
                      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-800 dark:text-amber-300">
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                        Confirmation Needed
                      </div>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => handleConfirmAction(msg.id, msg.pendingAction)}
                          className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-[10px] font-semibold transition-colors"
                        >
                          {t('ai.yes_proceed')}
                        </button>
                        <button
                          onClick={() => {
                            setMessages((prev) =>
                              prev.map((m) =>
                                m.id === msg.id
                                  ? { ...m, isConfirmation: false, pendingAction: undefined }
                                  : m
                              )
                            );
                          }}
                          className="px-2.5 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-md text-[10px] font-medium transition-colors"
                        >
                          {t('ai.no_cancel')}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Suggested Navigation Actions */}
                  {msg.suggestedActions?.map((act) => (
                    <button
                      key={act.label}
                      onClick={() => {
                        if (act.route) {
                          navigate(act.route);
                          setIsOpen(false);
                        }
                      }}
                      className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-[10px] font-medium transition-colors"
                    >
                      <span>{act.label}</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  ))}

                  <div
                    className={`text-[9px] mt-1 text-right ${
                      msg.sender === 'user' ? 'text-teal-100' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-7 h-7 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-2 items-center text-slate-400 text-xs py-1">
                <div className="w-6 h-6 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-600 flex items-center justify-center">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded-xl">
                  <span className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Footer Input Bar */}
          <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-1.5"
            >
              <button
                type="button"
                onClick={toggleListening}
                className={`p-2 rounded-xl transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title={isListening ? 'Stop Mic' : 'Voice Input'}
              >
                {isListening ? <Mic className="w-4 h-4 animate-bounce" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                id="chatbot-drawer-input"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t('ai.chat_placeholder')}
                className="flex-1 px-3 py-2 text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-transparent focus:border-teal-500 focus:outline-none placeholder:text-slate-400 transition-all"
              />

              <button
                id="chatbot-drawer-send-btn"
                type="submit"
                disabled={!inputText.trim()}
                className="p-2 bg-teal-600 hover:bg-teal-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

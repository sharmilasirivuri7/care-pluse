import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Send,
  AlertCircle,
  ArrowRight,
  ShieldAlert,
  CheckCircle,
  Languages,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useHospital } from '../../context/HospitalContext';
import { useTranslation } from '../../i18n/translations';
import { Language } from '../../types';
import {
  processHospitalQuery,
  speakText,
  stopSpeaking,
  ProcessedAIResponse,
} from '../../services/aiVoiceAndChatService';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Window typing for SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({ isOpen, onClose }) => {
  const {
    language,
    setLanguage,
    patients,
    doctors,
    appointments,
    beds,
    invoices,
    medicines,
    labTests,
    deletePatient,
    cancelAppointment,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [manualQuery, setManualQuery] = useState('');
  const [response, setResponse] = useState<ProcessedAIResponse | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [speechSupported, setSpeechSupported] = useState(true);

  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition when opened
  useEffect(() => {
    if (!isOpen) {
      stopListening();
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      setErrorMessage(
        'Speech Recognition API is not supported in this browser. Please use the text input below.'
      );
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;

      // Set language code
      if (language === 'te') {
        recognition.lang = 'te-IN';
      } else if (language === 'hi') {
        recognition.lang = 'hi-IN';
      } else {
        recognition.lang = 'en-IN';
      }

      recognition.onstart = () => {
        setIsListening(true);
        setErrorMessage(null);
        setTranscript('');
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setErrorMessage(t('ai.voice_permission_error'));
        } else if (event.error === 'no-speech') {
          setErrorMessage('No voice detected. Please tap the microphone and speak again.');
        } else {
          setErrorMessage(`Voice recognition issue (${event.error}). You can type your request below.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;

      // Auto start listening on open
      startListening();
    } catch (err) {
      console.error('Failed to init speech recognition:', err);
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      stopSpeaking();
    };
  }, [isOpen, language]);

  // When transcript updates and is complete, process automatically
  useEffect(() => {
    if (!isListening && transcript.trim().length > 2) {
      handleQuerySubmit(transcript);
    }
  }, [isListening, transcript]);

  const startListening = () => {
    stopSpeaking();
    setIsSpeaking(false);
    setErrorMessage(null);
    setTranscript('');
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (err) {
        // May already be started
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
    }
    setIsListening(false);
  };

  const handleQuerySubmit = (text: string) => {
    if (!text.trim()) return;
    setErrorMessage(null);

    const hospitalData = {
      patients,
      doctors,
      appointments,
      beds,
      invoices,
      medicines,
      labTests,
    };

    const aiRes = processHospitalQuery(text, language, hospitalData);
    setResponse(aiRes);

    // Speak answer aloud
    if (aiRes.spokenText) {
      setIsSpeaking(true);
      speakText(aiRes.spokenText, aiRes.detectedLang || language);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualQuery.trim()) {
      handleQuerySubmit(manualQuery);
      setManualQuery('');
    }
  };

  const handleConfirmAction = () => {
    if (!response?.pendingAction) return;
    const { actionType, targetId, targetName } = response.pendingAction;

    if (actionType === 'delete_patient') {
      deletePatient(targetId);
      addToast('Patient Deleted', `Record for ${targetName} was deleted.`, 'warning');
    } else if (actionType === 'cancel_appointment') {
      cancelAppointment(targetId);
      addToast('Appointment Cancelled', `Appointment was cancelled.`, 'info');
    }

    const confirmMsg =
      language === 'te'
        ? `✅ **చర్య ఖరారైంది**: ${targetName} కోసం కోరిన విధి విజయవంతంగా పూర్తయింది.`
        : language === 'hi'
        ? `✅ **कार्रवाई की पुष्टि हुई**: ${targetName} के लिए अनुरोध सफलतापूर्वक निष्पादित किया गया।`
        : `✅ **Action Confirmed**: Successfully performed requested operation for **${targetName}**.`;

    setResponse({
      spokenText: 'Action successfully confirmed and executed.',
      displayText: confirmMsg,
    });
    speakText('Action successfully confirmed and executed.', language);
  };

  if (!isOpen) return null;

  return (
    <div
      id="voice-assistant-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          stopListening();
          stopSpeaking();
          onClose();
        }
      }}
    >
      <div
        id="voice-assistant-card"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
      >
        {/* Header */}
        <div className="flex flex-col gap-3 px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-teal-600/10 via-sky-600/10 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  {t('ai.voice_title')}
                </h3>
                <p className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold uppercase tracking-wider">
                  Speech Engine: {language === 'te' ? ' te-IN (తెలుగు)' : language === 'hi' ? ' hi-IN (हिन्दी)' : ' en-IN (English)'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                stopListening();
                stopSpeaking();
                onClose();
              }}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Language Selector: English | తెలుగు | हिन्दी */}
          <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl text-xs">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1 pl-1">
              <Languages className="w-3.5 h-3.5 text-teal-600" /> Language:
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  language === 'en'
                    ? 'bg-teal-600 text-white font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('te')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  language === 'te'
                    ? 'bg-teal-600 text-white font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                తెలుగు
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  language === 'hi'
                    ? 'bg-teal-600 text-white font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                हिन्दी
              </button>
            </div>
          </div>
        </div>

        {/* Body Area */}
        <div className="p-6 flex flex-col items-center text-center">
          {/* Animated Microphone Orb */}
          <div className="relative my-4">
            {isListening && (
              <>
                <div className="absolute -inset-4 rounded-full bg-teal-500/20 animate-ping" />
                <div className="absolute -inset-2 rounded-full bg-teal-500/30 animate-pulse" />
              </>
            )}
            <button
              id="voice-modal-mic-btn"
              onClick={isListening ? stopListening : startListening}
              className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center text-white shadow-xl transition-all active:scale-95 ${
                isListening
                  ? 'bg-rose-500 hover:bg-rose-600 ring-8 ring-rose-500/30 animate-pulse'
                  : 'bg-gradient-to-tr from-teal-600 to-sky-500 hover:from-teal-500 hover:to-sky-400 ring-4 ring-teal-500/20'
              }`}
            >
              {isListening ? <Mic className="w-10 h-10 animate-bounce" /> : <Mic className="w-10 h-10" />}
            </button>
          </div>

          {/* Status Text / Live Speech Wave */}
          <div className="min-h-[2.5rem] flex flex-col items-center justify-center">
            {isListening ? (
              <div className="flex flex-col items-center gap-1.5">
                <span className="text-xs font-semibold text-teal-600 dark:text-teal-400 animate-pulse">
                  {t('ai.listening')}
                </span>
                {transcript ? (
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200 bg-teal-50 dark:bg-teal-950/40 px-3 py-1 rounded-full">
                    "{transcript}"
                  </p>
                ) : (
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-4 bg-teal-500 rounded-full animate-bounce" />
                    <span className="w-1.5 h-6 bg-teal-500 rounded-full animate-bounce [animation-delay:0.15s]" />
                    <span className="w-1.5 h-8 bg-teal-500 rounded-full animate-bounce [animation-delay:0.3s]" />
                    <span className="w-1.5 h-5 bg-teal-500 rounded-full animate-bounce [animation-delay:0.45s]" />
                    <span className="w-1.5 h-3 bg-teal-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('ai.speak_prompt')}
              </p>
            )}
          </div>

          {/* Error Message Box */}
          {errorMessage && (
            <div className="w-full mt-3 p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 rounded-xl text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* AI Response Card */}
          {response && (
            <div
              id="voice-response-card"
              className="w-full mt-4 p-4 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-2xl text-left space-y-3 animate-in fade-in zoom-in-95 duration-200"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Assistant Response
                </span>
                <button
                  onClick={() => {
                    if (isSpeaking) {
                      stopSpeaking();
                      setIsSpeaking(false);
                    } else if (response.spokenText) {
                      setIsSpeaking(true);
                      speakText(response.spokenText, response.detectedLang || language);
                    }
                  }}
                  className="p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded-md"
                  title={isSpeaking ? 'Mute Speech' : 'Speak Again'}
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4 text-teal-500" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              <div className="text-xs text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed">
                {response.displayText}
              </div>

              {/* Confirmation Prompt if Dangerous Action */}
              {response.isConfirmation && response.pendingAction && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-800 dark:text-amber-300">
                    <ShieldAlert className="w-4 h-4 text-amber-600" />
                    {t('ai.confirm_action')}
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={handleConfirmAction}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold transition-colors"
                    >
                      {t('ai.yes_proceed')}
                    </button>
                    <button
                      onClick={() => setResponse(null)}
                      className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors"
                    >
                      {t('ai.no_cancel')}
                    </button>
                  </div>
                </div>
              )}

              {/* Suggested Navigation Route */}
              {response.suggestedRoute && (
                <button
                  onClick={() => {
                    navigate(response.suggestedRoute!);
                    onClose();
                  }}
                  className="w-full mt-2 px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open Related View</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

          {/* Quick Voice Prompt Suggestions */}
          <div className="w-full mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <div className="text-[11px] font-semibold text-slate-400 mb-2 text-left">
              Quick Voice Examples ({language.toUpperCase()}):
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(language === 'te'
                ? [
                    'ఈరోజు అపాయింట్మెంట్స్ చూపించు',
                    'ఎన్ని బెడ్స్ ఖాళీగా ఉన్నాయి?',
                    'రాహుల్ అనే పేషెంట్ని వెతుకు',
                    'అందుబాటులో ఉన్న డాక్టర్లను చూపించు',
                    'పెండింగ్ బిల్లులు చూపించు',
                  ]
                : language === 'hi'
                ? [
                    'आज की अपॉइंटमेंट दिखाओ',
                    'कितने बेड खाली हैं?',
                    'राहुल मरीज को खोजो',
                    'उपलब्ध डॉक्टर दिखाओ',
                    'पेंडिंग बिल दिखाओ',
                  ]
                : [
                    "Show today's appointments",
                    'How many beds are available?',
                    'Find patient Rahul',
                    'Show available doctors',
                    'Show pending bills',
                  ]
              ).map((example) => (
                <button
                  key={example}
                  onClick={() => handleQuerySubmit(example)}
                  className="px-2.5 py-1 text-[11px] bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950 text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-300 rounded-lg transition-colors"
                >
                  "{example}"
                </button>
              ))}
            </div>
          </div>

          {/* Fallback Text Input */}
          <form onSubmit={handleManualSubmit} className="w-full mt-4 flex items-center gap-2">
            <input
              id="voice-modal-text-fallback-input"
              type="text"
              value={manualQuery}
              onChange={(e) => setManualQuery(e.target.value)}
              placeholder="Or type your request here..."
              className="flex-1 px-3.5 py-2 text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-transparent focus:border-teal-500 focus:outline-none transition-all placeholder:text-slate-400"
            />
            <button
              id="voice-modal-text-submit-btn"
              type="submit"
              disabled={!manualQuery.trim()}
              className="p-2 bg-teal-600 hover:bg-teal-700 disabled:opacity-40 text-white rounded-xl transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

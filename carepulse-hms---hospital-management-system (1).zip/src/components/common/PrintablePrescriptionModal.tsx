import React from 'react';
import { Printer, X, HeartPulse } from 'lucide-react';
import { Prescription } from '../../types';
import { useHospital } from '../../context/HospitalContext';

interface PrintablePrescriptionModalProps {
  prescription: Prescription | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintablePrescriptionModal: React.FC<PrintablePrescriptionModalProps> = ({
  prescription,
  isOpen,
  onClose,
}) => {
  const { settings } = useHospital();
  if (!isOpen || !prescription) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="printable-prescription-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="printable-prescription-card"
        className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6"
      >
        {/* Controls bar */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 print:hidden">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
            Prescription Preview: {prescription.prescriptionId}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Prescription</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Medical Pad */}
        <div className="p-8 bg-white text-slate-900 space-y-6">
          {/* Header Doctor & Hospital Info */}
          <div className="flex justify-between items-start border-b-2 border-teal-600 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-md">
                <HeartPulse className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">{prescription.doctorName}</h2>
                <p className="text-xs font-medium text-teal-700">{prescription.doctorQualification}</p>
                <p className="text-xs text-slate-500">{prescription.department} Specialist</p>
                <p className="text-[11px] text-slate-400">{settings.hospitalName}</p>
              </div>
            </div>
            <div className="text-right text-xs text-slate-500">
              <div className="text-sm font-bold text-slate-900">{prescription.prescriptionId}</div>
              <div>Date: {prescription.date}</div>
              <div>Emergency: {settings.emergencyPhone}</div>
            </div>
          </div>

          {/* Patient Details Row */}
          <div className="grid grid-cols-4 gap-4 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 font-semibold block text-[10px] uppercase">Patient Name</span>
              <span className="font-bold text-slate-900">{prescription.patientName}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold block text-[10px] uppercase">Patient ID</span>
              <span className="text-slate-700">{prescription.patientId}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold block text-[10px] uppercase">Age / Gender</span>
              <span className="text-slate-700">{prescription.patientAge} yrs / {prescription.patientGender}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold block text-[10px] uppercase">Diagnosis</span>
              <span className="font-bold text-teal-700">{prescription.diagnosis}</span>
            </div>
          </div>

          {/* Rx Symbol & Medication Table */}
          <div className="space-y-3">
            <div className="text-2xl font-serif font-black text-teal-700 italic flex items-center gap-2">
              <span>℞</span>
              <span className="text-xs font-sans not-italic font-bold text-slate-400 uppercase tracking-widest">
                Prescribed Medicines
              </span>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <th className="py-2">#</th>
                  <th className="py-2">Medicine Name</th>
                  <th className="py-2">Dosage</th>
                  <th className="py-2">Frequency</th>
                  <th className="py-2">Duration</th>
                  <th className="py-2">Instructions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {prescription.medicines.map((med, idx) => (
                  <tr key={med.id} className="py-2.5">
                    <td className="py-2.5 text-slate-400">{idx + 1}</td>
                    <td className="py-2.5 font-bold text-slate-900">{med.medicineName}</td>
                    <td className="py-2.5 text-slate-700">{med.dosage}</td>
                    <td className="py-2.5 font-medium text-teal-700">{med.frequency}</td>
                    <td className="py-2.5 text-slate-700">{med.duration}</td>
                    <td className="py-2.5 text-slate-500 italic">{med.instructions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Advice & Lifestyle */}
          {prescription.advice && (
            <div className="p-3.5 bg-teal-50/50 rounded-xl border border-teal-100 text-xs">
              <span className="font-bold text-teal-800 uppercase tracking-wide text-[10px] block mb-1">
                Doctor's Advice & Diet Instructions:
              </span>
              <p className="text-slate-700 leading-relaxed">{prescription.advice}</p>
            </div>
          )}

          {/* Follow-up & Doctor Signature */}
          <div className="pt-8 flex justify-between items-end text-xs border-t border-slate-200">
            <div>
              {prescription.nextFollowUp && (
                <div className="font-semibold text-slate-700">
                  Next Review / Follow-up:{' '}
                  <span className="text-teal-700 font-bold">{prescription.nextFollowUp}</span>
                </div>
              )}
              <p className="text-[10px] text-slate-400 mt-1">Please bring this prescription during your next visit.</p>
            </div>
            <div className="text-center">
              <div className="border-b border-slate-400 w-44 mb-1"></div>
              <p className="text-xs font-bold text-slate-900">{prescription.doctorName}</p>
              <p className="text-[10px] text-slate-500">Signature / Reg. No. PMC-44912</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

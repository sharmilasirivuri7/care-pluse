import React from 'react';
import { Printer, X, HeartPulse } from 'lucide-react';
import { Invoice } from '../../types';
import { useHospital } from '../../context/HospitalContext';

interface PrintableInvoiceModalProps {
  invoice: Invoice | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintableInvoiceModal: React.FC<PrintableInvoiceModalProps> = ({
  invoice,
  isOpen,
  onClose,
}) => {
  const { settings } = useHospital();
  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="printable-invoice-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="printable-invoice-card"
        className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6"
      >
        {/* Controls bar (hidden during print) */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 print:hidden">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
            Invoice Preview: {invoice.invoiceId}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Invoice</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Letterhead & Invoice Body */}
        <div className="p-8 bg-white text-slate-900 space-y-6">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-md">
                <HeartPulse className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">{settings.hospitalName}</h2>
                <p className="text-xs text-slate-500">{settings.tagline}</p>
                <p className="text-[11px] text-slate-500 mt-1">{settings.address}</p>
                <p className="text-[11px] text-slate-500">Phone: {settings.phone} | Email: {settings.email}</p>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-block px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 text-xs font-bold rounded-lg uppercase tracking-wider">
                TAX INVOICE
              </span>
              <div className="text-lg font-bold text-slate-900 mt-2">{invoice.invoiceId}</div>
              <div className="text-xs text-slate-500">Date: {invoice.date}</div>
              <div className="text-xs text-slate-500">Due: {invoice.dueDate}</div>
            </div>
          </div>

          {/* Bill To & Status */}
          <div className="grid grid-cols-2 gap-4 py-2 border-b border-slate-100 text-xs">
            <div>
              <div className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">PATIENT INFORMATION</div>
              <div className="text-sm font-bold text-slate-900 mt-1">{invoice.patientName}</div>
              <div className="text-slate-600">ID: {invoice.patientId}</div>
              <div className="text-slate-600">Phone: {invoice.patientPhone}</div>
            </div>
            <div className="text-right">
              <div className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">PAYMENT STATUS</div>
              <div className="mt-1">
                <span
                  className={`inline-block px-3 py-0.5 rounded-full text-xs font-bold uppercase ${
                    invoice.status === 'Paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : invoice.status === 'Partially Paid'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {invoice.status}
                </span>
              </div>
              {invoice.paymentMethod && (
                <div className="text-slate-600 mt-1">Method: {invoice.paymentMethod}</div>
              )}
            </div>
          </div>

          {/* Itemized Table */}
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                <th className="py-2.5">#</th>
                <th className="py-2.5">Description</th>
                <th className="py-2.5">Category</th>
                <th className="py-2.5 text-center">Qty</th>
                <th className="py-2.5 text-right">Unit Price</th>
                <th className="py-2.5 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoice.items.map((item, idx) => (
                <tr key={item.id} className="py-2">
                  <td className="py-2.5 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 font-medium text-slate-900">{item.description}</td>
                  <td className="py-2.5 text-slate-500">{item.category}</td>
                  <td className="py-2.5 text-center text-slate-700">{item.quantity}</td>
                  <td className="py-2.5 text-right text-slate-700">₹{item.unitPrice.toLocaleString()}</td>
                  <td className="py-2.5 text-right font-semibold text-slate-900">₹{item.total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals Breakdown */}
          <div className="flex justify-end pt-4 border-t border-slate-200">
            <div className="w-64 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span>₹{invoice.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Tax ({invoice.taxRate}%):</span>
                <span>₹{invoice.taxAmount.toLocaleString()}</span>
              </div>
              {invoice.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount:</span>
                  <span>-₹{invoice.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Amount:</span>
                <span>₹{invoice.total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Amount Paid:</span>
                <span>₹{invoice.paidAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900 pt-1 border-t border-slate-100">
                <span>Remaining Balance:</span>
                <span className={invoice.remainingAmount > 0 ? 'text-rose-600 font-extrabold' : 'text-emerald-600'}>
                  ₹{invoice.remainingAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Footer Signatures */}
          <div className="pt-10 flex justify-between items-end text-xs text-slate-500 border-t border-slate-200">
            <div>
              <p className="font-semibold text-slate-700">Thank you for choosing {settings.hospitalName}</p>
              <p className="text-[10px] text-slate-400">Computer generated medical tax invoice. Valid without physical stamp.</p>
            </div>
            <div className="text-center">
              <div className="border-b border-slate-400 w-36 mb-1"></div>
              <p className="text-[11px] font-semibold text-slate-700">Authorized Accounts Signatory</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Moon,
  Sun,
  Bell,
  Mic,
  Languages,
  User,
  LogOut,
  Menu,
  CheckCircle2,
  Calendar,
  Pill,
  CreditCard,
  UserCheck,
  Building2,
  X,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useHospital } from '../../context/HospitalContext';
import { useTranslation } from '../../i18n/translations';
import { Language } from '../../types';

interface HeaderProps {
  onToggleSidebar: () => void;
  onOpenVoiceAssistant: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleSidebar, onOpenVoiceAssistant }) => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    user,
    logout,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    patients,
    doctors,
    appointments,
    medicines,
    invoices,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Popover States
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const langRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setIsProfileOpen(false);
      }
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Global search filtering
  const filteredPatients = searchQuery.trim()
    ? patients.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.patientId.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.phone.includes(searchQuery)
      )
    : [];

  const filteredDoctors = searchQuery.trim()
    ? doctors.filter(
        (d) =>
          d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          d.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
          d.specialization.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const filteredMedicines = searchQuery.trim()
    ? medicines.filter(
        (m) =>
          m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          m.genericName.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const totalSearchResults = filteredPatients.length + filteredDoctors.length + filteredMedicines.length;

  return (
    <header
      id="main-app-header"
      className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-6 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors"
    >
      {/* Left: Mobile Toggle & Global Search */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <button
          id="mobile-sidebar-toggle-btn"
          onClick={onToggleSidebar}
          className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 lg:hidden rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Global Search Bar */}
        <div ref={searchContainerRef} className="relative w-full">
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
            <input
              id="global-hospital-search-input"
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              placeholder={`${t('common.search')} (Patients, Doctors, Medicines...)`}
              className="w-full pl-9 pr-8 py-2 text-xs md:text-sm bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-transparent focus:border-teal-500 dark:focus:border-teal-400 focus:bg-white dark:focus:bg-slate-900 focus:outline-none transition-all placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Search Dropdown Results */}
          {isSearchOpen && searchQuery.trim().length > 0 && (
            <div
              id="global-search-results-dropdown"
              className="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50 max-h-96 overflow-y-auto"
            >
              <div className="px-4 pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Search Results ({totalSearchResults})
                </span>
                <span className="text-xs text-teal-600 dark:text-teal-400 font-medium">
                  Keyword: "{searchQuery}"
                </span>
              </div>

              {totalSearchResults === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  No records matching "{searchQuery}"
                </div>
              ) : (
                <div className="space-y-4 px-2">
                  {/* Patients section */}
                  {filteredPatients.length > 0 && (
                    <div>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                        <UserCheck className="w-3.5 h-3.5 text-teal-500" />
                        Patients ({filteredPatients.length})
                      </div>
                      {filteredPatients.slice(0, 4).map((p) => (
                        <button
                          key={p.id}
                          onClick={() => {
                            navigate(`/patients?search=${encodeURIComponent(p.name)}`);
                            setIsSearchOpen(false);
                          }}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-teal-50 dark:hover:bg-teal-950/40 flex items-center justify-between text-xs transition-colors"
                        >
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white">
                              {p.name}
                            </span>
                            <span className="text-slate-400 ml-2 text-[11px]">
                              {p.patientId} • {p.bloodGroup} • {p.department}
                            </span>
                          </div>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {p.status}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Doctors section */}
                  {filteredDoctors.length > 0 && (
                    <div>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-sky-500" />
                        Doctors ({filteredDoctors.length})
                      </div>
                      {filteredDoctors.slice(0, 3).map((d) => (
                        <button
                          key={d.id}
                          onClick={() => {
                            navigate(`/doctors?search=${encodeURIComponent(d.name)}`);
                            setIsSearchOpen(false);
                          }}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-sky-50 dark:hover:bg-sky-950/40 flex items-center justify-between text-xs transition-colors"
                        >
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white">
                              {d.name}
                            </span>
                            <span className="text-slate-400 ml-2 text-[11px]">
                              {d.specialization} ({d.department})
                            </span>
                          </div>
                          <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                            ₹{d.consultationFee}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Medicines section */}
                  {filteredMedicines.length > 0 && (
                    <div>
                      <div className="px-2 py-1 text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                        <Pill className="w-3.5 h-3.5 text-amber-500" />
                        Medicines ({filteredMedicines.length})
                      </div>
                      {filteredMedicines.slice(0, 3).map((m) => (
                        <button
                          key={m.id}
                          onClick={() => {
                            navigate(`/pharmacy?search=${encodeURIComponent(m.name)}`);
                            setIsSearchOpen(false);
                          }}
                          className="w-full text-left px-3 py-2 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/40 flex items-center justify-between text-xs transition-colors"
                        >
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white">
                              {m.name}
                            </span>
                            <span className="text-slate-400 ml-2 text-[11px]">
                              {m.category} • Shelf {m.location}
                            </span>
                          </div>
                          <span className="text-slate-600 dark:text-slate-300">
                            Qty: {m.stockQuantity}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Controls: AI Voice Mic, Language, Theme, Notifications, Profile */}
      <div className="flex items-center gap-1.5 sm:gap-2.5">
        {/* Floating Voice Assistant Trigger */}
        <button
          id="header-voice-assistant-btn"
          onClick={onOpenVoiceAssistant}
          className="relative flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-teal-600 to-sky-600 hover:from-teal-500 hover:to-sky-500 text-white rounded-xl text-xs font-semibold shadow-xs hover:shadow-md transition-all active:scale-95"
          title="Open AI Voice Assistant"
        >
          <Mic className="w-3.5 h-3.5 animate-pulse" />
          <span className="hidden sm:inline">AI Voice</span>
        </button>

        {/* Multilingual Selector */}
        <div ref={langRef} className="relative">
          <button
            id="header-language-select-btn"
            onClick={() => setIsLangOpen(!isLangOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
            title="Change Language"
          >
            <Languages className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span className="uppercase font-bold tracking-wider">{language}</span>
          </button>

          {isLangOpen && (
            <div
              id="header-language-dropdown"
              className="absolute right-0 mt-2 w-44 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              {[
                { code: 'en', label: 'English', native: 'English (India)' },
                { code: 'te', label: 'Telugu', native: 'తెలుగు (Telugu)' },
                { code: 'hi', label: 'Hindi', native: 'हिन्दी (Hindi)' },
              ].map((langItem) => (
                <button
                  key={langItem.code}
                  onClick={() => {
                    setLanguage(langItem.code as Language);
                    setIsLangOpen(false);
                  }}
                  className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors ${
                    language === langItem.code
                      ? 'bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 font-semibold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <div>
                    <div className="font-medium">{langItem.native}</div>
                    <div className="text-[10px] text-slate-400">{langItem.label}</div>
                  </div>
                  {language === langItem.code && <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Dark / Light Mode Switch */}
        <button
          id="header-theme-toggle-btn"
          onClick={toggleTheme}
          className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
        </button>

        {/* Notifications Popover */}
        <div ref={notifRef} className="relative">
          <button
            id="header-notifications-btn"
            onClick={() => setIsNotifOpen(!isNotifOpen)}
            className="relative p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 flex items-center justify-center text-[10px] font-bold text-white bg-rose-500 rounded-full shadow-xs">
                {unreadCount}
              </span>
            )}
          </button>

          {isNotifOpen && (
            <div
              id="header-notifications-dropdown"
              className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="flex items-center justify-between px-4 pb-2.5 mb-1 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-xs text-slate-900 dark:text-white">Notifications</span>
                  {unreadCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-[10px] font-bold rounded-full">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllNotificationsRead}
                    className="text-[11px] text-teal-600 hover:text-teal-700 dark:text-teal-400 font-medium"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                {notifications.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-400">No notifications</div>
                ) : (
                  notifications.slice(0, 5).map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        markNotificationRead(n.id);
                        if (n.actionRoute) {
                          navigate(n.actionRoute);
                          setIsNotifOpen(false);
                        }
                      }}
                      className={`px-4 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors ${
                        !n.read ? 'bg-teal-50/50 dark:bg-teal-950/20' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="text-xs font-semibold text-slate-900 dark:text-white">
                          {n.title}
                        </h5>
                        <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp}</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 line-clamp-2 leading-relaxed">
                        {n.message}
                      </p>
                    </div>
                  ))
                )}
              </div>

              <div className="pt-2 px-4 border-t border-slate-100 dark:border-slate-800 text-center">
                <button
                  onClick={() => {
                    navigate('/notifications');
                    setIsNotifOpen(false);
                  }}
                  className="text-xs font-medium text-teal-600 hover:text-teal-700 dark:text-teal-400"
                >
                  {t('common.view_all')}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div ref={profileRef} className="relative">
          <button
            id="header-user-profile-btn"
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <img
              src={user.avatar}
              alt={user.name}
              className="w-8 h-8 rounded-full object-cover ring-2 ring-teal-500/30"
            />
            <div className="hidden md:block text-left">
              <div className="text-xs font-semibold text-slate-900 dark:text-white truncate max-w-[120px]">
                {user.name}
              </div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                {user.role}
              </div>
            </div>
          </button>

          {isProfileOpen && (
            <div
              id="header-user-profile-dropdown"
              className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <div className="text-xs font-semibold text-slate-900 dark:text-white">{user.name}</div>
                <div className="text-[11px] text-slate-400 truncate">{user.email}</div>
                <span className="inline-block mt-1 px-2 py-0.5 bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[10px] font-bold rounded-md uppercase">
                  {user.role}
                </span>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    navigate('/settings');
                    setIsProfileOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
                >
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  {t('nav.settings')}
                </button>
                <button
                  onClick={() => {
                    logout();
                    setIsProfileOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  {t('nav.logout')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

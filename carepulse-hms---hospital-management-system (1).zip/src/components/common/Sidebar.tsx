import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  Calendar,
  Building,
  UserPlus,
  BedDouble,
  Receipt,
  Pill,
  FlaskConical,
  FileText,
  FileSpreadsheet,
  BadgeAlert,
  BarChart3,
  Bell,
  Settings,
  HeartPulse,
  X,
  PhoneCall,
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useTranslation } from '../../i18n/translations';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { language, appointments, beds, invoices, medicines, notifications, settings } = useHospital();
  const t = useTranslation(language);
  const navigate = useNavigate();

  // Badges
  const todayApptsCount = appointments.filter(
    (a) => a.date === new Date().toISOString().split('T')[0] || a.date === '2026-08-27'
  ).length;
  const availableBedsCount = beds.filter((b) => b.status === 'Available').length;
  const pendingInvoicesCount = invoices.filter((i) => i.status === 'Pending').length;
  const lowStockCount = medicines.filter((m) => m.stockQuantity <= m.minThreshold).length;
  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  const navItems = [
    { to: '/', label: t('nav.dashboard'), icon: LayoutDashboard, badge: null },
    { to: '/patients', label: t('nav.patients'), icon: Users, badge: null },
    { to: '/doctors', label: t('nav.doctors'), icon: Stethoscope, badge: null },
    { to: '/appointments', label: t('nav.appointments'), icon: Calendar, badge: todayApptsCount ? `${todayApptsCount}` : null, badgeColor: 'bg-teal-500' },
    { to: '/departments', label: t('nav.departments'), icon: Building, badge: null },
    { to: '/admissions', label: t('nav.admissions'), icon: UserPlus, badge: null },
    { to: '/beds', label: t('nav.beds'), icon: BedDouble, badge: `${availableBedsCount} Free`, badgeColor: 'bg-emerald-500' },
    { to: '/billing', label: t('nav.billing'), icon: Receipt, badge: pendingInvoicesCount ? `${pendingInvoicesCount}` : null, badgeColor: 'bg-amber-500' },
    { to: '/pharmacy', label: t('nav.pharmacy'), icon: Pill, badge: lowStockCount ? `${lowStockCount} Low` : null, badgeColor: 'bg-rose-500' },
    { to: '/laboratory', label: t('nav.laboratory'), icon: FlaskConical, badge: null },
    { to: '/medical-records', label: t('nav.medical_records'), icon: FileText, badge: null },
    { to: '/prescriptions', label: t('nav.prescriptions'), icon: FileSpreadsheet, badge: null },
    { to: '/staff', label: t('nav.staff'), icon: BadgeAlert, badge: null },
    { to: '/reports', label: t('nav.reports'), icon: BarChart3, badge: null },
    { to: '/notifications', label: t('nav.notifications'), icon: Bell, badge: unreadNotifCount ? `${unreadNotifCount}` : null, badgeColor: 'bg-rose-500' },
    { to: '/settings', label: t('nav.settings'), icon: Settings, badge: null },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          id="sidebar-backdrop"
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="main-app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Hospital Brand Header */}
        <div className="h-16 flex items-center justify-between px-5 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div
            onClick={() => {
              navigate('/');
              onClose();
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-teal-500/20 group-hover:scale-105 transition-transform">
              <HeartPulse className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-1">
                {settings?.hospitalName || 'Medicover Hospital'}
              </h1>
              <p className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold">HMS Platform</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 lg:hidden rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items (Scrollable) */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1 scrollbar-thin">
          <div className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Medical Modules
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-semibold shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                  }`
                }
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold text-white leading-none ${
                      item.badgeColor || 'bg-teal-500'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </div>

        {/* Emergency Helpline Footer */}
        <div className="p-3.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 shrink-0">
          <div className="flex items-center gap-2.5 p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/40 rounded-xl text-rose-700 dark:text-rose-300 text-xs">
            <PhoneCall className="w-4 h-4 text-rose-500 shrink-0 animate-bounce" />
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-wide">Emergency 24x7</div>
              <div className="text-xs font-bold truncate">1800 425 9999</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Patient,
  Doctor,
  Appointment,
  Department,
  Bed,
  Admission,
  Invoice,
  Medicine,
  LabTest,
  Prescription,
  MedicalRecord,
  StaffMember,
  HospitalNotification,
  ActivityLog,
  HospitalSettings,
  UserProfile,
  Language,
  Theme,
  BedStatus,
  AppointmentStatus,
  InvoiceStatus,
  LabTestStatus,
} from '../types';
import {
  initialPatients,
  initialDoctors,
  initialDepartments,
  initialBeds,
  initialAdmissions,
  initialAppointments,
  initialInvoices,
  initialMedicines,
  initialLabTests,
  initialPrescriptions,
  initialMedicalRecords,
  initialStaff,
  initialNotifications,
  initialActivities,
  initialHospitalSettings,
  initialUserProfile,
} from '../data/initialData';

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  timestamp: number;
}

interface HospitalContextType {
  // State
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  user: UserProfile;
  setUser: (user: UserProfile) => void;
  isAuthenticated: boolean;
  login: (email: string, role: string) => boolean;
  logout: () => void;
  settings: HospitalSettings;
  updateSettings: (newSettings: Partial<HospitalSettings>) => void;

  // Data Collections
  patients: Patient[];
  doctors: Doctor[];
  appointments: Appointment[];
  departments: Department[];
  beds: Bed[];
  admissions: Admission[];
  invoices: Invoice[];
  medicines: Medicine[];
  labTests: LabTest[];
  prescriptions: Prescription[];
  medicalRecords: MedicalRecord[];
  staff: StaffMember[];
  notifications: HospitalNotification[];
  activities: ActivityLog[];

  // Toasts
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  removeToast: (id: string) => void;

  // CRUD & Operations
  // Patients
  addPatient: (patient: Omit<Patient, 'id' | 'patientId' | 'createdAt'>) => Patient;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  deletePatient: (id: string) => void;

  // Doctors
  addDoctor: (doctor: Omit<Doctor, 'id' | 'doctorId'>) => Doctor;
  updateDoctor: (id: string, updates: Partial<Doctor>) => void;
  deleteDoctor: (id: string) => void;
  toggleDoctorAvailability: (id: string, status: Doctor['availability']) => void;

  // Appointments
  bookAppointment: (appt: Omit<Appointment, 'id' | 'appointmentId' | 'createdAt'>) => Appointment;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  cancelAppointment: (id: string, reason?: string) => void;
  completeAppointment: (id: string) => void;
  deleteAppointment: (id: string) => void;

  // Admissions & Beds
  admitPatient: (
    patientIdOrData: any,
    bedId?: string,
    doctorInCharge?: string,
    diagnosis?: string,
    deposit?: number
  ) => Admission;
  dischargePatient: (admissionId: string) => void;
  transferBed: (admissionId: string, newBedId: string) => void;
  addBed: (bed: Omit<Bed, 'id' | 'bedId'>) => Bed;
  updateBedStatus: (bedId: string, status: BedStatus, notes?: string) => void;

  // Departments
  addDepartment: (dept: Omit<Department, 'id' | 'departmentId'>) => Department;
  updateDepartment: (id: string, updates: Partial<Department>) => void;

  // Billing
  createInvoice: (inv: any) => Invoice;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  recordPayment: (id: string, amount: number, paymentMethod: Invoice['paymentMethod']) => void;
  deleteInvoice: (id: string) => void;

  // Pharmacy
  addMedicine: (med: Omit<Medicine, 'id' | 'medicineId'>) => Medicine;
  updateMedicine: (id: string, updates: Partial<Medicine>) => void;
  updateMedicineStock: (id: string, deltaQuantity: number) => void;
  deleteMedicine: (id: string) => void;

  // Laboratory
  addLabTest: (test: Omit<LabTest, 'id' | 'testId'>) => LabTest;
  orderLabTest: (test: Omit<LabTest, 'id' | 'testId'>) => LabTest;
  updateLabTestStatus: (id: string, status: LabTestStatus, results?: LabTest['results'], notes?: string) => void;
  updateLabTestResult: (id: string, resultOrStatus: any, notes?: string) => void;
  deleteLabTest: (id: string) => void;

  // Prescriptions & Records
  addPrescription: (rx: Omit<Prescription, 'id' | 'prescriptionId'>) => Prescription;
  deletePrescription: (id: string) => void;
  addMedicalRecord: (rec: Omit<MedicalRecord, 'id' | 'recordId'>) => MedicalRecord;
  deleteMedicalRecord: (id: string) => void;

  // Staff
  addStaff: (stf: Omit<StaffMember, 'id' | 'staffId'>) => StaffMember;
  updateStaff: (id: string, updates: Partial<StaffMember>) => void;
  deleteStaff: (id: string) => void;

  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  clearNotification: (id: string) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  clearAllNotifications: () => void;

  // Theme & Data Aliases
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  resetToDemoData: () => void;
  addStaffMember: (stf: Omit<StaffMember, 'id' | 'staffId'>) => StaffMember;
  updateStaffMember: (id: string, updates: Partial<StaffMember>) => void;
  deleteStaffMember: (id: string) => void;

  // Reset demo data
  resetAllData: () => void;
  logActivity: (action: string, module: string, details: string) => void;
}

const HospitalContext = createContext<HospitalContextType | undefined>(undefined);

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(`carepulse_${key}`);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (err) {
    console.error(`Failed to load ${key} from localStorage`, err);
  }
  return fallback;
}

function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(`carepulse_${key}`, JSON.stringify(data));
  } catch (err) {
    console.error(`Failed to save ${key} to localStorage`, err);
  }
}

export const HospitalProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Preferences & Auth
  const [language, setLanguageState] = useState<Language>(() => loadFromStorage<Language>('language', 'en'));
  const [theme, setThemeState] = useState<Theme>(() => loadFromStorage<Theme>('theme', 'light'));
  const [user, setUserState] = useState<UserProfile>(() => loadFromStorage<UserProfile>('user', initialUserProfile));
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => loadFromStorage<boolean>('auth', true));
  const [settings, setSettingsState] = useState<HospitalSettings>(() => loadFromStorage<HospitalSettings>('settings', initialHospitalSettings));

  // Collections
  const [patients, setPatients] = useState<Patient[]>(() => loadFromStorage<Patient[]>('patients', initialPatients));
  const [doctors, setDoctors] = useState<Doctor[]>(() => loadFromStorage<Doctor[]>('doctors', initialDoctors));
  const [appointments, setAppointments] = useState<Appointment[]>(() => loadFromStorage<Appointment[]>('appointments', initialAppointments));
  const [departments, setDepartments] = useState<Department[]>(() => loadFromStorage<Department[]>('departments', initialDepartments));
  const [beds, setBeds] = useState<Bed[]>(() => loadFromStorage<Bed[]>('beds', initialBeds));
  const [admissions, setAdmissions] = useState<Admission[]>(() => loadFromStorage<Admission[]>('admissions', initialAdmissions));
  const [invoices, setInvoices] = useState<Invoice[]>(() => loadFromStorage<Invoice[]>('invoices', initialInvoices));
  const [medicines, setMedicines] = useState<Medicine[]>(() => loadFromStorage<Medicine[]>('medicines', initialMedicines));
  const [labTests, setLabTests] = useState<LabTest[]>(() => loadFromStorage<LabTest[]>('labTests', initialLabTests));
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(() => loadFromStorage<Prescription[]>('prescriptions', initialPrescriptions));
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>(() => loadFromStorage<MedicalRecord[]>('medicalRecords', initialMedicalRecords));
  const [staff, setStaff] = useState<StaffMember[]>(() => loadFromStorage<StaffMember[]>('staff', initialStaff));
  const [notifications, setNotifications] = useState<HospitalNotification[]>(() => loadFromStorage<HospitalNotification[]>('notifications', initialNotifications));
  const [activities, setActivities] = useState<ActivityLog[]>(() => loadFromStorage<ActivityLog[]>('activities', initialActivities));

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, title, message, type, timestamp: Date.now() }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to local storage
  useEffect(() => saveToStorage('language', language), [language]);
  useEffect(() => saveToStorage('theme', theme), [theme]);
  useEffect(() => saveToStorage('user', user), [user]);
  useEffect(() => saveToStorage('auth', isAuthenticated), [isAuthenticated]);
  useEffect(() => saveToStorage('settings', settings), [settings]);
  useEffect(() => saveToStorage('patients', patients), [patients]);
  useEffect(() => saveToStorage('doctors', doctors), [doctors]);
  useEffect(() => saveToStorage('appointments', appointments), [appointments]);
  useEffect(() => saveToStorage('departments', departments), [departments]);
  useEffect(() => saveToStorage('beds', beds), [beds]);
  useEffect(() => saveToStorage('admissions', admissions), [admissions]);
  useEffect(() => saveToStorage('invoices', invoices), [invoices]);
  useEffect(() => saveToStorage('medicines', medicines), [medicines]);
  useEffect(() => saveToStorage('labTests', labTests), [labTests]);
  useEffect(() => saveToStorage('prescriptions', prescriptions), [prescriptions]);
  useEffect(() => saveToStorage('medicalRecords', medicalRecords), [medicalRecords]);
  useEffect(() => saveToStorage('staff', staff), [staff]);
  useEffect(() => saveToStorage('notifications', notifications), [notifications]);
  useEffect(() => saveToStorage('activities', activities), [activities]);

  // Apply dark mode class to html document element
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    addToast('Language Updated', `Active language set to ${lang.toUpperCase()}`, 'info');
  };

  const setTheme = (t: Theme) => {
    setThemeState(t);
  };

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const setUser = (newUser: UserProfile) => {
    setUserState(newUser);
  };

  const login = (email: string, role: string) => {
    setIsAuthenticated(true);
    setUserState((prev) => ({
      ...prev,
      email,
      role: role as any,
    }));
    addToast('Signed In', `Welcome back, ${user.name}`, 'success');
    logActivity('User Login', 'Auth', `Logged in as ${role}`);
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    addToast('Signed Out', 'You have been safely signed out.', 'info');
  };

  const updateSettings = (newSettings: Partial<HospitalSettings>) => {
    setSettingsState((prev) => ({ ...prev, ...newSettings }));
    addToast('Settings Saved', 'Hospital settings updated successfully.', 'success');
    logActivity('Settings Modified', 'Settings', 'Updated hospital operational settings');
  };

  const logActivity = (action: string, module: string, details: string) => {
    const newLog: ActivityLog = {
      id: `act-${Date.now()}`,
      user: user.name || 'System Admin',
      action,
      module,
      timestamp: new Date().toLocaleString(),
      details,
    };
    setActivities((prev) => [newLog, ...prev.slice(0, 40)]);
  };

  // ----------------- PATIENT ACTIONS -----------------
  const addPatient = (patientData: Omit<Patient, 'id' | 'patientId' | 'createdAt'>): Patient => {
    const newId = `PAT-${1000 + patients.length + 1}`;
    const newPatient: Patient = {
      ...patientData,
      id: `p-${Date.now()}`,
      patientId: newId,
      createdAt: new Date().toISOString(),
    };
    setPatients((prev) => [newPatient, ...prev]);
    addToast('Patient Registered', `${newPatient.name} (${newId}) successfully added.`, 'success');
    logActivity('Patient Registered', 'Patients', `Created profile for ${newPatient.name}`);
    return newPatient;
  };

  const updatePatient = (id: string, updates: Partial<Patient>) => {
    setPatients((prev) =>
      prev.map((p) => (p.id === id || p.patientId === id ? { ...p, ...updates } : p))
    );
    addToast('Patient Updated', 'Patient details updated.', 'success');
    logActivity('Patient Updated', 'Patients', `Updated details for ID: ${id}`);
  };

  const deletePatient = (id: string) => {
    const target = patients.find((p) => p.id === id || p.patientId === id);
    setPatients((prev) => prev.filter((p) => p.id !== id && p.patientId !== id));
    addToast('Patient Removed', `${target?.name || 'Patient'} record deleted.`, 'warning');
    logActivity('Patient Deleted', 'Patients', `Deleted record for ${target?.name || id}`);
  };

  // ----------------- DOCTOR ACTIONS -----------------
  const addDoctor = (docData: Omit<Doctor, 'id' | 'doctorId'>): Doctor => {
    const newId = `DOC-${100 + doctors.length + 1}`;
    const newDoctor: Doctor = {
      ...docData,
      id: `doc-${Date.now()}`,
      doctorId: newId,
    };
    setDoctors((prev) => [...prev, newDoctor]);
    addToast('Doctor Added', `${newDoctor.name} added to ${newDoctor.department}.`, 'success');
    logActivity('Doctor Added', 'Doctors', `Added ${newDoctor.name}`);
    return newDoctor;
  };

  const updateDoctor = (id: string, updates: Partial<Doctor>) => {
    setDoctors((prev) =>
      prev.map((d) => (d.id === id || d.doctorId === id ? { ...d, ...updates } : d))
    );
    addToast('Doctor Updated', 'Doctor profile updated.', 'success');
    logActivity('Doctor Updated', 'Doctors', `Updated doctor ${id}`);
  };

  const deleteDoctor = (id: string) => {
    const target = doctors.find((d) => d.id === id || d.doctorId === id);
    setDoctors((prev) => prev.filter((d) => d.id !== id && d.doctorId !== id));
    addToast('Doctor Removed', `${target?.name || 'Doctor'} removed.`, 'warning');
    logActivity('Doctor Deleted', 'Doctors', `Deleted doctor ${target?.name || id}`);
  };

  const toggleDoctorAvailability = (id: string, status: Doctor['availability']) => {
    setDoctors((prev) =>
      prev.map((d) => (d.id === id || d.doctorId === id ? { ...d, availability: status } : d))
    );
    addToast('Availability Changed', `Doctor status set to ${status}.`, 'info');
  };

  // ----------------- APPOINTMENT ACTIONS -----------------
  const bookAppointment = (apptData: Omit<Appointment, 'id' | 'appointmentId' | 'createdAt'>): Appointment => {
    const newId = `APP-${2000 + appointments.length + 1}`;
    const newAppt: Appointment = {
      ...apptData,
      id: `app-${Date.now()}`,
      appointmentId: newId,
      createdAt: new Date().toISOString(),
    };
    setAppointments((prev) => [newAppt, ...prev]);
    addToast('Appointment Booked', `Booked for ${newAppt.patientName} on ${newAppt.date} at ${newAppt.time}`, 'success');
    logActivity('Appointment Booked', 'Appointments', `Booked with ${newAppt.doctorName} for ${newAppt.patientName}`);

    // Push notification
    const notif: HospitalNotification = {
      id: `notif-${Date.now()}`,
      title: 'New Appointment',
      message: `${newAppt.patientName} booked with ${newAppt.doctorName} on ${newAppt.date} at ${newAppt.time}.`,
      type: 'appointment',
      timestamp: 'Just now',
      read: false,
      actionRoute: '/appointments',
      severity: 'info',
    };
    setNotifications((prev) => [notif, ...prev]);

    return newAppt;
  };

  const updateAppointment = (id: string, updates: Partial<Appointment>) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id || a.appointmentId === id ? { ...a, ...updates } : a))
    );
    addToast('Appointment Updated', 'Appointment details modified.', 'success');
    logActivity('Appointment Updated', 'Appointments', `Updated appointment ${id}`);
  };

  const cancelAppointment = (id: string, reason?: string) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === id || a.appointmentId === id
          ? { ...a, status: 'Cancelled' as AppointmentStatus, notes: reason || a.notes }
          : a
      )
    );
    addToast('Appointment Cancelled', 'The appointment was marked as cancelled.', 'warning');
    logActivity('Appointment Cancelled', 'Appointments', `Cancelled appointment ID ${id}`);
  };

  const completeAppointment = (id: string) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === id || a.appointmentId === id
          ? { ...a, status: 'Completed' as AppointmentStatus }
          : a
      )
    );
    addToast('Appointment Completed', 'Consultation marked as completed.', 'success');
    logActivity('Appointment Completed', 'Appointments', `Completed consultation ${id}`);
  };

  const deleteAppointment = (id: string) => {
    setAppointments((prev) => prev.filter((a) => a.id !== id && a.appointmentId !== id));
    addToast('Appointment Deleted', 'Appointment record removed.', 'info');
  };

  // ----------------- ADMISSIONS & BEDS -----------------
  const admitPatient = (
    patientIdOrData: any,
    bedId?: string,
    doctorInCharge?: string,
    diagnosis?: string,
    deposit?: number
  ): Admission => {
    let newAdmission: Admission;
    if (typeof patientIdOrData === 'object' && patientIdOrData !== null) {
      const data = patientIdOrData;
      const targetBed = beds.find((b) => b.id === data.bedId || b.bedNumber === data.bedNumber);
      const targetPatient = patients.find((p) => p.id === data.patientId || p.patientId === data.patientId);

      const newId = `ADM-${3000 + admissions.length + 1}`;
      newAdmission = {
        id: `adm-${Date.now()}`,
        admissionId: newId,
        patientId: targetPatient?.id || data.patientId,
        patientName: targetPatient?.name || data.patientName || 'Inpatient',
        bedId: targetBed?.id || data.bedId,
        bedNumber: targetBed?.bedNumber || data.bedNumber || 'BED-XX',
        ward: targetBed?.ward || data.ward || 'General',
        admitDate: data.admissionDate || new Date().toISOString().split('T')[0],
        status: 'Admitted',
        doctorInCharge: data.doctorName || data.doctorInCharge || 'Dr. On Duty',
        diagnosis: data.admissionReason || data.diagnosis || 'General',
        emergencyContact: targetPatient?.emergencyContact?.phone || '',
        initialDeposit: Number(data.initialDeposit || 0),
      };

      if (targetBed) {
        setBeds((prev) =>
          prev.map((b) =>
            b.id === targetBed.id
              ? {
                  ...b,
                  status: 'Occupied' as BedStatus,
                  currentPatientId: targetPatient?.id || data.patientId,
                  currentPatientName: targetPatient?.name || data.patientName,
                  admittedDate: newAdmission.admitDate,
                }
              : b
          )
        );
      }
      if (targetPatient) {
        updatePatient(targetPatient.id, { status: 'Inpatient' });
      }
    } else {
      const patientId = patientIdOrData;
      const patient = patients.find((p) => p.id === patientId || p.patientId === patientId);
      const bed = beds.find((b) => b.id === bedId || b.bedNumber === bedId);

      const newId = `ADM-${3000 + admissions.length + 1}`;
      newAdmission = {
        id: `adm-${Date.now()}`,
        admissionId: newId,
        patientId: patient?.id || patientId,
        patientName: patient?.name || 'Inpatient',
        bedId: bed?.id || bedId,
        bedNumber: bed?.bedNumber || 'BED-XX',
        ward: bed?.ward || 'General',
        admitDate: new Date().toISOString().split('T')[0],
        status: 'Admitted',
        doctorInCharge: doctorInCharge || 'Dr. On Duty',
        diagnosis: diagnosis || 'General',
        emergencyContact: patient?.emergencyContact?.phone || '',
        initialDeposit: deposit || 0,
      };

      if (bed) {
        setBeds((prev) =>
          prev.map((b) =>
            b.id === bed.id
              ? {
                  ...b,
                  status: 'Occupied' as BedStatus,
                  currentPatientId: patient?.id || patientId,
                  currentPatientName: patient?.name,
                  admittedDate: newAdmission.admitDate,
                }
              : b
          )
        );
      }
      if (patient) {
        updatePatient(patient.id, { status: 'Inpatient' });
      }
    }

    setAdmissions((prev) => [newAdmission, ...prev]);
    addToast('Patient Admitted', `${newAdmission.patientName} admitted to ${newAdmission.bedNumber} (${newAdmission.ward})`, 'success');
    logActivity('Patient Admitted', 'Admissions', `Admitted ${newAdmission.patientName} to ${newAdmission.bedNumber}`);
    return newAdmission;
  };

  const addBed = (bedData: Omit<Bed, 'id' | 'bedId'>): Bed => {
    const newId = `bed-${Date.now()}`;
    const newBed: Bed = {
      ...bedData,
      id: newId,
      bedNumber: bedData.bedNumber || `BED-${100 + beds.length + 1}`,
    };
    setBeds((prev) => [...prev, newBed]);
    addToast('Bed Added', `Bed ${newBed.bedNumber} added.`, 'success');
    logActivity('Add Bed', 'Bed Management', `Added bed ${newBed.bedNumber}`);
    return newBed;
  };

  const addDepartment = (deptData: Omit<Department, 'id' | 'departmentId'>): Department => {
    const newId = `dept-${Date.now()}`;
    const newDept: Department = {
      ...deptData,
      id: newId,
      code: deptData.code || deptData.name.slice(0, 3).toUpperCase(),
    };
    setDepartments((prev) => [...prev, newDept]);
    addToast('Department Added', `Department ${newDept.name} added.`, 'success');
    logActivity('Add Department', 'Departments', `Created department ${newDept.name}`);
    return newDept;
  };

  const updateDepartment = (id: string, updates: Partial<Department>) => {
    setDepartments((prev) =>
      prev.map((d) => (d.id === id || d.code === id ? { ...d, ...updates } : d))
    );
    addToast('Department Updated', 'Department details updated.', 'info');
  };

  const dischargePatient = (admissionId: string) => {
    const admission = admissions.find((a) => a.id === admissionId || a.admissionId === admissionId);
    if (!admission) return;

    // Update admission record
    setAdmissions((prev) =>
      prev.map((a) =>
        a.id === admissionId || a.admissionId === admissionId
          ? {
              ...a,
              status: 'Discharged',
              dischargeDate: new Date().toISOString().split('T')[0],
            }
          : a
      )
    );

    // Free the bed
    setBeds((prev) =>
      prev.map((b) =>
        b.id === admission.bedId || b.bedNumber === admission.bedNumber
          ? {
              ...b,
              status: 'Available' as BedStatus,
              currentPatientId: undefined,
              currentPatientName: undefined,
              admittedDate: undefined,
            }
          : b
      )
    );

    // Update patient status to discharged
    updatePatient(admission.patientId, { status: 'Discharged' });
    addToast('Patient Discharged', `${admission.patientName} discharged from ${admission.bedNumber}. Bed is now available.`, 'success');
    logActivity('Patient Discharged', 'Admissions', `Discharged ${admission.patientName}`);
  };

  const transferBed = (admissionId: string, newBedId: string) => {
    const admission = admissions.find((a) => a.id === admissionId || a.admissionId === admissionId);
    const targetBed = beds.find((b) => b.id === newBedId || b.bedNumber === newBedId);
    if (!admission || !targetBed) return;

    const oldBedId = admission.bedId;

    // Free old bed
    setBeds((prev) =>
      prev.map((b) => {
        if (b.id === oldBedId || b.bedNumber === admission.bedNumber) {
          return {
            ...b,
            status: 'Available' as BedStatus,
            currentPatientId: undefined,
            currentPatientName: undefined,
            admittedDate: undefined,
          };
        }
        if (b.id === newBedId || b.bedNumber === targetBed.bedNumber) {
          return {
            ...b,
            status: 'Occupied' as BedStatus,
            currentPatientId: admission.patientId,
            currentPatientName: admission.patientName,
            admittedDate: admission.admitDate,
          };
        }
        return b;
      })
    );

    // Update admission record
    setAdmissions((prev) =>
      prev.map((a) =>
        a.id === admissionId || a.admissionId === admissionId
          ? {
              ...a,
              bedId: targetBed.id,
              bedNumber: targetBed.bedNumber,
              ward: targetBed.ward,
            }
          : a
      )
    );

    addToast('Bed Transferred', `Transferred ${admission.patientName} to ${targetBed.bedNumber} (${targetBed.ward})`, 'info');
    logActivity('Bed Transfer', 'Bed Management', `Transferred ${admission.patientName} to ${targetBed.bedNumber}`);
  };

  const updateBedStatus = (bedId: string, status: BedStatus, notes?: string) => {
    setBeds((prev) =>
      prev.map((b) =>
        b.id === bedId || b.bedNumber === bedId
          ? {
              ...b,
              status,
              notes: notes !== undefined ? notes : b.notes,
            }
          : b
      )
    );
    addToast('Bed Status Changed', `Bed ${bedId} set to ${status}.`, 'info');
  };

  // ----------------- BILLING ACTIONS -----------------
  const createInvoice = (
    invData: Omit<Invoice, 'id' | 'invoiceId' | 'taxAmount' | 'total' | 'remainingAmount' | 'status'>
  ): Invoice => {
    const newId = `INV-${4000 + invoices.length + 1}`;
    const subtotal = invData.items.reduce((sum, itm) => sum + (itm.quantity * itm.unitPrice), 0);
    const taxAmount = (subtotal * (invData.taxRate || 5)) / 100;
    const discount = invData.discount || 0;
    const total = Math.max(0, subtotal + taxAmount - discount);
    const paidAmount = invData.paidAmount || 0;
    const remainingAmount = Math.max(0, total - paidAmount);

    let status: InvoiceStatus = 'Pending';
    if (remainingAmount === 0 && total > 0) {
      status = 'Paid';
    } else if (paidAmount > 0) {
      status = 'Partially Paid';
    }

    const newInvoice: Invoice = {
      ...invData,
      id: `inv-${Date.now()}`,
      invoiceId: newId,
      subtotal,
      taxRate: invData.taxRate || 5,
      taxAmount,
      discount,
      total,
      paidAmount,
      remainingAmount,
      status,
    };

    setInvoices((prev) => [newInvoice, ...prev]);
    addToast('Invoice Created', `Invoice ${newId} created for ${newInvoice.patientName} (Total: ₹${total.toLocaleString()})`, 'success');
    logActivity('Invoice Created', 'Billing', `Generated ${newId} for ${newInvoice.patientName}`);
    return newInvoice;
  };

  const updateInvoice = (id: string, updates: Partial<Invoice>) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === id || inv.invoiceId === id) {
          const subtotal = updates.items ? updates.items.reduce((sum, itm) => sum + (itm.quantity * itm.unitPrice), 0) : (updates.subtotal ?? inv.subtotal);
          const taxRate = updates.taxRate ?? inv.taxRate;
          const taxAmount = (subtotal * taxRate) / 100;
          const discount = updates.discount ?? inv.discount;
          const total = Math.max(0, subtotal + taxAmount - discount);
          const paidAmount = updates.paidAmount ?? inv.paidAmount;
          const remainingAmount = Math.max(0, total - paidAmount);

          let status: InvoiceStatus = 'Pending';
          if (remainingAmount === 0 && total > 0) {
            status = 'Paid';
          } else if (paidAmount > 0) {
            status = 'Partially Paid';
          }

          return {
            ...inv,
            ...updates,
            subtotal,
            taxAmount,
            total,
            remainingAmount,
            status,
          };
        }
        return inv;
      })
    );
    addToast('Invoice Updated', 'Invoice calculations refreshed.', 'success');
  };

  const recordPayment = (id: string, amount: number, paymentMethod: Invoice['paymentMethod']) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === id || inv.invoiceId === id) {
          const newPaid = Math.min(inv.total, inv.paidAmount + amount);
          const remaining = Math.max(0, inv.total - newPaid);
          const status: InvoiceStatus = remaining === 0 ? 'Paid' : 'Partially Paid';

          return {
            ...inv,
            paidAmount: newPaid,
            remainingAmount: remaining,
            status,
            paymentMethod: paymentMethod || inv.paymentMethod,
            paymentDate: new Date().toISOString().split('T')[0],
          };
        }
        return inv;
      })
    );
    addToast('Payment Recorded', `Payment of ₹${amount.toLocaleString()} received.`, 'success');
    logActivity('Payment Received', 'Billing', `Recorded payment of ₹${amount} for invoice ${id}`);
  };

  const deleteInvoice = (id: string) => {
    setInvoices((prev) => prev.filter((inv) => inv.id !== id && inv.invoiceId !== id));
    addToast('Invoice Deleted', 'Invoice deleted.', 'warning');
    logActivity('Invoice Deleted', 'Billing', `Deleted invoice ID ${id}`);
  };

  // ----------------- PHARMACY ACTIONS -----------------
  const addMedicine = (medData: Omit<Medicine, 'id' | 'medicineId'>): Medicine => {
    const newId = `MED-${5000 + medicines.length + 1}`;
    const newMed: Medicine = {
      ...medData,
      id: `med-${Date.now()}`,
      medicineId: newId,
    };
    setMedicines((prev) => [...prev, newMed]);
    addToast('Medicine Added', `${newMed.name} added to pharmacy inventory.`, 'success');
    logActivity('Medicine Added', 'Pharmacy', `Added ${newMed.name} (${newId})`);
    return newMed;
  };

  const updateMedicine = (id: string, updates: Partial<Medicine>) => {
    setMedicines((prev) =>
      prev.map((m) => (m.id === id || m.medicineId === id ? { ...m, ...updates } : m))
    );
    addToast('Medicine Updated', 'Inventory stock record updated.', 'success');
  };

  const updateMedicineStock = (id: string, deltaQuantity: number) => {
    setMedicines((prev) =>
      prev.map((m) => {
        if (m.id === id || m.medicineId === id) {
          const newQty = Math.max(0, m.stockQuantity + deltaQuantity);
          return { ...m, stockQuantity: newQty };
        }
        return m;
      })
    );
    addToast('Stock Adjusted', 'Medicine stock quantity updated.', 'info');
  };

  const deleteMedicine = (id: string) => {
    const target = medicines.find((m) => m.id === id || m.medicineId === id);
    setMedicines((prev) => prev.filter((m) => m.id !== id && m.medicineId !== id));
    addToast('Medicine Removed', `${target?.name || 'Medicine'} removed from inventory.`, 'warning');
    logActivity('Medicine Deleted', 'Pharmacy', `Deleted ${target?.name || id}`);
  };

  // ----------------- LABORATORY ACTIONS -----------------
  const addLabTest = (testData: Omit<LabTest, 'id' | 'testId'>): LabTest => {
    const newId = `LAB-${6000 + labTests.length + 1}`;
    const newTest: LabTest = {
      ...testData,
      id: `lab-${Date.now()}`,
      testId: newId,
    };
    setLabTests((prev) => [newTest, ...prev]);
    addToast('Lab Test Ordered', `${newTest.testName} ordered for ${newTest.patientName}`, 'success');
    logActivity('Lab Test Ordered', 'Laboratory', `Ordered ${newTest.testName} for ${newTest.patientName}`);
    return newTest;
  };

  const updateLabTestStatus = (
    id: string,
    status: LabTestStatus,
    results?: LabTest['results'],
    notes?: string
  ) => {
    setLabTests((prev) =>
      prev.map((t) => {
        if (t.id === id || t.testId === id) {
          const updates: Partial<LabTest> = { status };
          if (status === 'Sample Collected' && !t.sampleCollectionDate) {
            updates.sampleCollectionDate = new Date().toISOString().split('T')[0];
          }
          if (status === 'Completed') {
            updates.completionDate = new Date().toISOString().split('T')[0];
          }
          if (results) updates.results = results;
          if (notes) updates.notes = notes;
          return { ...t, ...updates };
        }
        return t;
      })
    );
    addToast('Lab Test Status Updated', `Status changed to ${status}.`, 'info');
    logActivity('Lab Test Updated', 'Laboratory', `Updated test ${id} to ${status}`);
  };

  const orderLabTest = (testData: Omit<LabTest, 'id' | 'testId'>): LabTest => addLabTest(testData);

  const updateLabTestResult = (id: string, resultOrStatus: any, notes?: string) => {
    if (typeof resultOrStatus === 'string') {
      const isStatus = ['Requested', 'Sample Collected', 'Processing', 'Completed', 'Pending', 'In Progress'].includes(resultOrStatus);
      if (isStatus) {
        updateLabTestStatus(id, resultOrStatus as LabTestStatus, undefined, notes);
      } else {
        setLabTests((prev) =>
          prev.map((t) => (t.id === id || t.testId === id ? { ...t, result: resultOrStatus, status: 'Completed', notes } : t))
        );
        addToast('Lab Result Uploaded', 'Diagnostic result saved.', 'success');
      }
    }
  };

  const deleteLabTest = (id: string) => {
    setLabTests((prev) => prev.filter((t) => t.id !== id && t.testId !== id));
    addToast('Lab Test Deleted', 'Lab test record removed.', 'info');
  };

  // ----------------- PRESCRIPTIONS & MEDICAL RECORDS -----------------
  const addPrescription = (rxData: Omit<Prescription, 'id' | 'prescriptionId'>): Prescription => {
    const newId = `RX-${7000 + prescriptions.length + 1}`;
    const newRx: Prescription = {
      ...rxData,
      id: `rx-${Date.now()}`,
      prescriptionId: newId,
    };
    setPrescriptions((prev) => [newRx, ...prev]);
    addToast('Prescription Written', `Prescription ${newId} created for ${newRx.patientName}`, 'success');
    logActivity('Prescription Generated', 'Prescriptions', `Created ${newId} for ${newRx.patientName}`);
    return newRx;
  };

  const deletePrescription = (id: string) => {
    setPrescriptions((prev) => prev.filter((rx) => rx.id !== id && rx.prescriptionId !== id));
    addToast('Prescription Deleted', 'Prescription record deleted.', 'warning');
  };

  const addMedicalRecord = (recData: Omit<MedicalRecord, 'id' | 'recordId'>): MedicalRecord => {
    const newId = `MR-${8000 + medicalRecords.length + 1}`;
    const newRec: MedicalRecord = {
      ...recData,
      id: `mr-${Date.now()}`,
      recordId: newId,
    };
    setMedicalRecords((prev) => [newRec, ...prev]);
    addToast('Medical Record Saved', `Medical record ${newId} added for ${newRec.patientName}`, 'success');
    logActivity('Medical Record Added', 'Medical Records', `Added ${newId} for ${newRec.patientName}`);
    return newRec;
  };

  const deleteMedicalRecord = (id: string) => {
    setMedicalRecords((prev) => prev.filter((r) => r.id !== id && r.recordId !== id));
    addToast('Record Deleted', 'Medical record removed.', 'info');
  };

  // ----------------- STAFF ACTIONS -----------------
  const addStaff = (staffData: Omit<StaffMember, 'id' | 'staffId'>): StaffMember => {
    const newId = `STF-${9000 + staff.length + 1}`;
    const newStaff: StaffMember = {
      ...staffData,
      id: `stf-${Date.now()}`,
      staffId: newId,
    };
    setStaff((prev) => [...prev, newStaff]);
    addToast('Staff Registered', `${newStaff.name} joined as ${newStaff.role}.`, 'success');
    logActivity('Staff Joined', 'Staff Management', `Added ${newStaff.name} (${newStaff.role})`);
    return newStaff;
  };

  const updateStaff = (id: string, updates: Partial<StaffMember>) => {
    setStaff((prev) =>
      prev.map((s) => (s.id === id || s.staffId === id ? { ...s, ...updates } : s))
    );
    addToast('Staff Updated', 'Staff details updated.', 'success');
  };

  const deleteStaff = (id: string) => {
    const target = staff.find((s) => s.id === id || s.staffId === id);
    setStaff((prev) => prev.filter((s) => s.id !== id && s.staffId !== id));
    addToast('Staff Removed', `${target?.name || 'Staff'} record deleted.`, 'warning');
    logActivity('Staff Deleted', 'Staff Management', `Removed ${target?.name || id}`);
  };

  // ----------------- NOTIFICATIONS -----------------
  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    addToast('Notifications Cleared', 'All notifications marked as read.', 'info');
  };

  const clearNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  // ----------------- RESET DEMO DATA -----------------
  const resetAllData = () => {
    setPatients(initialPatients);
    setDoctors(initialDoctors);
    setAppointments(initialAppointments);
    setDepartments(initialDepartments);
    setBeds(initialBeds);
    setAdmissions(initialAdmissions);
    setInvoices(initialInvoices);
    setMedicines(initialMedicines);
    setLabTests(initialLabTests);
    setPrescriptions(initialPrescriptions);
    setMedicalRecords(initialMedicalRecords);
    setStaff(initialStaff);
    setNotifications(initialNotifications);
    setActivities(initialActivities);
    setSettingsState(initialHospitalSettings);
    addToast('Reset Complete', 'Default demo hospital dataset successfully restored!', 'success');
    logActivity('System Reset', 'Settings', 'Restored initial hospital sample dataset');
  };

  return (
    <HospitalContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        setTheme,
        toggleTheme,
        user,
        setUser,
        isAuthenticated,
        login,
        logout,
        settings,
        updateSettings,
        patients,
        doctors,
        appointments,
        departments,
        beds,
        admissions,
        invoices,
        medicines,
        labTests,
        prescriptions,
        medicalRecords,
        staff,
        notifications,
        activities,
        toasts,
        addToast,
        removeToast,
        addPatient,
        updatePatient,
        deletePatient,
        addDoctor,
        updateDoctor,
        deleteDoctor,
        toggleDoctorAvailability,
        bookAppointment,
        updateAppointment,
        cancelAppointment,
        completeAppointment,
        deleteAppointment,
        admitPatient,
        dischargePatient,
        transferBed,
        addBed,
        updateBedStatus,
        addDepartment,
        updateDepartment,
        createInvoice,
        updateInvoice,
        recordPayment,
        deleteInvoice,
        addMedicine,
        updateMedicine,
        updateMedicineStock,
        deleteMedicine,
        addLabTest,
        orderLabTest,
        updateLabTestStatus,
        updateLabTestResult,
        deleteLabTest,
        addPrescription,
        deletePrescription,
        addMedicalRecord,
        deleteMedicalRecord,
        addStaff,
        updateStaff,
        deleteStaff,
        markNotificationRead,
        markAllNotificationsRead,
        clearNotification,
        markNotificationAsRead: markNotificationRead,
        markAllNotificationsAsRead: markAllNotificationsRead,
        clearAllNotifications: () => setNotifications([]),
        darkMode: theme === 'dark',
        setDarkMode: (dark: boolean) => setTheme(dark ? 'dark' : 'light'),
        resetToDemoData: resetAllData,
        addStaffMember: addStaff,
        updateStaffMember: updateStaff,
        deleteStaffMember: deleteStaff,
        resetAllData,
        logActivity,
      }}
    >
      {children}
    </HospitalContext.Provider>
  );
};

export const useHospital = (): HospitalContextType => {
  const context = useContext(HospitalContext);
  if (!context) {
    throw new Error('useHospital must be used within a HospitalProvider');
  }
  return context;
};

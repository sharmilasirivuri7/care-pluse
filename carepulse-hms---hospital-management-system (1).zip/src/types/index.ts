export type Language = 'en' | 'te' | 'hi';
export type Theme = 'light' | 'dark';
export type DepartmentType = string;

export type UserRole = 'admin' | 'doctor' | 'nurse' | 'receptionist' | 'pharmacist' | 'lab_technician';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department?: string;
  phone: string;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
export type Gender = 'Male' | 'Female' | 'Other';
export type PatientStatus = 'Outpatient' | 'Inpatient' | 'Discharged' | 'Emergency' | 'Critical';

export interface Patient {
  id: string;
  patientId: string; // e.g. PAT-1001
  name: string;
  age: number;
  gender: Gender;
  dob: string;
  phone: string;
  email: string;
  address: string;
  bloodGroup: BloodGroup;
  emergencyContact: {
    name: string;
    relation: string;
    phone: string;
  };
  emergencyPhone?: string;
  medicalHistory: string[];
  allergies: string[];
  assignedDoctorId?: string;
  assignedDoctorName?: string;
  department: string;
  status: PatientStatus;
  createdAt: string;
  registeredDate?: string;
  lastVisit?: string;
}

export interface Doctor {
  id: string;
  doctorId: string; // DOC-101
  name: string;
  specialization: string;
  department: string;
  qualification: string;
  experience: number; // years
  experienceYears?: number;
  phone: string;
  email: string;
  consultationFee: number;
  availability: 'Available' | 'In Surgery' | 'On Leave' | 'Busy';
  scheduleDays: string[];
  scheduleTime: string;
  schedule?: string;
  avatar?: string;
  image?: string;
  roomNumber: string;
}

export type AppointmentStatus = 'Pending' | 'Scheduled' | 'Confirmed' | 'Completed' | 'Cancelled';

export interface Appointment {
  id: string;
  appointmentId: string; // APP-2001
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  department: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  reason: string;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  headDoctor: string;
  headOfDepartment?: string;
  totalDoctors: number;
  doctorCount?: number;
  totalBeds: number;
  occupiedBeds: number;
  description: string;
  icon: string;
  floor: string;
  contactNumber?: string;
}

export type BedStatus = 'Available' | 'Occupied' | 'Reserved' | 'Maintenance';
export type BedType = 'General' | 'ICU' | 'Semi-Private' | 'Private VIP' | 'Emergency';

export interface Bed {
  id: string;
  bedNumber: string; // e.g. ICU-01, GEN-104
  ward: string; // e.g. "Cardiology ICU", "General Ward A"
  type: BedType;
  department: string;
  floor: string;
  status: BedStatus;
  dailyRate: number;
  pricePerDay?: number;
  currentPatientId?: string;
  patientId?: string;
  currentPatientName?: string;
  patientName?: string;
  admittedDate?: string;
  notes?: string;
}

export interface Admission {
  id: string;
  admissionId: string; // ADM-3001
  patientId: string;
  patientName: string;
  bedId: string;
  bedNumber: string;
  ward: string;
  admitDate: string;
  admissionDate?: string;
  dischargeDate?: string;
  status: 'Admitted' | 'Discharged' | 'Transferred';
  doctorInCharge: string;
  doctorName?: string;
  department?: string;
  diagnosis: string;
  emergencyContact: string;
  initialDeposit: number;
}

export type InvoiceStatus = 'Paid' | 'Partially Paid' | 'Pending';

export interface InvoiceItem {
  id: string;
  description: string;
  category: 'Consultation' | 'Bed Charge' | 'Medication' | 'Lab Test' | 'Surgery' | 'Nursing' | 'Other';
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceId: string; // INV-4001
  patientId: string;
  patientName: string;
  patientPhone: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number; // percentage, e.g. 5%
  taxAmount: number;
  discount: number; // flat amount
  total: number;
  paidAmount: number;
  remainingAmount: number;
  status: InvoiceStatus;
  paymentMethod?: 'Cash' | 'Credit Card' | 'Debit Card' | 'Insurance' | 'UPI / Online';
  paymentDate?: string;
}

export interface Medicine {
  id: string;
  medicineId: string; // MED-5001
  name: string;
  genericName: string;
  category: 'Antibiotics' | 'Analgesics' | 'Cardiovascular' | 'Antidiabetic' | 'Antiviral' | 'Respiratory' | 'Vitamins' | 'Other';
  manufacturer: string;
  batchNumber: string;
  expiryDate: string; // YYYY-MM-DD
  stockQuantity: number;
  minThreshold: number; // low stock alert if below this
  unitPrice: number;
  location: string; // Shelf A-3
  dosageForm: 'Tablet' | 'Capsule' | 'Syrup' | 'Injection' | 'Ointment' | 'IV Fluid';
  // Optional convenience aliases
  stock?: number;
  reorderLevel?: number;
  pricePerUnit?: number;
  unit?: string;
  status?: 'In Stock' | 'Low Stock' | 'Out of Stock';
}

export type LabTestStatus = 'Requested' | 'Sample Collected' | 'Processing' | 'Completed' | 'Pending' | 'In Progress';

export interface LabTest {
  id: string;
  testId: string; // LAB-6001
  testName: string;
  category: 'Hematology' | 'Biochemistry' | 'Microbiology' | 'Radiology' | 'Pathology' | 'Cardiology';
  patientId: string;
  patientName: string;
  doctorId?: string;
  doctorName: string;
  requestDate?: string;
  orderDate?: string;
  sampleCollectionDate?: string;
  completionDate?: string;
  reportDate?: string;
  sampleType?: string;
  status: LabTestStatus;
  price: number;
  results?: {
    parameter: string;
    value: string;
    referenceRange: string;
    unit: string;
    isAbnormal: boolean;
  }[];
  result?: string;
  normalRange?: string;
  notes?: string;
  technicianName?: string;
}

export interface PrescriptionItem {
  id: string;
  medicineName: string;
  dosage: string; // e.g. "500mg"
  frequency: string; // e.g. "1-0-1 (Twice daily after food)"
  duration: string; // e.g. "5 Days"
  instructions: string; // e.g. "Take with warm water"
}

export type PrescribedMedicine = PrescriptionItem;

export interface Prescription {
  id: string;
  prescriptionId: string; // RX-7001
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: Gender;
  doctorId: string;
  doctorName: string;
  doctorQualification?: string;
  doctorSpecialization?: string;
  department?: string;
  date: string;
  diagnosis: string;
  symptoms?: string[] | string;
  medicines: PrescriptionItem[];
  advice: string;
  nextFollowUp?: string;
  followUpDate?: string;
}

export interface MedicalRecord {
  id: string;
  recordId: string; // MR-8001
  patientId: string;
  patientName: string;
  date: string;
  doctorId?: string;
  doctorName: string;
  department: string;
  chiefComplaint?: string;
  symptoms?: string;
  diagnosis: string;
  clinicalNotes?: string;
  notes?: string;
  treatment?: string;
  attachments?: string[];
  vitalSigns?: {
    bloodPressure: string; // e.g. "120/80 mmHg"
    pulseRate: number; // bpm
    temperature: number; // °F
    spO2: number; // %
    weight?: number; // kg
    height?: number; // cm
  };
  vitals?: {
    bloodPressure?: string;
    heartRate?: string;
    temperature?: string;
    spo2?: string;
  };
  treatmentPlan?: string;
  labReportIds?: string[];
  prescriptionId?: string;
}

export interface StaffMember {
  id: string;
  staffId: string; // STF-9001
  name: string;
  role: 'Nurse' | 'Receptionist' | 'Pharmacist' | 'Lab Technician' | 'Admin' | 'Accountant' | 'Ward Boy';
  department: string;
  phone: string;
  email: string;
  joinDate: string;
  shift: 'Morning' | 'Evening' | 'Night' | 'Rotational' | string;
  status: 'Active' | 'On Leave' | 'Inactive';
  salary: number;
  avatar?: string;
  image?: string;
}

export interface HospitalNotification {
  id: string;
  title: string;
  message: string;
  type: 'appointment' | 'billing' | 'pharmacy' | 'bed' | 'lab' | 'emergency';
  timestamp: string;
  time?: string;
  read: boolean;
  actionRoute?: string;
  link?: string;
  severity: 'info' | 'warning' | 'success' | 'danger';
}

export interface ActivityLog {
  id: string;
  user: string;
  action: string;
  module: string;
  timestamp: string;
  details: string;
}

export interface HospitalSettings {
  hospitalName: string;
  tagline: string;
  address: string;
  phone: string;
  emergencyPhone: string;
  email: string;
  taxRate: number;
  currencySymbol: string;
  enableVoiceAssistant: boolean;
  enableAutoNotifications: boolean;
  defaultLanguage: Language;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: {
    label: string;
    route?: string;
    actionType?: string;
    payload?: any;
  }[];
  dataPayload?: any;
  isConfirmation?: boolean;
  pendingAction?: {
    actionType: string;
    targetId: string;
    description: string;
  };
}

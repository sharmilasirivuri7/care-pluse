import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Activity,
  Lock,
  Mail,
  ArrowRight,
  ShieldCheck,
  Globe,
  UserCheck,
  Stethoscope,
  Building,
  KeyRound,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation, Language } from '../i18n/translations';

export const LoginPage: React.FC = () => {
  const { language, setLanguage, addToast } = useHospital();
  const t = useTranslation(language);
  const navigate = useNavigate();

  const [email, setEmail] = useState('dr.sathyaprakash@medicoverhospitals.in');
  const [password, setPassword] = useState('medicover2026');
  const [selectedRole, setSelectedRole] = useState<'Doctor' | 'Admin' | 'Nurse' | 'Receptionist'>('Admin');
  const [isLoading, setIsLoading] = useState(false);

  const demoAccounts = [
    { role: 'Admin', name: 'Dr. Sathya Prakash', email: 'dr.sathyaprakash@medicoverhospitals.in', title: 'Medical Director & Chief Physician' },
    { role: 'Doctor', name: 'Dr. Ananya Roy', email: 'dr.ananya@medicoverhospitals.in', title: 'Senior Cardiologist' },
    { role: 'Nurse', name: 'Sister Sunita Rao', email: 'sunita.rao@medicoverhospitals.in', title: 'Senior ICU Incharge' },
    { role: 'Receptionist', name: 'Kavitha Devi', email: 'kavitha@medicoverhospitals.in', title: 'Front Desk OPD' },
  ];

  const handleQuickSelect = (acc: typeof demoAccounts[0]) => {
    setEmail(acc.email);
    setPassword('medicover2026');
    setSelectedRole(acc.role as any);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      addToast('Welcome to Medicover Hospital', `Signed in as ${selectedRole} (${email}).`, 'success');
      navigate('/');
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Graphic Accents */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar with Language Selector */}
      <header className="p-6 flex items-center justify-between max-w-7xl mx-auto w-full z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500 flex items-center justify-center text-white shadow-lg shadow-teal-500/20 font-black text-xl">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="font-extrabold text-lg tracking-tight text-white block">
              Medicover Hospital
            </span>
            <span className="text-[10px] text-teal-400 font-semibold tracking-wider uppercase">
              Hospital Management System
            </span>
          </div>
        </div>

        {/* Language Select */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700">
          {[
            { code: 'en', label: 'English' },
            { code: 'te', label: 'తెలుగు' },
            { code: 'hi', label: 'हिन्दी' },
          ].map((lang) => (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code as Language)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                language === lang.code
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Login Card */}
      <main className="flex-1 flex items-center justify-center p-4 z-10 my-6">
        <div className="w-full max-w-md bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/50">
          <div className="mb-6 text-center">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Hospital Portal Sign-In
            </h1>
            <p className="text-xs text-slate-400 mt-1.5">
              Secure electronic health records & administrative access
            </p>
          </div>

          {/* 1-Click Demo Profiles */}
          <div className="mb-6">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Quick 1-Click Role Login
            </span>
            <div className="grid grid-cols-2 gap-2">
              {demoAccounts.map((acc) => (
                <button
                  key={acc.role}
                  type="button"
                  onClick={() => handleQuickSelect(acc)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    email === acc.email
                      ? 'bg-teal-500/20 border-teal-500 text-teal-300'
                      : 'bg-slate-900/60 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="font-bold text-xs flex items-center justify-between">
                    <span>{acc.role}</span>
                    {email === acc.email && <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">{acc.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Staff Email ID</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-slate-700 rounded-xl text-white focus:border-teal-500 focus:outline-none text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">Access Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-slate-700 rounded-xl text-white focus:border-teal-500 focus:outline-none text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 text-teal-500" />
                <span>Keep me signed in</span>
              </label>
              <a href="#reset" onClick={(e) => { e.preventDefault(); addToast('Reset link sent', 'Password reset instructions sent to registered admin mail.', 'info'); }} className="text-teal-400 hover:underline">
                Forgot password?
              </a>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 active:scale-[0.98] transition-all cursor-pointer mt-2"
            >
              {isLoading ? (
                <span>Authenticating Credentials...</span>
              ) : (
                <>
                  <span>Sign In to Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </main>

      {/* Footer Emergency info */}
      <footer className="p-4 text-center text-xs text-slate-500 border-t border-slate-800/80 z-10">
        <p>Medicover Healthcare ERP • NABH & HIPAA Compliant Hospital Information System</p>
        <p className="text-[11px] text-slate-400 mt-0.5">Emergency Helpline: +91 1800 425 3333 (24x7 Emergency Trauma Care)</p>
      </footer>
    </div>
  );
};

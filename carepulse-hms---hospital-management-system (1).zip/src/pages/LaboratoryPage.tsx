import React, { useState } from 'react';
import {
  FlaskConical,
  Search,
  Plus,
  FileCheck,
  Clock,
  AlertCircle,
  CheckCircle2,
  Printer,
  FileText,
  Activity,
  Microscope,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { LabTest } from '../types';
import { Modal } from '../components/common/Modal';

export const LaboratoryPage: React.FC = () => {
  const {
    language,
    labTests,
    patients,
    doctors,
    orderLabTest,
    updateLabTestResult,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  // Modals
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isResultModalOpen, setIsResultModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null);

  // New Test Order Form State
  const [orderForm, setOrderForm] = useState({
    patientId: patients[0]?.id || '',
    doctorId: doctors[0]?.id || '',
    testName: 'Complete Blood Count (CBC)',
    category: 'Hematology',
    sampleType: 'Blood (EDTA)',
    price: 450,
  });

  // Result Upload Form State
  const [resultForm, setResultForm] = useState({
    result: '',
    normalRange: '',
    notes: '',
  });

  // Lab Metrics
  const totalTests = labTests.length;
  const completedCount = labTests.filter((t) => t.status === 'Completed').length;
  const inProgressCount = labTests.filter((t) => t.status === 'In Progress' || t.status === 'Sample Collected').length;
  const pendingCount = labTests.filter((t) => t.status === 'Pending').length;

  const categories = Array.from(new Set(labTests.map((t) => t.category)));

  const filteredTests = labTests.filter((test) => {
    const matchesSearch =
      test.testName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.testId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.doctorName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || test.status === statusFilter;
    const matchesCat = categoryFilter === 'All' || test.category === categoryFilter;

    return matchesSearch && matchesStatus && matchesCat;
  });

  const handleOpenOrder = () => {
    setOrderForm({
      patientId: patients[0]?.id || '',
      doctorId: doctors[0]?.id || '',
      testName: 'Lipid Profile & Cholesterol Screen',
      category: 'Biochemistry',
      sampleType: 'Blood Serum (Fasting)',
      price: 850,
    });
    setIsOrderModalOpen(true);
  };

  const handleOpenResult = (test: LabTest) => {
    setSelectedTest(test);
    setResultForm({
      result: test.result || 'Total Cholesterol: 185 mg/dL, HDL: 48 mg/dL, LDL: 110 mg/dL',
      normalRange: test.normalRange || 'Cholesterol < 200 mg/dL',
      notes: test.notes || 'Specimen processed on automated analyzer. Normal limits observed.',
    });
    setIsResultModalOpen(true);
  };

  const handleOpenReport = (test: LabTest) => {
    setSelectedTest(test);
    setIsReportModalOpen(true);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patients.find((p) => p.id === orderForm.patientId);
    const doc = doctors.find((d) => d.id === orderForm.doctorId);

    if (!pat || !doc) return;

    orderLabTest({
      patientId: pat.patientId,
      patientName: pat.name,
      doctorId: doc.id,
      doctorName: doc.name,
      testName: orderForm.testName,
      category: orderForm.category,
      orderDate: new Date().toISOString().split('T')[0],
      status: 'Pending',
      price: Number(orderForm.price),
      sampleType: orderForm.sampleType,
    });

    addToast('Lab Test Ordered', `${orderForm.testName} ordered for ${pat.name}.`, 'success');
    setIsOrderModalOpen(false);
  };

  const handleSubmitResult = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTest) return;

    updateLabTestResult(selectedTest.id, {
      result: resultForm.result,
      normalRange: resultForm.normalRange,
      notes: resultForm.notes,
      status: 'Completed',
      reportDate: new Date().toISOString().split('T')[0],
    });

    addToast('Report Finalized', `Report recorded for ${selectedTest.testId}.`, 'success');
    setIsResultModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('lab.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Pathology diagnostics, specimen tracking, clinical biochemistry, and lab reports
          </p>
        </div>

        <button
          onClick={handleOpenOrder}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('lab.order')}</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Investigations
          </span>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            {totalTests} Tests
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Automated analyzers online</p>
        </div>

        <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
            Completed Reports
          </span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {completedCount}
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">
            Verified by Pathologist
          </p>
        </div>

        <div className="p-4 bg-teal-50/50 dark:bg-teal-950/20 border border-teal-100 dark:border-teal-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
            In Analyzer / Testing
          </span>
          <div className="text-2xl font-black text-teal-700 dark:text-teal-300 mt-1">
            {inProgressCount}
          </div>
          <p className="text-[11px] text-teal-700 dark:text-teal-300 mt-0.5">Sample processing</p>
        </div>

        <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Pending Collection
          </span>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
            {pendingCount}
          </div>
          <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">Awaiting phlebotomy</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search test name (e.g. Lipid, CBC), patient name, ID..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="In Progress">In Progress</option>
            <option value="Sample Collected">Sample Collected</option>
            <option value="Pending">Pending</option>
          </select>
        </div>
      </div>

      {/* Tests Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Test ID & Title</th>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Category & Specimen</th>
                <th className="py-3.5 px-4">Referred By</th>
                <th className="py-3.5 px-4">Order Date</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredTests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No diagnostic tests found.
                  </td>
                </tr>
              ) : (
                filteredTests.map((test) => (
                  <tr
                    key={test.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <Microscope className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                        <span>{test.testName}</span>
                      </div>
                      <div className="text-[10px] text-slate-400">{test.testId} • ₹{test.price}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {test.patientName}
                      </div>
                      <div className="text-[11px] text-slate-400">{test.patientId}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {test.category}
                      </div>
                      <div className="text-[11px] text-slate-400">{test.sampleType}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-800 dark:text-slate-200">
                        {test.doctorName}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-900 dark:text-white font-medium">{test.orderDate}</div>
                      {test.reportDate && (
                        <div className="text-[10px] text-emerald-600">Rep: {test.reportDate}</div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          test.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : test.status === 'Processing'
                            ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                            : test.status === 'Sample Collected'
                            ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {test.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {test.status !== 'Completed' ? (
                          <button
                            onClick={() => handleOpenResult(test)}
                            className="px-2.5 py-1 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <FileCheck className="w-3.5 h-3.5" />
                            <span>Enter Result</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleOpenReport(test)}
                            className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>View Report</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Lab Test Modal */}
      <Modal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        title={t('lab.order')}
        subtitle="Schedule a pathology or diagnostic investigation for a patient."
        maxWidth="lg"
      >
        <form onSubmit={handleSubmitOrder} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Patient *
            </label>
            <select
              required
              value={orderForm.patientId}
              onChange={(e) => setOrderForm({ ...orderForm, patientId: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.patientId}) - {p.age}y/{p.gender}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Requisitioning Physician *
            </label>
            <select
              required
              value={orderForm.doctorId}
              onChange={(e) => setOrderForm({ ...orderForm, doctorId: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            >
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.department})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Test / Panel Name *
              </label>
              <input
                type="text"
                required
                value={orderForm.testName}
                onChange={(e) => setOrderForm({ ...orderForm, testName: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Department Category
              </label>
              <select
                value={orderForm.category}
                onChange={(e) => setOrderForm({ ...orderForm, category: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="Biochemistry">Biochemistry</option>
                <option value="Hematology">Hematology</option>
                <option value="Microbiology">Microbiology</option>
                <option value="Pathology">Pathology</option>
                <option value="Immunology">Immunology</option>
                <option value="Radiology">Radiology / Imaging</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Specimen / Sample Type
              </label>
              <input
                type="text"
                value={orderForm.sampleType}
                onChange={(e) => setOrderForm({ ...orderForm, sampleType: e.target.value })}
                placeholder="e.g. Blood Serum, Morning Urine, Sputum"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Investigation Tariff (₹)
              </label>
              <input
                type="number"
                min="0"
                value={orderForm.price}
                onChange={(e) => setOrderForm({ ...orderForm, price: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsOrderModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Issue Lab Requisition
            </button>
          </div>
        </form>
      </Modal>

      {/* Enter Result Modal */}
      {selectedTest && (
        <Modal
          isOpen={isResultModalOpen}
          onClose={() => setIsResultModalOpen(false)}
          title={`Upload Report: ${selectedTest.testName}`}
          subtitle={`Patient: ${selectedTest.patientName} (${selectedTest.patientId})`}
          maxWidth="lg"
        >
          <form onSubmit={handleSubmitResult} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Observed Finding / Quantitative Value *
              </label>
              <textarea
                rows={3}
                required
                value={resultForm.result}
                onChange={(e) => setResultForm({ ...resultForm, result: e.target.value })}
                placeholder="e.g. Hemoglobin: 14.2 g/dL, WBC: 7,200 /mcL, Platelets: 2.8 Lakhs"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Biological Reference Range
              </label>
              <input
                type="text"
                value={resultForm.normalRange}
                onChange={(e) => setResultForm({ ...resultForm, normalRange: e.target.value })}
                placeholder="e.g. 13.0 - 17.0 g/dL"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Pathologist Clinical Remarks / Interpretation
              </label>
              <textarea
                rows={2}
                value={resultForm.notes}
                onChange={(e) => setResultForm({ ...resultForm, notes: e.target.value })}
                placeholder="Specimen indices normal, no cellular abnormalities detected."
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsResultModalOpen(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
              >
                {t('common.cancel')}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
              >
                Save & Sign Off Report
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Printable Diagnostic Report Modal */}
      {selectedTest && (
        <Modal
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          title="Diagnostic Lab Report"
          maxWidth="2xl"
        >
          <div className="p-6 bg-white text-slate-900 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            {/* Hospital Header */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold">
                    MH
                  </div>
                  <span className="font-bold text-lg text-slate-900">MEDICOVER DIAGNOSTICS</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">NABL Accredited Central Pathology Laboratory</p>
              </div>
              <div className="text-right text-xs">
                <div className="font-bold text-teal-700">{selectedTest.testId}</div>
                <div className="text-slate-400">Report Date: {selectedTest.reportDate || selectedTest.orderDate}</div>
              </div>
            </div>

            {/* Patient & Doctor Strip */}
            <div className="grid grid-cols-2 gap-4 p-3 bg-slate-50 rounded-xl text-xs">
              <div>
                <span className="text-slate-400 font-semibold block text-[10px] uppercase">Patient Details</span>
                <span className="font-bold text-slate-900">{selectedTest.patientName}</span>
                <div className="text-slate-500 text-[11px]">ID: {selectedTest.patientId}</div>
              </div>
              <div>
                <span className="text-slate-400 font-semibold block text-[10px] uppercase">Referred By Doctor</span>
                <span className="font-bold text-slate-900">{selectedTest.doctorName}</span>
                <div className="text-slate-500 text-[11px]">Department of {selectedTest.category}</div>
              </div>
            </div>

            {/* Test Details Table */}
            <div>
              <h4 className="font-bold text-sm text-slate-900 mb-2">{selectedTest.testName}</h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <div className="grid grid-cols-3 bg-slate-100 font-semibold p-2.5 border-b border-slate-200">
                  <span>Investigation Parameter</span>
                  <span>Observed Result</span>
                  <span>Biological Reference</span>
                </div>
                <div className="grid grid-cols-3 p-3 bg-white">
                  <span className="font-medium text-slate-800">{selectedTest.testName}</span>
                  <span className="font-bold text-teal-700">{selectedTest.result || 'Analysis in Progress'}</span>
                  <span className="text-slate-600">{selectedTest.normalRange || 'Standard clinical limits'}</span>
                </div>
              </div>
            </div>

            {/* Remarks */}
            {selectedTest.notes && (
              <div className="p-3 bg-teal-50/50 rounded-xl border border-teal-100 text-xs">
                <span className="font-bold text-teal-800 block mb-1">Pathologist Remarks:</span>
                <p className="text-teal-900">{selectedTest.notes}</p>
              </div>
            )}

            {/* Signatures */}
            <div className="flex justify-between items-end pt-6 border-t border-slate-200 text-xs">
              <div>
                <span className="font-bold text-slate-700">Specimen:</span> {selectedTest.sampleType}
              </div>
              <div className="text-center">
                <div className="font-serif italic font-bold text-teal-800 mb-1">Dr. S. Mehta, MD (Path)</div>
                <div className="border-t border-slate-400 pt-1 text-[10px] text-slate-500 font-semibold uppercase">
                  Chief Medical Pathologist
                </div>
              </div>
            </div>

            {/* Print button */}
            <div className="flex justify-end gap-2 pt-2 print:hidden">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>Print Diagnostic Report</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

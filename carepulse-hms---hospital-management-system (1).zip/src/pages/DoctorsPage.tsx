import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Stethoscope,
  Search,
  Plus,
  Filter,
  Calendar,
  Phone,
  Mail,
  Award,
  Clock,
  Edit2,
  Trash2,
  CheckCircle2,
  Building,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Doctor, DepartmentType } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const DoctorsPage: React.FC = () => {
  const {
    language,
    doctors,
    departments,
    addDoctor,
    updateDoctor,
    deleteDoctor,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedAvailability, setSelectedAvailability] = useState<string>('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    department: 'Cardiology' as DepartmentType,
    specialization: '',
    qualification: '',
    experienceYears: 10,
    phone: '',
    email: '',
    consultationFee: 700,
    availability: 'Available' as 'Available' | 'On Leave' | 'Busy' | 'In Surgery',
    roomNumber: 'Room 101',
    schedule: 'Mon - Fri (09:00 AM - 04:00 PM)',
  });

  useEffect(() => {
    const urlQuery = searchParams.get('search');
    if (urlQuery) setSearchQuery(urlQuery);
  }, [searchParams]);

  // Filtered Doctors
  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.department.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDept = selectedDept === 'All' || doc.department === selectedDept;
    const matchesAvailability =
      selectedAvailability === 'All' || doc.availability === selectedAvailability;

    return matchesSearch && matchesDept && matchesAvailability;
  });

  const handleOpenAdd = () => {
    setFormData({
      name: 'Dr. ',
      department: 'Cardiology',
      specialization: 'Consultant Specialist',
      qualification: 'MBBS, MD',
      experienceYears: 8,
      phone: '+91 98765 00000',
      email: 'doctor@medicoverhospitals.in',
      consultationFee: 800,
      availability: 'Available',
      roomNumber: 'OPD 204',
      schedule: 'Mon - Fri (09:00 AM - 03:00 PM)',
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (doc: Doctor) => {
    setSelectedDoctor(doc);
    setFormData({
      name: doc.name,
      department: doc.department,
      specialization: doc.specialization,
      qualification: doc.qualification,
      experienceYears: doc.experienceYears,
      phone: doc.phone,
      email: doc.email,
      consultationFee: doc.consultationFee,
      availability: doc.availability,
      roomNumber: doc.roomNumber,
      schedule: doc.schedule,
    });
    setIsEditModalOpen(true);
  };

  const handleOpenDelete = (doc: Doctor) => {
    setSelectedDoctor(doc);
    setIsDeleteConfirmOpen(true);
  };

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    addDoctor({
      ...formData,
      image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&h=300&fit=crop&crop=face',
    });

    addToast('Doctor Added', `Dr. ${formData.name} added to medical directory.`, 'success');
    setIsAddModalOpen(false);
  };

  const handleSubmitEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoctor) return;

    updateDoctor(selectedDoctor.id, formData);
    addToast('Doctor Updated', `Updated information for ${formData.name}.`, 'success');
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('doc.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {doctors.length} verified specialist doctors on staff
          </p>
        </div>

        <button
          id="add-new-doctor-btn"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('doc.add')}</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search doctors by name, specialization, or department..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={selectedAvailability}
            onChange={(e) => setSelectedAvailability(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Availabilities</option>
            <option value="Available">Available</option>
            <option value="In Surgery">In Surgery</option>
            <option value="Busy">Busy</option>
            <option value="On Leave">On Leave</option>
          </select>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {filteredDoctors.map((doc) => (
          <div
            key={doc.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:shadow-md hover:border-teal-500/40 transition-all flex flex-col justify-between"
          >
            <div>
              {/* Doctor Head Info */}
              <div className="flex items-start gap-4 mb-4">
                <img
                  src={doc.image}
                  alt={doc.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-teal-500/20"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {doc.name}
                    </h3>
                  </div>
                  <p className="text-xs font-semibold text-teal-600 dark:text-teal-400">
                    {doc.specialization}
                  </p>
                  <p className="text-[11px] text-slate-400">{doc.qualification}</p>
                </div>
              </div>

              {/* Status & Fee Badges */}
              <div className="flex items-center justify-between py-2 border-y border-slate-100 dark:border-slate-800 text-xs mb-3">
                <div className="flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      doc.availability === 'Available'
                        ? 'bg-emerald-500 animate-pulse'
                        : doc.availability === 'In Surgery'
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                  />
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    {doc.availability}
                  </span>
                </div>
                <span className="font-bold text-slate-900 dark:text-white">
                  ₹{doc.consultationFee}{' '}
                  <span className="text-[10px] text-slate-400 font-normal">/ Visit</span>
                </span>
              </div>

              {/* Info Details */}
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 mb-4">
                <div className="flex items-center gap-2 text-[11px]">
                  <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>
                    {doc.department} • {doc.roomNumber}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[11px]">
                  <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{doc.schedule}</span>
                </div>
                <div className="flex items-center gap-2 text-[11px]">
                  <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{doc.experienceYears} Years Clinical Experience</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => navigate(`/appointments?doctor=${encodeURIComponent(doc.name)}`)}
                className="flex items-center gap-1 px-3 py-1.5 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-xl text-xs font-semibold transition-colors"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Appt</span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleOpenEdit(doc)}
                  className="p-1.5 text-slate-400 hover:text-sky-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="Edit Doctor"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleOpenDelete(doc)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="Remove Doctor"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Doctor Modal */}
      <Modal
        isOpen={isAddModalOpen || isEditModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setIsEditModalOpen(false);
        }}
        title={isAddModalOpen ? t('doc.add') : 'Edit Doctor Profile'}
        maxWidth="xl"
      >
        <form onSubmit={isAddModalOpen ? handleSubmitAdd : handleSubmitEdit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Doctor Full Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Department *
              </label>
              <select
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value as any })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.name}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Specialization
              </label>
              <input
                type="text"
                required
                value={formData.specialization}
                onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Qualification
              </label>
              <input
                type="text"
                required
                value={formData.qualification}
                onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Consultation Fee (₹)
              </label>
              <input
                type="number"
                required
                min="0"
                value={formData.consultationFee}
                onChange={(e) => setFormData({ ...formData, consultationFee: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Availability Status
              </label>
              <select
                value={formData.availability}
                onChange={(e) => setFormData({ ...formData, availability: e.target.value as any })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="Available">Available</option>
                <option value="In Surgery">In Surgery</option>
                <option value="Busy">Busy</option>
                <option value="On Leave">On Leave</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Room / Cabin
              </label>
              <input
                type="text"
                value={formData.roomNumber}
                onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Schedule Hours
              </label>
              <input
                type="text"
                value={formData.schedule}
                onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                setIsAddModalOpen(false);
                setIsEditModalOpen(false);
              }}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              {t('common.save')}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      {selectedDoctor && (
        <ConfirmDialog
          isOpen={isDeleteConfirmOpen}
          onClose={() => setIsDeleteConfirmOpen(false)}
          onConfirm={() => {
            deleteDoctor(selectedDoctor.id);
            addToast('Doctor Removed', `${selectedDoctor.name} removed from registry.`, 'warning');
          }}
          title={t('doc.delete_title')}
          message={`Are you sure you want to remove ${selectedDoctor.name}? This will affect scheduled appointments.`}
          confirmText={t('common.delete')}
          isDestructive={true}
        />
      )}
    </div>
  );
};

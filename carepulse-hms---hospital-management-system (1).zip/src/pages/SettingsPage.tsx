import React, { useState } from 'react';
import {
  Settings,
  Building,
  Globe,
  Mic,
  Moon,
  Sun,
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  Shield,
  Volume2,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation, Language } from '../i18n/translations';
import { speakText } from '../services/aiVoiceAndChatService';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const SettingsPage: React.FC = () => {
  const {
    language,
    setLanguage,
    darkMode,
    setDarkMode,
    resetToDemoData,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  // Hospital Details State
  const [hospitalInfo, setHospitalInfo] = useState({
    name: 'Medicover Hospital',
    tagline: 'Excellence in Healthcare & Patient Wellbeing',
    emergencyHotline: '1800 425 3333 / +91 40 6833 4455',
    phone: '+91 40 6833 4455',
    email: 'info@medicoverhospitals.in',
    address: 'Plot 42, Health City, Jubilee Hills, Hyderabad, Telangana - 500033',
    taxGstin: '36AAAAA0000A1Z5',
  });

  // AI Voice settings
  const [voiceSpeed, setVoiceSpeed] = useState('1');
  const [autoListen, setAutoListen] = useState(false);

  // Confirm Reset Modal
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const handleSaveHospitalInfo = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('Settings Saved', 'Hospital profile updated successfully.', 'success');
  };

  const handleTestVoice = () => {
    const testPhrase =
      language === 'te'
        ? 'నమస్కారం! కేర్‌పల్స్ హాస్పిటల్ వాయిస్ అసిస్టెంట్ సిద్ధంగా ఉంది.'
        : language === 'hi'
        ? 'नमस्ते! केयरपल्स हॉस्पिटल वॉयస్ असिस्टेंट तैयार है।'
        : 'Hello! Medicover Hospital Voice and AI Assistant is ready to help you.';

    speakText(testPhrase, language);
    addToast('Voice Test', `Playing sample speech in ${language.toUpperCase()}.`, 'info');
  };

  const handleExportFullJSON = () => {
    const dataStr = localStorage.getItem('carepulse_hospital_data');
    if (!dataStr) {
      addToast('Error', 'No data found in storage to export.', 'error');
      return;
    }

    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carepulse_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addToast('Backup Downloaded', 'Full hospital JSON backup exported.', 'success');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        localStorage.setItem('carepulse_hospital_data', JSON.stringify(json));
        addToast('Data Restored', 'Database backup imported! Reloading...', 'success');
        setTimeout(() => window.location.reload(), 1200);
      } catch (err) {
        addToast('Import Failed', 'Invalid JSON backup file format.', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-teal-600 dark:text-teal-400" />
          {t('set.title')}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Hospital enterprise configuration, regional language preferences, AI voice engine, and data backups
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Navigation / Quick Highlights */}
        <div className="space-y-4">
          <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-black text-base">
                MH
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Medicover EHR</h4>
                <p className="text-[10px] text-teal-600 font-semibold">v3.4.0 • Enterprise Edition</p>
              </div>
            </div>
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">System Mode:</span>
                <span className="font-semibold text-emerald-600">Active Online</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Persistence:</span>
                <span className="font-semibold">Local Storage</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Security Rule:</span>
                <span className="font-semibold">HIPAA / NABH</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-teal-50 dark:bg-teal-950/40 rounded-2xl border border-teal-100 dark:border-teal-900/40 text-xs">
            <h4 className="font-bold text-teal-900 dark:text-teal-200 mb-1 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-teal-600" />
              <span>Multilingual Switcher</span>
            </h4>
            <p className="text-slate-600 dark:text-slate-300 text-[11px] mb-3">
              Choose your interface and speech assistant language:
            </p>

            <div className="space-y-1.5">
              {[
                { code: 'en', label: 'English (India)', native: 'English' },
                { code: 'te', label: 'Telugu', native: 'తెలుగు (ఆంధ్రప్రదేశ్ & తెలంగాణ)' },
                { code: 'hi', label: 'Hindi', native: 'हिन्दी (भारत)' },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code as Language)}
                  className={`w-full p-2 rounded-xl text-left font-semibold text-xs flex items-center justify-between transition-colors ${
                    language === lang.code
                      ? 'bg-teal-600 text-white shadow-2xs'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-teal-100 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{lang.native}</span>
                  {language === lang.code && <CheckCircle2 className="w-4 h-4" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Columns: Setting Sections */}
        <div className="md:col-span-2 space-y-6">
          {/* Hospital Profile */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
              <Building className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Hospital Profile & Contact Info</span>
            </h3>

            <form onSubmit={handleSaveHospitalInfo} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Hospital Legal Name
                  </label>
                  <input
                    type="text"
                    value={hospitalInfo.name}
                    onChange={(e) => setHospitalInfo({ ...hospitalInfo, name: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Emergency 24x7 Hotline
                  </label>
                  <input
                    type="text"
                    value={hospitalInfo.emergencyHotline}
                    onChange={(e) =>
                      setHospitalInfo({ ...hospitalInfo, emergencyHotline: e.target.value })
                    }
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Primary Reception Phone
                  </label>
                  <input
                    type="text"
                    value={hospitalInfo.phone}
                    onChange={(e) => setHospitalInfo({ ...hospitalInfo, phone: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    GSTIN / Tax ID
                  </label>
                  <input
                    type="text"
                    value={hospitalInfo.taxGstin}
                    onChange={(e) => setHospitalInfo({ ...hospitalInfo, taxGstin: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Hospital Campus Address
                </label>
                <input
                  type="text"
                  value={hospitalInfo.address}
                  onChange={(e) => setHospitalInfo({ ...hospitalInfo, address: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold shadow-xs text-xs"
                >
                  Save Hospital Details
                </button>
              </div>
            </form>
          </div>

          {/* AI Voice Assistant Preferences */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
              <Mic className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>AI Speech & Voice Assistant Settings</span>
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Speech Synthesizer Speed
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Voice playback pace for doctor & patient voice queries
                  </p>
                </div>
                <select
                  value={voiceSpeed}
                  onChange={(e) => setVoiceSpeed(e.target.value)}
                  className="p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                >
                  <option value="0.8">0.8x (Gentle / Slower)</option>
                  <option value="1">1.0x (Standard)</option>
                  <option value="1.2">1.2x (Fast)</option>
                </select>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">Test Voice Audio</h4>
                  <p className="text-[11px] text-slate-500">
                    Verify multilingual audio synthesis in your browser
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleTestVoice}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-xl font-bold transition-colors"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Play Sample</span>
                </button>
              </div>
            </div>
          </div>

          {/* Database Backup & Demo Reset */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
              <Database className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Data Persistence & Maintenance</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <button
                onClick={handleExportFullJSON}
                className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center gap-1.5 transition-colors"
              >
                <Download className="w-4 h-4 text-teal-600" />
                <span>Export Backup JSON</span>
              </button>

              <label className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer text-center">
                <Upload className="w-4 h-4 text-sky-600" />
                <span>Import JSON Backup</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportJSON}
                  className="hidden"
                />
              </label>

              <button
                onClick={() => setIsResetConfirmOpen(true)}
                className="p-3 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-xl border border-rose-200 dark:border-rose-900/50 font-bold text-rose-700 dark:text-rose-300 flex flex-col items-center justify-center gap-1.5 transition-colors"
              >
                <RefreshCw className="w-4 h-4 text-rose-600" />
                <span>Reset to Demo Data</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      <ConfirmDialog
        isOpen={isResetConfirmOpen}
        onClose={() => setIsResetConfirmOpen(false)}
        onConfirm={() => {
          resetToDemoData();
          addToast('Database Reset', 'Demo hospital records restored.', 'info');
        }}
        title="Reset Entire Database"
        message="Are you sure you want to restore default mock patients, doctors, beds, pharmacy inventory, and appointments? All local changes will be replaced with clean demo records."
        confirmText="Yes, Reset Database"
        isDestructive={true}
      />
    </div>
  );
};

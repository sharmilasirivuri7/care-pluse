import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Receipt,
  Search,
  Plus,
  Printer,
  CreditCard,
  CheckCircle2,
  DollarSign,
  TrendingUp,
  AlertCircle,
  FileText,
  Trash2,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Invoice, InvoiceItem } from '../types';
import { Modal } from '../components/common/Modal';
import { PrintableInvoiceModal } from '../components/common/PrintableInvoiceModal';

export const BillingPage: React.FC = () => {
  const {
    language,
    invoices,
    patients,
    createInvoice,
    recordPayment,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const [searchParams] = useSearchParams();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(searchParams.get('filter') || 'All');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // New Invoice Form State
  const [newInvoiceForm, setNewInvoiceForm] = useState<{
    patientId: string;
    items: { description: string; category: string; quantity: number; unitPrice: number }[];
    taxRate: number;
    discount: number;
    paymentMethod?: string;
  }>({
    patientId: patients[0]?.id || '',
    items: [
      { description: 'OPD Specialist Consultation', category: 'Consultation', quantity: 1, unitPrice: 750 },
    ],
    taxRate: 5,
    discount: 0,
  });

  // Payment Record Form
  const [paymentForm, setPaymentForm] = useState({
    amount: 0,
    method: 'UPI / Online' as 'Cash' | 'Card' | 'UPI / Online' | 'Insurance Claim' | 'Net Banking',
  });

  useEffect(() => {
    const filterParam = searchParams.get('filter');
    if (filterParam) setStatusFilter(filterParam);
  }, [searchParams]);

  // Billing Metrics
  const totalBilled = invoices.reduce((acc, i) => acc + i.total, 0);
  const totalCollected = invoices.reduce((acc, i) => acc + i.paidAmount, 0);
  const totalOutstanding = invoices.reduce((acc, i) => acc + i.remainingAmount, 0);
  const pendingCount = invoices.filter((i) => i.status === 'Pending' || i.status === 'Partially Paid').length;

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.invoiceId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientId.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || inv.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenCreate = () => {
    setNewInvoiceForm({
      patientId: patients[0]?.id || '',
      items: [
        { description: 'Consultation Fee', category: 'Consultation', quantity: 1, unitPrice: 800 },
      ],
      taxRate: 5,
      discount: 0,
    });
    setIsCreateModalOpen(true);
  };

  const handleAddItemRow = () => {
    setNewInvoiceForm((prev) => ({
      ...prev,
      items: [...prev.items, { description: '', category: 'Investigation', quantity: 1, unitPrice: 500 }],
    }));
  };

  const handleRemoveItemRow = (index: number) => {
    setNewInvoiceForm((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const handleItemChange = (index: number, field: string, value: any) => {
    setNewInvoiceForm((prev) => {
      const updated = [...prev.items];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, items: updated };
    });
  };

  const handleOpenPayment = (inv: Invoice) => {
    setSelectedInvoice(inv);
    setPaymentForm({
      amount: inv.remainingAmount,
      method: 'UPI / Online',
    });
    setIsPaymentModalOpen(true);
  };

  const handleOpenPrint = (inv: Invoice) => {
    setSelectedInvoice(inv);
    setIsPrintModalOpen(true);
  };

  const handleSubmitCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patients.find((p) => p.id === newInvoiceForm.patientId);
    if (!pat) return;

    const formattedItems: InvoiceItem[] = newInvoiceForm.items.map((it, idx) => ({
      id: `item-${Date.now()}-${idx}`,
      description: it.description || 'Hospital Service',
      category: it.category,
      quantity: Number(it.quantity) || 1,
      unitPrice: Number(it.unitPrice) || 0,
      total: (Number(it.quantity) || 1) * (Number(it.unitPrice) || 0),
    }));

    const subtotal = formattedItems.reduce((sum, it) => sum + it.total, 0);
    const taxAmount = (subtotal * newInvoiceForm.taxRate) / 100;
    const total = subtotal + taxAmount - Number(newInvoiceForm.discount);

    createInvoice({
      patientId: pat.patientId,
      patientName: pat.name,
      patientPhone: pat.phone,
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      items: formattedItems,
      subtotal,
      taxRate: newInvoiceForm.taxRate,
      taxAmount,
      discount: Number(newInvoiceForm.discount),
      total,
      paidAmount: 0,
      remainingAmount: total,
      status: 'Pending',
    });

    addToast('Invoice Created', `Invoice generated for ${pat.name}.`, 'success');
    setIsCreateModalOpen(false);
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;

    recordPayment(selectedInvoice.id, Number(paymentForm.amount), paymentForm.method);
    addToast('Payment Recorded', `Received ₹${Number(paymentForm.amount).toLocaleString()} for ${selectedInvoice.invoiceId}.`, 'success');
    setIsPaymentModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Receipt className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('bill.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Billing management, tax invoices, revenue tracking, and payment collection
          </p>
        </div>

        <button
          id="generate-new-invoice-btn"
          onClick={handleOpenCreate}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('bill.generate')}</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Billed
          </span>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1 truncate">
            ₹{totalBilled.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">{invoices.length} Invoices generated</p>
        </div>

        <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
            Total Collected
          </span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1 truncate">
            ₹{totalCollected.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">Realized revenue</p>
        </div>

        <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Outstanding Due
          </span>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1 truncate">
            ₹{totalOutstanding.toLocaleString()}
          </div>
          <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">
            {pendingCount} Pending invoices
          </p>
        </div>

        <div className="p-4 bg-teal-50/50 dark:bg-teal-950/20 border border-teal-100 dark:border-teal-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
            Collection Ratio
          </span>
          <div className="text-2xl font-black text-teal-700 dark:text-teal-300 mt-1">
            {totalBilled > 0 ? Math.round((totalCollected / totalBilled) * 100) : 100}%
          </div>
          <p className="text-[11px] text-teal-700 dark:text-teal-300 mt-0.5">Financial health</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search invoice number, patient name, ID..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
        >
          <option value="All">All Invoices</option>
          <option value="Paid">Paid</option>
          <option value="Partially Paid">Partially Paid</option>
          <option value="Pending">Pending</option>
        </select>
      </div>

      {/* Invoices Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Invoice #</th>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Date / Due</th>
                <th className="py-3.5 px-4">Total Amount</th>
                <th className="py-3.5 px-4">Paid / Balance</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No invoice records found.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {inv.invoiceId}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {inv.patientName}
                      </div>
                      <div className="text-[11px] text-slate-400">{inv.patientId}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-900 dark:text-white font-medium">{inv.date}</div>
                      <div className="text-[11px] text-slate-400">Due: {inv.dueDate}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white text-sm">
                        ₹{inv.total.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {inv.items.length} billable items
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-emerald-600 dark:text-emerald-400 font-semibold">
                        Paid: ₹{inv.paidAmount.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-rose-600 font-bold">
                        Bal: ₹{inv.remainingAmount.toLocaleString()}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          inv.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : inv.status === 'Partially Paid'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {inv.remainingAmount > 0 && (
                          <button
                            onClick={() => handleOpenPayment(inv)}
                            className="px-2.5 py-1 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>Pay</span>
                          </button>
                        )}
                        <button
                          onClick={() => handleOpenPrint(inv)}
                          className="p-1.5 text-slate-400 hover:text-teal-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Print / View Invoice"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Generate Invoice Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title={t('bill.generate')}
        subtitle="Create an itemized hospital bill for clinical procedures and pharmacy."
        maxWidth="2xl"
      >
        <form onSubmit={handleSubmitCreate} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Patient *
            </label>
            <select
              required
              value={newInvoiceForm.patientId}
              onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, patientId: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.patientId}) - {p.phone}
                </option>
              ))}
            </select>
          </div>

          {/* Itemized Line Items */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-700 dark:text-slate-300">
                Billable Procedure / Medication Items
              </span>
              <button
                type="button"
                onClick={handleAddItemRow}
                className="text-xs font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Item</span>
              </button>
            </div>

            {newInvoiceForm.items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
                <input
                  type="text"
                  required
                  placeholder="Item description (e.g. ECG Test)"
                  value={item.description}
                  onChange={(e) => handleItemChange(idx, 'description', e.target.value)}
                  className="flex-2 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
                <select
                  value={item.category}
                  onChange={(e) => handleItemChange(idx, 'category', e.target.value)}
                  className="p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                >
                  <option value="Consultation">Consultation</option>
                  <option value="Pharmacy">Pharmacy</option>
                  <option value="Investigation">Investigation</option>
                  <option value="Room Charges">Room Charges</option>
                  <option value="Procedure">Procedure</option>
                </select>
                <input
                  type="number"
                  min="1"
                  placeholder="Qty"
                  value={item.quantity}
                  onChange={(e) => handleItemChange(idx, 'quantity', Number(e.target.value))}
                  className="w-14 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-center"
                />
                <input
                  type="number"
                  min="0"
                  placeholder="Unit Price"
                  value={item.unitPrice}
                  onChange={(e) => handleItemChange(idx, 'unitPrice', Number(e.target.value))}
                  className="w-20 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-right"
                />
                {newInvoiceForm.items.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveItemRow(idx)}
                    className="p-1 text-slate-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                GST / Tax Rate (%)
              </label>
              <input
                type="number"
                min="0"
                max="28"
                value={newInvoiceForm.taxRate}
                onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, taxRate: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Discount (₹)
              </label>
              <input
                type="number"
                min="0"
                value={newInvoiceForm.discount}
                onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, discount: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Generate Invoice
            </button>
          </div>
        </form>
      </Modal>

      {/* Record Payment Modal */}
      {selectedInvoice && (
        <Modal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          title="Collect Payment"
          subtitle={`Invoice: ${selectedInvoice.invoiceId} • Patient: ${selectedInvoice.patientName}`}
          maxWidth="md"
        >
          <form onSubmit={handleSubmitPayment} className="space-y-4 text-xs">
            <div className="p-3 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-teal-100 dark:border-teal-900/40">
              <div className="flex justify-between text-slate-700 dark:text-slate-300 mb-1">
                <span>Total Invoice Value:</span>
                <span className="font-bold">₹{selectedInvoice.total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-700 dark:text-slate-300 mb-1">
                <span>Previously Paid:</span>
                <span className="font-semibold text-emerald-600">₹{selectedInvoice.paidAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-900 dark:text-white font-bold pt-1 border-t border-teal-200 dark:border-teal-800">
                <span>Current Balance Due:</span>
                <span className="text-rose-600">₹{selectedInvoice.remainingAmount.toLocaleString()}</span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Payment Amount (₹) *
              </label>
              <input
                type="number"
                required
                min="1"
                max={selectedInvoice.remainingAmount}
                value={paymentForm.amount}
                onChange={(e) => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none font-bold text-sm"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Payment Method *
              </label>
              <select
                value={paymentForm.method}
                onChange={(e) => setPaymentForm({ ...paymentForm, method: e.target.value as any })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="UPI / Online">UPI / Online QR (Google Pay, PhonePe)</option>
                <option value="Card">Debit / Credit Card (POS Terminal)</option>
                <option value="Cash">Cash Counter</option>
                <option value="Insurance Claim">TPA / Medical Insurance Claim</option>
                <option value="Net Banking">Net Banking / NEFT</option>
              </select>
            </div>

            <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
              >
                {t('common.cancel')}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
              >
                Confirm Payment Receipt
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Printable Invoice Modal */}
      <PrintableInvoiceModal
        invoice={selectedInvoice}
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
      />
    </div>
  );
};

import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Stethoscope,
  Calendar,
  BedDouble,
  Receipt,
  Pill,
  TrendingUp,
  Activity,
  ArrowUpRight,
  PlusCircle,
  Sparkles,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';

interface DashboardPageProps {
  onOpenVoiceAssistant: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onOpenVoiceAssistant }) => {
  const {
    language,
    settings,
    user,
    patients,
    doctors,
    appointments,
    beds,
    admissions,
    invoices,
    medicines,
    activities,
    completeAppointment,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();

  // Metrics Calculations
  const totalPatients = patients.length;
  const totalDoctors = doctors.length;
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter(
    (a) => a.date === todayDateStr || a.date === '2026-08-27'
  );
  const admittedCount = beds.filter((b) => b.status === 'Occupied').length;
  const availableBeds = beds.filter((b) => b.status === 'Available').length;
  const bedOccupancyRate = beds.length > 0 ? Math.round((admittedCount / beds.length) * 100) : 0;
  const pendingInvoices = invoices.filter((i) => i.status === 'Pending' || i.status === 'Partially Paid');
  const totalPendingAmount = pendingInvoices.reduce((acc, i) => acc + i.remainingAmount, 0);
  const totalRevenue = invoices.reduce((acc, i) => acc + i.paidAmount, 0);
  const lowStockMeds = medicines.filter((m) => m.stockQuantity <= m.minThreshold);

  // Mock appointment trend data by day
  const weeklyTrend = [
    { day: 'Mon', count: 12, height: '60%' },
    { day: 'Tue', count: 16, height: '80%' },
    { day: 'Wed', count: 14, height: '70%' },
    { day: 'Thu', count: 18, height: '90%' },
    { day: 'Fri', count: todayAppointments.length + 10, height: '85%' },
    { day: 'Sat', count: 9, height: '45%' },
    { day: 'Sun', count: 5, height: '25%' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-teal-700 via-teal-600 to-sky-600 text-white p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-teal-100 text-xs font-semibold backdrop-blur-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>{t('dash.system_status')}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">
              {t('dash.welcome_back')} {user.name}
            </h2>
            <p className="text-xs sm:text-sm text-teal-50/90 leading-relaxed">
              {settings?.hospitalName || 'Medicover Hospital'} Operations are running smoothly. You have{' '}
              <strong className="text-white font-bold">{todayAppointments.length} appointments</strong> scheduled for today and{' '}
              <strong className="text-white font-bold">{availableBeds} beds available</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenVoiceAssistant}
              className="flex items-center gap-2 px-4 py-2.5 bg-white text-teal-800 hover:bg-teal-50 rounded-2xl text-xs font-bold shadow-md transition-all active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-teal-600 animate-pulse" />
              <span>{t('ai.voice_title')}</span>
            </button>
            <button
              onClick={() => navigate('/appointments')}
              className="flex items-center gap-2 px-4 py-2.5 bg-teal-800/60 hover:bg-teal-800 text-white rounded-2xl text-xs font-semibold backdrop-blur-xs transition-colors"
            >
              <Calendar className="w-4 h-4" />
              <span>{t('nav.appointments')}</span>
            </button>
          </div>
        </div>

        {/* Decorative background shapes */}
        <div className="absolute right-0 top-0 -mt-8 -mr-8 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 -mb-12 w-48 h-48 rounded-full bg-teal-400/20 blur-xl pointer-events-none" />
      </div>

      {/* Top 6 KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Patients */}
        <div
          onClick={() => navigate('/patients')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-teal-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Users className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold text-emerald-600 flex items-center">
              +12% <TrendingUp className="w-3 h-3 ml-0.5" />
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white">{totalPatients}</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.total_patients')}
          </div>
        </div>

        {/* Total Doctors */}
        <div
          onClick={() => navigate('/doctors')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-sky-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Stethoscope className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold text-sky-600 bg-sky-50 dark:bg-sky-950 px-1.5 py-0.5 rounded-md">
              Active
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white">{totalDoctors}</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.total_doctors')}
          </div>
        </div>

        {/* Today's Appointments */}
        <div
          onClick={() => navigate('/appointments')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-teal-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Calendar className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold text-teal-600 bg-teal-50 dark:bg-teal-950 px-1.5 py-0.5 rounded-md">
              Today
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white">{todayAppointments.length}</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.today_appointments')}
          </div>
        </div>

        {/* Available Beds */}
        <div
          onClick={() => navigate('/beds')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <BedDouble className="w-4 h-4" />
            </div>
            <span className="text-[11px] font-semibold text-slate-500">
              {bedOccupancyRate}% Occ
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white">{availableBeds}</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.available_beds')}
          </div>
        </div>

        {/* Pending Bills */}
        <div
          onClick={() => navigate('/billing')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-amber-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Receipt className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-amber-600">
              {pendingInvoices.length} Bills
            </span>
          </div>
          <div className="text-lg font-bold text-slate-900 dark:text-white truncate">
            ₹{totalPendingAmount.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.pending_bills')}
          </div>
        </div>

        {/* Pharmacy Alerts */}
        <div
          onClick={() => navigate('/pharmacy')}
          className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-rose-500/50 shadow-xs hover:shadow-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Pill className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950 px-1.5 py-0.5 rounded-md">
              Alerts
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white">{lowStockMeds.length}</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
            {t('dash.pharmacy_alerts')}
          </div>
        </div>
      </div>

      {/* Charts & Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Appointments Chart */}
        <div className="lg:col-span-2 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                {t('dash.appointments_chart')}
              </h3>
              <p className="text-xs text-slate-400">Total appointments booked over the past 7 days</p>
            </div>
            <span className="text-xs font-semibold text-teal-600 bg-teal-50 dark:bg-teal-950/60 px-2.5 py-1 rounded-lg">
              Avg 14.5 / Day
            </span>
          </div>

          <div className="h-44 flex items-end justify-between gap-3 pt-6 px-2 border-b border-slate-100 dark:border-slate-800">
            {weeklyTrend.map((item) => (
              <div key={item.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <div className="text-[10px] font-bold text-slate-600 dark:text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.count}
                </div>
                <div
                  className="w-full max-w-[36px] bg-gradient-to-t from-teal-600 to-sky-400 rounded-t-lg transition-all group-hover:brightness-110"
                  style={{ height: item.height }}
                />
                <span className="text-[11px] font-medium text-slate-400 mt-1">{item.day}</span>
              </div>
            ))}
          </div>

          {/* Mini summary badges */}
          <div className="grid grid-cols-3 gap-3 pt-4 text-center">
            <div className="p-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-medium">Completed Visits</span>
              <span className="text-xs font-bold text-slate-900 dark:text-white">84 Consultations</span>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-medium">Cancellation Rate</span>
              <span className="text-xs font-bold text-emerald-600">3.2% (Very Low)</span>
            </div>
            <div className="p-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-medium">Peak Consultation Hours</span>
              <span className="text-xs font-bold text-teal-600">10:00 AM - 01:00 PM</span>
            </div>
          </div>
        </div>

        {/* Bed Occupancy & Revenue Widget */}
        <div className="space-y-6">
          {/* Bed Occupancy Meter */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t('dash.bed_occupancy_rate')}
              </h3>
              <span className="text-xs font-bold text-teal-600">{bedOccupancyRate}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mb-4">
              <div
                className="h-full bg-gradient-to-r from-teal-500 to-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${bedOccupancyRate}%` }}
              />
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  Available Beds
                </span>
                <span className="font-bold">{availableBeds}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  Occupied Inpatients
                </span>
                <span className="font-bold">{admittedCount}</span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  Reserved & Maintenance
                </span>
                <span className="font-bold">{beds.length - (availableBeds + admittedCount)}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/beds')}
              className="w-full mt-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950 text-slate-700 dark:text-slate-200 hover:text-teal-700 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1"
            >
              <span>{t('bed.visual_grid')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Revenue Breakdown mini card */}
          <div className="p-5 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl shadow-md border border-slate-700">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs text-slate-400 font-medium">{t('dash.revenue_month')}</span>
                <div className="text-2xl font-extrabold text-teal-400 mt-0.5">
                  ₹{totalRevenue.toLocaleString()}
                </div>
              </div>
              <div className="p-2 bg-teal-500/20 text-teal-400 rounded-xl">
                <Receipt className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3 text-xs text-slate-300 flex items-center justify-between border-t border-slate-700/60 pt-2.5">
              <span>Pending Collections:</span>
              <span className="text-amber-400 font-bold">₹{totalPendingAmount.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Section: Today's Appointments & Recent Patients */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Appointments Table */}
        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-600" />
                {t('dash.today_appointments')}
              </h3>
              <p className="text-xs text-slate-400">Scheduled consultations for today</p>
            </div>
            <button
              onClick={() => navigate('/appointments')}
              className="text-xs font-semibold text-teal-600 hover:text-teal-700 dark:text-teal-400 flex items-center gap-1"
            >
              <span>{t('common.view_all')}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {todayAppointments.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">No appointments scheduled for today</div>
            ) : (
              todayAppointments.map((appt) => (
                <div
                  key={appt.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800/80 hover:border-teal-500/30 transition-all text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="px-2.5 py-1.5 rounded-lg bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold text-[11px]">
                      {appt.time}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white">{appt.patientName}</h4>
                      <p className="text-[11px] text-slate-400">{appt.doctorName} • {appt.department}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        appt.status === 'Confirmed'
                          ? 'bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300'
                          : appt.status === 'Completed'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {appt.status}
                    </span>
                    {appt.status !== 'Completed' && (
                      <button
                        onClick={() => completeAppointment(appt.id)}
                        className="p-1.5 text-slate-400 hover:text-emerald-600 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/40"
                        title="Mark Completed"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Patients List */}
        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-sky-600" />
                {t('dash.recent_patients')}
              </h3>
              <p className="text-xs text-slate-400">Recently admitted & registered profiles</p>
            </div>
            <button
              onClick={() => navigate('/patients')}
              className="text-xs font-semibold text-teal-600 hover:text-teal-700 dark:text-teal-400 flex items-center gap-1"
            >
              <span>{t('common.view_all')}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {patients.slice(0, 4).map((p) => (
              <div
                key={p.id}
                onClick={() => navigate(`/patients?search=${encodeURIComponent(p.name)}`)}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800/80 hover:bg-teal-50/40 dark:hover:bg-teal-950/20 cursor-pointer transition-all text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold flex items-center justify-center text-xs">
                    {p.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">{p.name}</h4>
                    <p className="text-[11px] text-slate-400">{p.patientId} • {p.bloodGroup} • {p.department}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      p.status === 'Inpatient'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    }`}
                  >
                    {p.status}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-0.5">{p.phone}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activities Log */}
      <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-600" />
            {t('dash.recent_activities')}
          </h3>
          <span className="text-[11px] text-slate-400 font-medium">Real-time audit log</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {activities.slice(0, 4).map((act) => (
            <div
              key={act.id}
              className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-xs space-y-1"
            >
              <div className="flex items-center justify-between text-[10px]">
                <span className="font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">
                  {act.module}
                </span>
                <span className="text-slate-400">{act.timestamp.split(' ')[1] || 'Today'}</span>
              </div>
              <div className="font-semibold text-slate-900 dark:text-white truncate">{act.action}</div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-tight">
                {act.details}
              </p>
              <div className="text-[10px] text-slate-400 pt-1">By: {act.user}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

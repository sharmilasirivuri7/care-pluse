import React, { useState } from 'react';
import {
  FilePlus,
  Search,
  Plus,
  Printer,
  Pill,
  Clock,
  Calendar,
  Trash2,
  Stethoscope,
  User,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Prescription, PrescribedMedicine } from '../types';
import { Modal } from '../components/common/Modal';
import { PrintablePrescriptionModal } from '../components/common/PrintablePrescriptionModal';

export const PrescriptionsPage: React.FC = () => {
  const {
    language,
    prescriptions,
    patients,
    doctors,
    medicines,
    addPrescription,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);

  // New Prescription Form State
  const [formData, setFormData] = useState<{
    patientId: string;
    doctorId: string;
    diagnosis: string;
    medicines: PrescribedMedicine[];
    advice: string;
    followUpDate: string;
  }>({
    patientId: patients[0]?.id || '',
    doctorId: doctors[0]?.id || '',
    diagnosis: 'Upper Respiratory Tract Infection',
    medicines: [
      {
        id: 'pm-1',
        medicineName: 'Augmentin 625 Duo',
        dosage: '625 mg',
        frequency: '1-0-1 (Twice daily)',
        duration: '5 Days',
        instructions: 'Take after meals with warm water',
      },
    ],
    advice: 'Drink plenty of warm fluids, steam inhalation twice a day, avoid cold drinks.',
    followUpDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
  });

  const filteredPrescriptions = prescriptions.filter((rx) => {
    return (
      rx.prescriptionId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rx.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rx.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rx.diagnosis.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const handleOpenAdd = () => {
    setFormData({
      patientId: patients[0]?.id || '',
      doctorId: doctors[0]?.id || '',
      diagnosis: 'Acute Pharyngitis & Fever',
      medicines: [
        {
          id: `pm-${Date.now()}`,
          medicineName: medicines[0]?.name || 'Paracetamol 650mg',
          dosage: '650 mg',
          frequency: '1-0-1',
          duration: '3 Days',
          instructions: 'Take after food for fever',
        },
      ],
      advice: 'Get adequate rest, gargle with warm saline water, review if fever persists.',
      followUpDate: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
    });
    setIsAddModalOpen(true);
  };

  const handleAddMedRow = () => {
    setFormData((prev) => ({
      ...prev,
      medicines: [
        ...prev.medicines,
        {
          id: `pm-${Date.now()}-${Math.random()}`,
          medicineName: '',
          dosage: '1 tab',
          frequency: '1-0-1',
          duration: '5 Days',
          instructions: 'After food',
        },
      ],
    }));
  };

  const handleRemoveMedRow = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      medicines: prev.medicines.filter((_, i) => i !== index),
    }));
  };

  const handleMedChange = (index: number, field: string, value: string) => {
    setFormData((prev) => {
      const updated = [...prev.medicines];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, medicines: updated };
    });
  };

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patients.find((p) => p.id === formData.patientId);
    const doc = doctors.find((d) => d.id === formData.doctorId);

    if (!pat || !doc) return;

    addPrescription({
      patientId: pat.patientId,
      patientName: pat.name,
      patientAge: pat.age,
      patientGender: pat.gender,
      doctorId: doc.id,
      doctorName: doc.name,
      doctorSpecialization: doc.specialization,
      date: new Date().toISOString().split('T')[0],
      diagnosis: formData.diagnosis,
      medicines: formData.medicines,
      advice: formData.advice,
      followUpDate: formData.followUpDate,
    });

    addToast('Prescription Generated', `e-Rx created for ${pat.name}.`, 'success');
    setIsAddModalOpen(false);
  };

  const handleOpenPrint = (rx: Prescription) => {
    setSelectedPrescription(rx);
    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FilePlus className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('rx.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Digital doctor prescription slips (e-Rx), dosage schedules, and medication advice
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('rx.create')}</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search e-Rx ID, patient name, doctor, or diagnosis..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Prescriptions Grid / Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPrescriptions.map((rx) => (
          <div
            key={rx.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:shadow-md hover:border-teal-500/40 transition-all flex flex-col justify-between"
          >
            <div>
              {/* Header strip */}
              <div className="flex items-start justify-between mb-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-teal-700 dark:text-teal-400">
                      {rx.prescriptionId}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold rounded-full">
                      e-Rx
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base mt-1">
                    {rx.patientName}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {rx.patientAge} Yrs • {rx.patientGender} • {rx.patientId}
                  </p>
                </div>

                <div className="text-right">
                  <div className="font-semibold text-slate-800 dark:text-slate-200 text-xs">
                    {rx.doctorName}
                  </div>
                  <div className="text-[11px] text-teal-600 dark:text-teal-400">
                    {rx.doctorSpecialization}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{rx.date}</div>
                </div>
              </div>

              {/* Diagnosis */}
              <div className="mb-3">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                  Diagnosis
                </span>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {rx.diagnosis}
                </p>
              </div>

              {/* Meds List */}
              <div className="space-y-1.5 mb-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Prescribed Formulations ({rx.medicines.length})
                </span>
                {rx.medicines.map((med, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between text-xs py-1 border-b border-slate-200/60 dark:border-slate-700/60 last:border-none"
                  >
                    <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Pill className="w-3 h-3 text-teal-500 shrink-0" />
                      <span>{med.medicineName}</span>
                      <span className="text-[10px] text-slate-400">({med.dosage})</span>
                    </div>
                    <div className="text-[11px] font-bold text-teal-700 dark:text-teal-300">
                      {med.frequency} • {med.duration}
                    </div>
                  </div>
                ))}
              </div>

              {/* Advice */}
              {rx.advice && (
                <p className="text-[11px] text-slate-500 italic mb-3">
                  <strong>Advice:</strong> {rx.advice}
                </p>
              )}
            </div>

            {/* Print & Action */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400">
                Followup: <strong>{rx.followUpDate || 'SOS'}</strong>
              </span>

              <button
                onClick={() => handleOpenPrint(rx)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-xl text-xs font-bold transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{t('rx.print')}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Prescription Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title={t('rx.create')}
        subtitle="Issue an electronic prescription slip with dosage schedule."
        maxWidth="2xl"
      >
        <form onSubmit={handleSubmitAdd} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Patient *
              </label>
              <select
                required
                value={formData.patientId}
                onChange={(e) => setFormData({ ...formData, patientId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId}) - {p.age}y/{p.gender}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Prescribing Doctor *
              </label>
              <select
                required
                value={formData.doctorId}
                onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.specialization})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Diagnosis / Clinical Indication *
            </label>
            <input
              type="text"
              required
              value={formData.diagnosis}
              onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
              placeholder="e.g. Acute Pharyngitis, Type 2 Diabetes"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none font-bold"
            />
          </div>

          {/* Medicines Line Items */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-700 dark:text-slate-300">
                Prescribed Medications (Rx)
              </span>
              <button
                type="button"
                onClick={handleAddMedRow}
                className="text-xs font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Medicine</span>
              </button>
            </div>

            {formData.medicines.map((med, idx) => (
              <div
                key={idx}
                className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2"
              >
                <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                  <div className="md:col-span-2">
                    <input
                      type="text"
                      required
                      placeholder="Medicine Name (e.g. Augmentin 625 Duo)"
                      value={med.medicineName}
                      onChange={(e) => handleMedChange(idx, 'medicineName', e.target.value)}
                      className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Dosage (e.g. 500mg / 1 tab)"
                      value={med.dosage}
                      onChange={(e) => handleMedChange(idx, 'dosage', e.target.value)}
                      className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Frequency (e.g. 1-0-1)"
                      value={med.frequency}
                      onChange={(e) => handleMedChange(idx, 'frequency', e.target.value)}
                      className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Duration (e.g. 5 Days)"
                    value={med.duration}
                    onChange={(e) => handleMedChange(idx, 'duration', e.target.value)}
                    className="w-28 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Instructions (e.g. After food with warm water)"
                    value={med.instructions}
                    onChange={(e) => handleMedChange(idx, 'instructions', e.target.value)}
                    className="flex-1 p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  />
                  {formData.medicines.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveMedRow(idx)}
                      className="p-1.5 text-slate-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Doctor's General Advice / Dietary Restrictions
              </label>
              <textarea
                rows={2}
                value={formData.advice}
                onChange={(e) => setFormData({ ...formData, advice: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Scheduled Next Follow-Up Date
              </label>
              <input
                type="date"
                value={formData.followUpDate}
                onChange={(e) => setFormData({ ...formData, followUpDate: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Issue Digital Prescription
            </button>
          </div>
        </form>
      </Modal>

      {/* Printable Prescription Modal */}
      <PrintablePrescriptionModal
        prescription={selectedPrescription}
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
      />
    </div>
  );
};

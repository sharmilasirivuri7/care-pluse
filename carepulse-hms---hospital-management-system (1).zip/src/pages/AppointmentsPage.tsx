import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Calendar,
  Search,
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Stethoscope,
  User,
  Filter,
  ArrowRight,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Appointment, DepartmentType } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const AppointmentsPage: React.FC = () => {
  const {
    language,
    appointments,
    patients,
    doctors,
    departments,
    bookAppointment,
    cancelAppointment,
    completeAppointment,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const [searchParams] = useSearchParams();

  const [searchQuery, setSearchQuery] = useState(searchParams.get('doctor') || '');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'upcoming' | 'completed' | 'cancelled'>('all');
  const [isBookModalOpen, setIsBookModalOpen] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [selectedAppt, setSelectedAppt] = useState<Appointment | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Book Appointment Form State
  const [formData, setFormData] = useState({
    patientId: patients[0]?.id || '',
    patientName: patients[0]?.name || '',
    doctorId: doctors[0]?.id || '',
    department: 'Cardiology' as DepartmentType,
    date: todayStr,
    time: '10:00 AM',
    reason: 'Routine Health Checkup',
    notes: '',
  });

  useEffect(() => {
    const docQuery = searchParams.get('doctor');
    if (docQuery) setSearchQuery(docQuery);
  }, [searchParams]);

  // Filtered Appointments
  const filteredAppointments = appointments.filter((a) => {
    const matchesSearch =
      a.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.appointmentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.department.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (dateFilter === 'today') {
      return a.date === todayStr || a.date === '2026-08-27';
    }
    if (dateFilter === 'upcoming') {
      return a.status === 'Scheduled' || a.status === 'Confirmed';
    }
    if (dateFilter === 'completed') {
      return a.status === 'Completed';
    }
    if (dateFilter === 'cancelled') {
      return a.status === 'Cancelled';
    }
    return true;
  });

  const handleOpenBook = () => {
    setFormData({
      patientId: patients[0]?.id || '',
      patientName: patients[0]?.name || '',
      doctorId: doctors[0]?.id || '',
      department: doctors[0]?.department || 'Cardiology',
      date: todayStr,
      time: '11:00 AM',
      reason: 'General Consultation',
      notes: '',
    });
    setIsBookModalOpen(true);
  };

  const handlePatientSelect = (patId: string) => {
    const p = patients.find((pat) => pat.id === patId);
    if (p) {
      setFormData((prev) => ({
        ...prev,
        patientId: p.id,
        patientName: p.name,
      }));
    }
  };

  const handleDoctorSelect = (docId: string) => {
    const d = doctors.find((doc) => doc.id === docId);
    if (d) {
      setFormData((prev) => ({
        ...prev,
        doctorId: d.id,
        department: d.department,
      }));
    }
  };

  const handleSubmitBook = (e: React.FormEvent) => {
    e.preventDefault();
    const doc = doctors.find((d) => d.id === formData.doctorId);
    const pat = patients.find((p) => p.id === formData.patientId);

    if (!doc || !pat) {
      addToast('Error', 'Please select a valid patient and doctor', 'error');
      return;
    }

    bookAppointment({
      patientId: pat.patientId,
      patientName: pat.name,
      doctorId: doc.id,
      doctorName: doc.name,
      department: formData.department,
      date: formData.date,
      time: formData.time,
      reason: formData.reason,
      status: 'Confirmed',
      notes: formData.notes,
    });

    addToast('Appointment Booked', `Appointment confirmed with ${doc.name} for ${pat.name}.`, 'success');
    setIsBookModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('appt.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage outpatient bookings, doctor consultations, and schedules
          </p>
        </div>

        <button
          id="book-new-appointment-btn"
          onClick={handleOpenBook}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('appt.book')}</span>
        </button>
      </div>

      {/* Filter Tabs & Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Quick Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto w-full md:w-auto">
          {[
            { key: 'all', label: 'All' },
            { key: 'today', label: "Today's" },
            { key: 'upcoming', label: 'Upcoming' },
            { key: 'completed', label: 'Completed' },
            { key: 'cancelled', label: 'Cancelled' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setDateFilter(tab.key as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                dateFilter === tab.key
                  ? 'bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search patient, doctor, ID..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Appointments List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Appointment</th>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Doctor & Dept</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4">Reason / Notes</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No appointments found for the selected criteria.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((appt) => (
                  <tr
                    key={appt.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {appt.appointmentId}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {appt.patientName}
                      </div>
                      <div className="text-[11px] text-slate-400">{appt.patientId}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {appt.doctorName}
                      </div>
                      <div className="text-[11px] text-teal-600 dark:text-teal-400 font-medium">
                        {appt.department}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">{appt.date}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-teal-500" />
                        <span>{appt.time}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 max-w-[200px]">
                      <div className="text-slate-800 dark:text-slate-200 font-medium truncate">
                        {appt.reason}
                      </div>
                      {appt.notes && <div className="text-[10px] text-slate-400 truncate">{appt.notes}</div>}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          appt.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : appt.status === 'Confirmed'
                            ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                            : appt.status === 'Cancelled'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {appt.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {appt.status !== 'Completed' && appt.status !== 'Cancelled' && (
                          <>
                            <button
                              onClick={() => completeAppointment(appt.id)}
                              className="px-2 py-1 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded-lg text-[10px] font-semibold transition-colors flex items-center gap-1"
                              title="Mark Completed"
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Done</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedAppt(appt);
                                setIsCancelConfirmOpen(true);
                              }}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40"
                              title="Cancel Appointment"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Book Appointment Modal */}
      <Modal
        isOpen={isBookModalOpen}
        onClose={() => setIsBookModalOpen(false)}
        title={t('appt.book')}
        subtitle="Schedule a consultation with a hospital doctor."
        maxWidth="xl"
      >
        <form onSubmit={handleSubmitBook} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Patient *
              </label>
              <select
                required
                value={formData.patientId}
                onChange={(e) => handlePatientSelect(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Doctor *
              </label>
              <select
                required
                value={formData.doctorId}
                onChange={(e) => handleDoctorSelect(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} — {d.specialization} ({d.department})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Consultation Date *
              </label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Time Slot *
              </label>
              <select
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {[
                  '09:00 AM',
                  '09:30 AM',
                  '10:00 AM',
                  '10:30 AM',
                  '11:00 AM',
                  '11:30 AM',
                  '12:00 PM',
                  '02:00 PM',
                  '02:30 PM',
                  '03:00 PM',
                  '03:30 PM',
                  '04:00 PM',
                ].map((slot) => (
                  <option key={slot} value={slot}>
                    {slot}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Reason for Visit *
            </label>
            <input
              type="text"
              required
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="e.g. Chest pain follow-up, general fever"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Doctor's Prep / Patient Notes
            </label>
            <textarea
              rows={2}
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Fasting required, bring old reports..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsBookModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Confirm Appointment
            </button>
          </div>
        </form>
      </Modal>

      {/* Cancel Confirmation Dialog */}
      {selectedAppt && (
        <ConfirmDialog
          isOpen={isCancelConfirmOpen}
          onClose={() => setIsCancelConfirmOpen(false)}
          onConfirm={() => {
            cancelAppointment(selectedAppt.id);
            addToast('Appointment Cancelled', `Appointment ${selectedAppt.appointmentId} was cancelled.`, 'info');
          }}
          title={t('appt.cancel_title')}
          message={`Are you sure you want to cancel the appointment for ${selectedAppt.patientName} with ${selectedAppt.doctorName}?`}
          confirmText={t('common.confirm')}
          isDestructive={true}
        />
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  BedDouble,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  AlertTriangle,
  User,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Bed, BedType } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const BedManagementPage: React.FC = () => {
  const {
    language,
    beds,
    patients,
    doctors,
    updateBedStatus,
    addBed,
    admitPatient,
    dischargePatient,
    admissions,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWard, setSelectedWard] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Modals
  const [isAddBedModalOpen, setIsAddBedModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isReleaseConfirmOpen, setIsReleaseConfirmOpen] = useState(false);
  const [selectedBed, setSelectedBed] = useState<Bed | null>(null);

  // Quick Assign Form
  const [assignForm, setAssignForm] = useState({
    patientId: patients[0]?.id || '',
    doctorId: doctors[0]?.id || '',
    deposit: 10000,
  });

  // Add Bed Form
  const [newBedForm, setNewBedForm] = useState({
    bedNumber: 'BED-',
    ward: 'ICU',
    type: 'ICU' as BedType,
    floor: '2nd Floor, Wing A',
    pricePerDay: 4500,
  });

  // Stats
  const totalBeds = beds.length;
  const availableCount = beds.filter((b) => b.status === 'Available').length;
  const occupiedCount = beds.filter((b) => b.status === 'Occupied').length;
  const maintenanceCount = beds.filter((b) => b.status === 'Maintenance').length;
  const occupancyPercent = totalBeds > 0 ? Math.round((occupiedCount / totalBeds) * 100) : 0;

  const wards = Array.from(new Set(beds.map((b) => b.ward)));

  const filteredBeds = beds.filter((b) => {
    const matchesSearch =
      b.bedNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.ward.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.patientName && b.patientName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesWard = selectedWard === 'All' || b.ward === selectedWard;
    const matchesStatus = selectedStatus === 'All' || b.status === selectedStatus;

    return matchesSearch && matchesWard && matchesStatus;
  });

  const handleOpenAssign = (bed: Bed) => {
    setSelectedBed(bed);
    setAssignForm({
      patientId: patients[0]?.id || '',
      doctorId: doctors[0]?.id || '',
      deposit: bed.pricePerDay * 3,
    });
    setIsAssignModalOpen(true);
  };

  const handleOpenRelease = (bed: Bed) => {
    setSelectedBed(bed);
    setIsReleaseConfirmOpen(true);
  };

  const handleConfirmRelease = () => {
    if (!selectedBed) return;
    // Find matching active admission if any
    const activeAdm = admissions.find(
      (a) => a.bedId === selectedBed.id && a.status === 'Admitted'
    );
    if (activeAdm) {
      dischargePatient(activeAdm.id);
    } else {
      updateBedStatus(selectedBed.id, 'Available');
    }
    addToast('Bed Released', `${selectedBed.bedNumber} is now Available.`, 'success');
  };

  const handleSubmitAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBed) return;
    const pat = patients.find((p) => p.id === assignForm.patientId);
    const doc = doctors.find((d) => d.id === assignForm.doctorId);

    if (!pat || !doc) return;

    admitPatient({
      patientId: pat.patientId,
      patientName: pat.name,
      bedId: selectedBed.id,
      bedNumber: selectedBed.bedNumber,
      ward: selectedBed.ward,
      doctorId: doc.id,
      doctorName: doc.name,
      department: pat.department,
      admissionDate: new Date().toISOString().split('T')[0],
      admissionReason: 'Bed assignment admission',
      status: 'Admitted',
      initialDeposit: Number(assignForm.deposit),
    });

    addToast('Bed Assigned', `${pat.name} assigned to ${selectedBed.bedNumber}.`, 'success');
    setIsAssignModalOpen(false);
  };

  const handleSubmitAddBed = (e: React.FormEvent) => {
    e.preventDefault();
    addBed({
      ...newBedForm,
      status: 'Available',
    });
    addToast('Bed Added', `Bed ${newBedForm.bedNumber} created.`, 'success');
    setIsAddBedModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BedDouble className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('bed.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-time ward occupancy map, ICU bed status, and inpatient admissions
          </p>
        </div>

        <button
          onClick={() => {
            setNewBedForm({
              bedNumber: `BED-${beds.length + 101}`,
              ward: 'General Ward',
              type: 'General',
              floor: '1st Floor',
              pricePerDay: 1200,
            });
            setIsAddBedModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('bed.add')}</span>
        </button>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Capacity
          </span>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            {totalBeds} Beds
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Across {wards.length} hospital wings</p>
        </div>

        <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
            Available Free
          </span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {availableCount}
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">
            Ready for admission
          </p>
        </div>

        <div className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400">
            Occupied Inpatients
          </span>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1">
            {occupiedCount}
          </div>
          <p className="text-[11px] text-rose-700 dark:text-rose-300 mt-0.5">
            {occupancyPercent}% Occupancy rate
          </p>
        </div>

        <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Sanitization / Maint
          </span>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
            {maintenanceCount}
          </div>
          <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">Cleaning in progress</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bed number (e.g. ICU-01) or admitted patient..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={selectedWard}
            onChange={(e) => setSelectedWard(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Wards</option>
            {wards.map((w) => (
              <option key={w} value={w}>
                {w}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Available">Available</option>
            <option value="Occupied">Occupied</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Reserved">Reserved</option>
          </select>
        </div>
      </div>

      {/* Visual Bed Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredBeds.map((bed) => {
          const isOccupied = bed.status === 'Occupied';
          const isAvailable = bed.status === 'Available';
          const isMaintenance = bed.status === 'Maintenance';

          return (
            <div
              key={bed.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                isAvailable
                  ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 shadow-xs hover:shadow-md'
                  : isOccupied
                  ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50 shadow-xs'
                  : 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50 shadow-xs'
              }`}
            >
              <div>
                {/* Card Top */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                        isAvailable
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : isOccupied
                          ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                      }`}
                    >
                      <BedDouble className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {bed.bedNumber}
                      </h4>
                      <span className="text-[10px] text-slate-400 font-medium">{bed.type}</span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      isAvailable
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : isOccupied
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    {bed.status}
                  </span>
                </div>

                {/* Ward & Floor */}
                <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300 mb-3">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">Ward:</span>
                    <span className="font-semibold">{bed.ward}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">Location:</span>
                    <span className="font-medium">{bed.floor}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">Daily Tariff:</span>
                    <span className="font-bold text-teal-600 dark:text-teal-400">
                      ₹{bed.pricePerDay.toLocaleString()}/day
                    </span>
                  </div>
                </div>

                {/* Patient Badge if Occupied */}
                {isOccupied && bed.patientName && (
                  <div className="p-2.5 bg-white dark:bg-slate-800/80 rounded-xl border border-rose-100 dark:border-rose-900/30 text-xs mb-2">
                    <span className="text-[10px] text-rose-600 font-bold uppercase tracking-wider block">
                      Admitted Inpatient
                    </span>
                    <div className="font-bold text-slate-900 dark:text-white truncate mt-0.5">
                      {bed.patientName}
                    </div>
                    <div className="text-[10px] text-slate-400">ID: {bed.patientId}</div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between gap-2 mt-2">
                {isAvailable ? (
                  <button
                    onClick={() => handleOpenAssign(bed)}
                    className="w-full py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-2xs transition-colors text-center"
                  >
                    Assign Patient
                  </button>
                ) : isOccupied ? (
                  <button
                    onClick={() => handleOpenRelease(bed)}
                    className="w-full py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold shadow-2xs transition-colors text-center"
                  >
                    Release Bed
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      updateBedStatus(bed.id, 'Available');
                      addToast('Status Updated', `${bed.bedNumber} is now Available.`, 'success');
                    }}
                    className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-colors text-center"
                  >
                    Mark Available
                  </button>
                )}

                {/* Status Switcher icon */}
                <select
                  value={bed.status}
                  onChange={(e) => updateBedStatus(bed.id, e.target.value as any)}
                  className="px-2 py-1 text-[10px] bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-600 dark:text-slate-300 focus:outline-none"
                >
                  <option value="Available">Free</option>
                  <option value="Occupied">Occ</option>
                  <option value="Maintenance">Maint</option>
                  <option value="Reserved">Res</option>
                </select>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Assign Patient Modal */}
      {selectedBed && (
        <Modal
          isOpen={isAssignModalOpen}
          onClose={() => setIsAssignModalOpen(false)}
          title={`Assign Bed: ${selectedBed.bedNumber}`}
          subtitle={`${selectedBed.ward} • ${selectedBed.type} (₹${selectedBed.pricePerDay}/day)`}
          maxWidth="md"
        >
          <form onSubmit={handleSubmitAssign} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Patient *
              </label>
              <select
                required
                value={assignForm.patientId}
                onChange={(e) => setAssignForm({ ...assignForm, patientId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId}) — {p.bloodGroup}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Attending Doctor *
              </label>
              <select
                required
                value={assignForm.doctorId}
                onChange={(e) => setAssignForm({ ...assignForm, doctorId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.department})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Admission Initial Deposit (₹)
              </label>
              <input
                type="number"
                min="0"
                value={assignForm.deposit}
                onChange={(e) => setAssignForm({ ...assignForm, deposit: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsAssignModalOpen(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
              >
                {t('common.cancel')}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
              >
                Confirm Bed Assignment
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Add New Bed Modal */}
      <Modal
        isOpen={isAddBedModalOpen}
        onClose={() => setIsAddBedModalOpen(false)}
        title={t('bed.add')}
        subtitle="Register a new hospital bed in the ward registry."
        maxWidth="md"
      >
        <form onSubmit={handleSubmitAddBed} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Bed Number / Identifier *
            </label>
            <input
              type="text"
              required
              value={newBedForm.bedNumber}
              onChange={(e) => setNewBedForm({ ...newBedForm, bedNumber: e.target.value })}
              placeholder="e.g. ICU-05 or GEN-201"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Ward Name *
            </label>
            <input
              type="text"
              required
              value={newBedForm.ward}
              onChange={(e) => setNewBedForm({ ...newBedForm, ward: e.target.value })}
              placeholder="e.g. Intensive Care Unit, Male Surgical Ward"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Bed Category *
              </label>
              <select
                value={newBedForm.type}
                onChange={(e) => setNewBedForm({ ...newBedForm, type: e.target.value as any })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="General">General</option>
                <option value="ICU">ICU</option>
                <option value="Semi-Private">Semi-Private</option>
                <option value="VIP Suite">VIP Suite</option>
                <option value="Pediatric">Pediatric</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Price Per Day (₹)
              </label>
              <input
                type="number"
                min="0"
                value={newBedForm.pricePerDay}
                onChange={(e) => setNewBedForm({ ...newBedForm, pricePerDay: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Floor / Wing Location
            </label>
            <input
              type="text"
              value={newBedForm.floor}
              onChange={(e) => setNewBedForm({ ...newBedForm, floor: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddBedModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Save New Bed
            </button>
          </div>
        </form>
      </Modal>

      {/* Release Bed Safety Confirmation */}
      {selectedBed && (
        <ConfirmDialog
          isOpen={isReleaseConfirmOpen}
          onClose={() => setIsReleaseConfirmOpen(false)}
          onConfirm={handleConfirmRelease}
          title="Release Bed"
          message={`Are you sure you want to release ${selectedBed.bedNumber}? This will mark the bed as Available.`}
          confirmText="Release Bed"
          isDestructive={false}
        />
      )}
    </div>
  );
};

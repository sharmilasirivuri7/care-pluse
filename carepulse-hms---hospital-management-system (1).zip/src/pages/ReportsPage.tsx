import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  Calendar,
  Filter,
  FileSpreadsheet,
  TrendingUp,
  Users,
  BedDouble,
  Receipt,
  Pill,
  FlaskConical,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';

export const ReportsPage: React.FC = () => {
  const {
    language,
    patients,
    doctors,
    appointments,
    admissions,
    beds,
    invoices,
    medicines,
    labTests,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const [dateRange, setDateRange] = useState('This Month');

  // Revenue By Month Analytics
  const monthlyRevenueData = [
    { month: 'Mar', revenue: 245000, admissions: 34, appointments: 110 },
    { month: 'Apr', revenue: 310000, admissions: 42, appointments: 145 },
    { month: 'May', revenue: 280000, admissions: 38, appointments: 130 },
    { month: 'Jun', revenue: 390000, admissions: 52, appointments: 165 },
    { month: 'Jul', revenue: 425000, admissions: 58, appointments: 190 },
    { month: 'Aug', revenue: 480000, admissions: 64, appointments: 210 },
  ];

  // Department Patient Load
  const deptData = [
    { name: 'Cardiology', value: 28, color: '#0d9488' },
    { name: 'Neurology', value: 16, color: '#0284c7' },
    { name: 'Pediatrics', value: 22, color: '#f59e0b' },
    { name: 'Orthopedics', value: 18, color: '#8b5cf6' },
    { name: 'General Medicine', value: 35, color: '#10b981' },
    { name: 'Oncology', value: 12, color: '#f43f5e' },
  ];

  // Export functions
  const exportCSV = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.map((val) => `"${val}"`).join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('Report Exported', `${filename}.csv downloaded.`, 'success');
  };

  const handleExportPatients = () => {
    const headers = ['Patient ID', 'Name', 'Age', 'Gender', 'Blood Group', 'Phone', 'Department', 'Status', 'Registered Date'];
    const rows = patients.map((p) => [
      p.patientId,
      p.name,
      p.age,
      p.gender,
      p.bloodGroup,
      p.phone,
      p.department,
      p.status,
      p.registeredDate,
    ]);
    exportCSV('Hospital_Patients_Registry', headers, rows);
  };

  const handleExportBilling = () => {
    const headers = ['Invoice ID', 'Patient ID', 'Patient Name', 'Date', 'Due Date', 'Total (INR)', 'Paid (INR)', 'Remaining (INR)', 'Status'];
    const rows = invoices.map((i) => [
      i.invoiceId,
      i.patientId,
      i.patientName,
      i.date,
      i.dueDate,
      i.total,
      i.paidAmount,
      i.remainingAmount,
      i.status,
    ]);
    exportCSV('Hospital_Revenue_Billing_Ledger', headers, rows);
  };

  const handleExportPharmacy = () => {
    const headers = ['Brand Name', 'Generic Name', 'Category', 'Stock Qty', 'Unit', 'Unit Price (INR)', 'Total Value (INR)', 'Batch', 'Expiry Date', 'Status'];
    const rows = medicines.map((m) => [
      m.name,
      m.genericName,
      m.category,
      m.stock,
      m.unit,
      m.pricePerUnit,
      m.stock * m.pricePerUnit,
      m.batchNumber,
      m.expiryDate,
      m.status,
    ]);
    exportCSV('Hospital_Pharmacy_Inventory', headers, rows);
  };

  const handleExportLab = () => {
    const headers = ['Test ID', 'Test Name', 'Category', 'Patient ID', 'Patient Name', 'Doctor', 'Price (INR)', 'Order Date', 'Status'];
    const rows = labTests.map((t) => [
      t.testId,
      t.testName,
      t.category,
      t.patientId,
      t.patientName,
      t.doctorName,
      t.price,
      t.orderDate,
      t.status,
    ]);
    exportCSV('Hospital_Diagnostic_Requisitions', headers, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('rep.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Executive clinical intelligence, revenue ledgers, and downloadable statistical reports
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 text-xs bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none font-semibold shadow-xs"
          >
            <option value="This Month">Current Month (August 2026)</option>
            <option value="Last Quarter">Last Quarter (Q2 2026)</option>
            <option value="Fiscal Year">Fiscal Year 2026-27</option>
          </select>
        </div>
      </div>

      {/* Quick Export Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Patients Master</h4>
              <p className="text-[11px] text-slate-400">{patients.length} records</p>
            </div>
          </div>
          <button
            onClick={handleExportPatients}
            className="w-full flex items-center justify-center gap-1.5 py-2 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-xl text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Financial Ledger</h4>
              <p className="text-[11px] text-slate-400">{invoices.length} invoices</p>
            </div>
          </div>
          <button
            onClick={handleExportBilling}
            className="w-full flex items-center justify-center gap-1.5 py-2 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Pharmacy Stock</h4>
              <p className="text-[11px] text-slate-400">{medicines.length} SKUs</p>
            </div>
          </div>
          <button
            onClick={handleExportPharmacy}
            className="w-full flex items-center justify-center gap-1.5 py-2 bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 hover:bg-amber-100 rounded-xl text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center justify-center font-bold">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Lab Diagnostics</h4>
              <p className="text-[11px] text-slate-400">{labTests.length} tests</p>
            </div>
          </div>
          <button
            onClick={handleExportLab}
            className="w-full flex items-center justify-center gap-1.5 py-2 bg-sky-50 dark:bg-sky-950 text-sky-700 dark:text-sky-300 hover:bg-sky-100 rounded-xl text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue & Admissions Trend */}
        <div className="lg:col-span-2 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Monthly Clinical Revenue & Inpatient Admissions
              </h3>
              <p className="text-xs text-slate-400">6-Month Trend Overview</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1 text-teal-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-600 inline-block" /> Revenue (₹)
              </span>
              <span className="flex items-center gap-1 text-sky-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500 inline-block" /> Admissions
              </span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyRevenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="revenue" fill="#0d9488" radius={[6, 6, 0, 0]} name="Revenue (₹)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department Patient Share */}
        <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
              Department Patient Inflow
            </h3>
            <p className="text-xs text-slate-400 mb-4">Patient volume by clinical specialty</p>

            <div className="h-52 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={deptData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {deptData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontSize: '11px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
            {deptData.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5 text-[11px]">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-slate-600 dark:text-slate-300 truncate">{item.name}</span>
                <span className="font-bold text-slate-900 dark:text-white ml-auto">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

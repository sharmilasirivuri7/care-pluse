import React, { useState } from 'react';
import {
  FileText,
  Search,
  Plus,
  HeartPulse,
  Activity,
  User,
  Calendar,
  Eye,
  Trash2,
  Stethoscope,
  Paperclip,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { MedicalRecord, DepartmentType } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const MedicalRecordsPage: React.FC = () => {
  const {
    language,
    medicalRecords,
    patients,
    doctors,
    departments,
    addMedicalRecord,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    patientId: patients[0]?.id || '',
    doctorId: doctors[0]?.id || '',
    department: 'Cardiology' as DepartmentType,
    date: new Date().toISOString().split('T')[0],
    diagnosis: 'Essential Hypertension Grade 1',
    symptoms: 'Mild dizziness, occasional morning headaches',
    treatment: 'Lifestyle modification, low sodium diet, Telmisartan 40mg OD',
    vitals: {
      bloodPressure: '138/88 mmHg',
      heartRate: '76 bpm',
      temperature: '98.4 °F',
      spo2: '99%',
    },
    notes: 'Follow-up in 4 weeks with lipid profile.',
  });

  const filteredRecords = medicalRecords.filter((rec) => {
    const matchesSearch =
      rec.recordId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.diagnosis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.doctorName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDept = selectedDept === 'All' || rec.department === selectedDept;

    return matchesSearch && matchesDept;
  });

  const handleOpenAdd = () => {
    setFormData({
      patientId: patients[0]?.id || '',
      doctorId: doctors[0]?.id || '',
      department: 'Cardiology',
      date: new Date().toISOString().split('T')[0],
      diagnosis: 'Type 2 Diabetes Mellitus - Followup',
      symptoms: 'Polyuria, fatigue, slight blurring',
      treatment: 'Metformin 500mg BD after meals, dietary counsel',
      vitals: {
        bloodPressure: '120/80 mmHg',
        heartRate: '72 bpm',
        temperature: '98.6 °F',
        spo2: '98%',
      },
      notes: 'HbA1c test scheduled for next month.',
    });
    setIsAddModalOpen(true);
  };

  const handlePatientSelect = (patId: string) => {
    const p = patients.find((pat) => pat.id === patId);
    if (p) {
      setFormData((prev) => ({
        ...prev,
        patientId: p.id,
        department: p.department,
      }));
    }
  };

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patients.find((p) => p.id === formData.patientId);
    const doc = doctors.find((d) => d.id === formData.doctorId);

    if (!pat || !doc) return;

    addMedicalRecord({
      patientId: pat.patientId,
      patientName: pat.name,
      doctorId: doc.id,
      doctorName: doc.name,
      department: formData.department,
      date: formData.date,
      diagnosis: formData.diagnosis,
      symptoms: formData.symptoms,
      treatment: formData.treatment,
      vitals: formData.vitals,
      notes: formData.notes,
      attachments: ['Lab_Report_CBC.pdf', 'ECG_Tracing.jpg'],
    });

    addToast('EHR Record Saved', `Medical record logged for ${pat.name}.`, 'success');
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('rec.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Electronic Health Records (EHR), clinical encounter summaries, and patient vitals
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('rec.add')}</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search record ID, diagnosis, patient name, doctor..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <select
          value={selectedDept}
          onChange={(e) => setSelectedDept(e.target.value)}
          className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
        >
          <option value="All">All Departments</option>
          {departments.map((d) => (
            <option key={d.id} value={d.name}>
              {d.name}
            </option>
          ))}
        </select>
      </div>

      {/* Records Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Record ID</th>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Clinical Diagnosis</th>
                <th className="py-3.5 px-4">Physician & Dept</th>
                <th className="py-3.5 px-4">Recorded Vitals</th>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No electronic health records found.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr
                    key={rec.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {rec.recordId}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {rec.patientName}
                      </div>
                      <div className="text-[11px] text-slate-400">{rec.patientId}</div>
                    </td>

                    <td className="py-3.5 px-4 max-w-[220px]">
                      <div className="font-bold text-teal-700 dark:text-teal-400 truncate">
                        {rec.diagnosis}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">{rec.symptoms}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {rec.doctorName}
                      </div>
                      <div className="text-[11px] text-slate-400">{rec.department}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-semibold text-slate-700 dark:text-slate-300">
                          BP: {rec.vitals.bloodPressure}
                        </span>
                        <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-semibold text-slate-700 dark:text-slate-300">
                          HR: {rec.vitals.heartRate}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-900 dark:text-white font-medium">{rec.date}</div>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => {
                          setSelectedRecord(rec);
                          setIsViewModalOpen(true);
                        }}
                        className="px-2.5 py-1 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ml-auto"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View EHR</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Medical Record Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title={t('rec.add')}
        subtitle="Log a new clinical encounter with examination findings and treatment regimen."
        maxWidth="xl"
      >
        <form onSubmit={handleSubmitAdd} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Patient *
              </label>
              <select
                required
                value={formData.patientId}
                onChange={(e) => handlePatientSelect(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Attending Doctor *
              </label>
              <select
                required
                value={formData.doctorId}
                onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.department})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Primary Diagnosis *
            </label>
            <input
              type="text"
              required
              value={formData.diagnosis}
              onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
              placeholder="e.g. Acute Bronchitis, Essential Hypertension"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none font-bold"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Chief Complaints & Symptoms
            </label>
            <textarea
              rows={2}
              value={formData.symptoms}
              onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
              placeholder="Patient reported symptoms..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          {/* Vitals Grid */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="font-bold text-slate-700 dark:text-slate-300 block mb-2">
              Vital Signs at Examination
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="text-[11px] text-slate-500">Blood Pressure</label>
                <input
                  type="text"
                  value={formData.vitals.bloodPressure}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      vitals: { ...formData.vitals, bloodPressure: e.target.value },
                    })
                  }
                  className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500">Heart Rate</label>
                <input
                  type="text"
                  value={formData.vitals.heartRate}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      vitals: { ...formData.vitals, heartRate: e.target.value },
                    })
                  }
                  className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500">Temperature</label>
                <input
                  type="text"
                  value={formData.vitals.temperature}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      vitals: { ...formData.vitals, temperature: e.target.value },
                    })
                  }
                  className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500">SpO2 Oxygen</label>
                <input
                  type="text"
                  value={formData.vitals.spo2}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      vitals: { ...formData.vitals, spo2: e.target.value },
                    })
                  }
                  className="w-full p-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Treatment Plan & Clinical Orders
            </label>
            <textarea
              rows={2}
              value={formData.treatment}
              onChange={(e) => setFormData({ ...formData, treatment: e.target.value })}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Save Medical Record
            </button>
          </div>
        </form>
      </Modal>

      {/* View EHR Record Modal */}
      {selectedRecord && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`EHR Encounter: ${selectedRecord.recordId}`}
          maxWidth="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex justify-between items-center">
              <div>
                <span className="text-[10px] text-slate-400 font-semibold uppercase block">Patient</span>
                <span className="font-bold text-sm text-slate-900 dark:text-white">{selectedRecord.patientName}</span>
                <span className="text-slate-500 text-[11px] block">{selectedRecord.patientId}</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 font-semibold uppercase block">Physician</span>
                <span className="font-bold text-sm text-teal-700 dark:text-teal-400">{selectedRecord.doctorName}</span>
                <span className="text-slate-500 text-[11px] block">{selectedRecord.department} • {selectedRecord.date}</span>
              </div>
            </div>

            <div className="p-3.5 bg-teal-50/50 dark:bg-teal-950/30 rounded-xl border border-teal-100 dark:border-teal-900/40">
              <span className="font-bold text-teal-900 dark:text-teal-200 text-xs block mb-1">Primary Diagnosis</span>
              <p className="text-sm font-semibold text-slate-900 dark:text-white">{selectedRecord.diagnosis}</p>
            </div>

            <div>
              <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Recorded Symptoms</span>
              <p className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-300">
                {selectedRecord.symptoms}
              </p>
            </div>

            {/* Vitals Strip */}
            <div className="grid grid-cols-4 gap-2 text-center p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl font-medium">
              <div>
                <span className="text-[10px] text-slate-400 block">BP</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedRecord.vitals.bloodPressure}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Pulse</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedRecord.vitals.heartRate}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Temp</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedRecord.vitals.temperature}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">SpO2</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedRecord.vitals.spo2}</span>
              </div>
            </div>

            <div>
              <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Prescribed Treatment</span>
              <p className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-300">
                {selectedRecord.treatment}
              </p>
            </div>

            {selectedRecord.notes && (
              <div>
                <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Clinical Followup Notes</span>
                <p className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-500">
                  {selectedRecord.notes}
                </p>
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setIsViewModalOpen(false)}
                className="px-4 py-2 bg-teal-600 text-white font-bold rounded-xl text-xs"
              >
                Close Encounter Record
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

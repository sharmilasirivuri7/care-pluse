import React, { useState } from 'react';
import {
  UserPlus,
  Search,
  Plus,
  LogOut,
  BedDouble,
  Calendar,
  Phone,
  AlertCircle,
  FileText,
  UserCheck,
  Building,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Admission, DepartmentType } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const AdmissionsPage: React.FC = () => {
  const {
    language,
    admissions,
    patients,
    doctors,
    beds,
    admitPatient,
    dischargePatient,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Admitted' | 'Discharged'>('All');

  // Modals
  const [isAdmitModalOpen, setIsAdmitModalOpen] = useState(false);
  const [isDischargeConfirmOpen, setIsDischargeConfirmOpen] = useState(false);
  const [selectedAdmission, setSelectedAdmission] = useState<Admission | null>(null);

  const availableBeds = beds.filter((b) => b.status === 'Available');

  // Form State
  const [formData, setFormData] = useState({
    patientId: patients[0]?.id || '',
    bedId: availableBeds[0]?.id || '',
    doctorId: doctors[0]?.id || '',
    department: 'General Medicine' as DepartmentType,
    admissionDate: new Date().toISOString().split('T')[0],
    admissionReason: 'Severe acute medical condition requiring hospitalization',
    initialDeposit: 10000,
    emergencyContact: '',
  });

  const filteredAdmissions = admissions.filter((adm) => {
    const matchesSearch =
      adm.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.patientId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.bedNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.doctorName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || adm.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAdmit = () => {
    if (availableBeds.length === 0) {
      addToast('No Available Beds', 'All hospital beds are currently occupied or under maintenance.', 'warning');
      return;
    }

    setFormData({
      patientId: patients[0]?.id || '',
      bedId: availableBeds[0]?.id || '',
      doctorId: doctors[0]?.id || '',
      department: 'General Medicine',
      admissionDate: new Date().toISOString().split('T')[0],
      admissionReason: 'Inpatient observation and treatment protocol',
      initialDeposit: 15000,
      emergencyContact: patients[0]?.emergencyContact || 'Family Member',
    });
    setIsAdmitModalOpen(true);
  };

  const handlePatientSelect = (patId: string) => {
    const p = patients.find((pat) => pat.id === patId);
    if (p) {
      setFormData((prev) => ({
        ...prev,
        patientId: p.id,
        department: p.department,
        emergencyContact: p.emergencyContact,
      }));
    }
  };

  const handleSubmitAdmit = (e: React.FormEvent) => {
    e.preventDefault();
    const pat = patients.find((p) => p.id === formData.patientId);
    const targetBed = beds.find((b) => b.id === formData.bedId);
    const doc = doctors.find((d) => d.id === formData.doctorId);

    if (!pat || !targetBed || !doc) {
      addToast('Validation Error', 'Please select a valid patient, bed, and doctor.', 'error');
      return;
    }

    admitPatient({
      patientId: pat.patientId,
      patientName: pat.name,
      bedId: targetBed.id,
      bedNumber: targetBed.bedNumber,
      ward: targetBed.ward,
      doctorId: doc.id,
      doctorName: doc.name,
      department: formData.department,
      admissionDate: formData.admissionDate,
      admissionReason: formData.admissionReason,
      status: 'Admitted',
      initialDeposit: Number(formData.initialDeposit),
    });

    addToast('Patient Admitted', `${pat.name} admitted to ${targetBed.bedNumber} (${targetBed.ward}).`, 'success');
    setIsAdmitModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('adm.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage inpatient registrations, ward assignments, and discharge protocols
          </p>
        </div>

        <button
          onClick={handleOpenAdmit}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('adm.admit_patient')}</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search admissions by patient name, bed number, or doctor..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
          className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
        >
          <option value="All">All Admissions</option>
          <option value="Admitted">Currently Admitted</option>
          <option value="Discharged">Discharged</option>
        </select>
      </div>

      {/* Admissions Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Admission ID</th>
                <th className="py-3.5 px-4">Patient</th>
                <th className="py-3.5 px-4">Bed & Ward</th>
                <th className="py-3.5 px-4">Doctor & Dept</th>
                <th className="py-3.5 px-4">Admission Date</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredAdmissions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No admission records found.
                  </td>
                </tr>
              ) : (
                filteredAdmissions.map((adm) => (
                  <tr
                    key={adm.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {adm.admissionId}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {adm.patientName}
                      </div>
                      <div className="text-[11px] text-slate-400">{adm.patientId}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                        <BedDouble className="w-3.5 h-3.5" />
                        <span>{adm.bedNumber}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">{adm.ward}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {adm.doctorName}
                      </div>
                      <div className="text-[11px] text-slate-400">{adm.department}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-900 dark:text-white">
                        {adm.admissionDate}
                      </div>
                      {adm.dischargeDate && (
                        <div className="text-[11px] text-slate-400">
                          Discharged: {adm.dischargeDate}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          adm.status === 'Admitted'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {adm.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      {adm.status === 'Admitted' && (
                        <button
                          onClick={() => {
                            setSelectedAdmission(adm);
                            setIsDischargeConfirmOpen(true);
                          }}
                          className="flex items-center gap-1 ml-auto px-2.5 py-1 bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 hover:bg-rose-100 rounded-lg text-xs font-semibold transition-colors"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>{t('adm.discharge')}</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admit Patient Modal */}
      <Modal
        isOpen={isAdmitModalOpen}
        onClose={() => setIsAdmitModalOpen(false)}
        title={t('adm.admit_patient')}
        subtitle="Assign an available hospital bed and attending physician."
        maxWidth="xl"
      >
        <form onSubmit={handleSubmitAdmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Patient *
              </label>
              <select
                required
                value={formData.patientId}
                onChange={(e) => handlePatientSelect(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientId}) - {p.bloodGroup}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Available Bed *
              </label>
              <select
                required
                value={formData.bedId}
                onChange={(e) => setFormData({ ...formData, bedId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {availableBeds.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.bedNumber} — {b.ward} ({b.type}) ₹{b.pricePerDay}/day
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Attending Doctor *
              </label>
              <select
                required
                value={formData.doctorId}
                onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} — {d.department}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Admission Date *
              </label>
              <input
                type="date"
                required
                value={formData.admissionDate}
                onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Admission Reason & Preliminary Diagnosis *
            </label>
            <input
              type="text"
              required
              value={formData.admissionReason}
              onChange={(e) => setFormData({ ...formData, admissionReason: e.target.value })}
              placeholder="e.g. Acute myocardial infarction, post-op care"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Initial Security Deposit (₹)
              </label>
              <input
                type="number"
                min="0"
                value={formData.initialDeposit}
                onChange={(e) => setFormData({ ...formData, initialDeposit: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Emergency Attendant
              </label>
              <input
                type="text"
                value={formData.emergencyContact}
                onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAdmitModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Admit Patient
            </button>
          </div>
        </form>
      </Modal>

      {/* Discharge Confirmation Dialog */}
      {selectedAdmission && (
        <ConfirmDialog
          isOpen={isDischargeConfirmOpen}
          onClose={() => setIsDischargeConfirmOpen(false)}
          onConfirm={() => {
            dischargePatient(selectedAdmission.id);
            addToast('Patient Discharged', `${selectedAdmission.patientName} discharged. Bed ${selectedAdmission.bedNumber} is now marked Available.`, 'success');
          }}
          title={t('adm.discharge_title')}
          message={`Are you sure you want to discharge ${selectedAdmission.patientName} from ${selectedAdmission.bedNumber} (${selectedAdmission.ward})? This will release the bed and finalize inpatient stay.`}
          confirmText={t('adm.discharge')}
          isDestructive={false}
        />
      )}
    </div>
  );
};

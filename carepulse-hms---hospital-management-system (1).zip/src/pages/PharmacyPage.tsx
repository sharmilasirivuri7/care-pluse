import React, { useState } from 'react';
import {
  Pill,
  Search,
  Plus,
  AlertTriangle,
  PackageCheck,
  PackageX,
  Edit2,
  Trash2,
  RefreshCw,
  Clock,
  Layers,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';
import { Medicine } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';

export const PharmacyPage: React.FC = () => {
  const {
    language,
    medicines,
    addMedicine,
    updateMedicineStock,
    deleteMedicine,
    addToast,
  } = useHospital();

  const t = useTranslation(language);

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [stockFilter, setStockFilter] = useState<string>('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);

  // Add Medicine Form
  const [newMedForm, setNewMedForm] = useState({
    name: '',
    genericName: '',
    category: 'Antibiotic',
    stock: 100,
    unit: 'Tablets',
    pricePerUnit: 15,
    batchNumber: 'BT-2026-',
    expiryDate: '2027-12-31',
    reorderLevel: 30,
    manufacturer: 'Sun Pharma',
  });

  // Stock Adjustment Form
  const [stockAdjustment, setStockAdjustment] = useState(50);

  // Pharmacy KPIs
  const totalStockItems = medicines.length;
  const lowStockCount = medicines.filter((m) => {
    const qty = m.stockQuantity ?? m.stock ?? 0;
    const threshold = m.minThreshold ?? m.reorderLevel ?? 20;
    return qty <= threshold && qty > 0;
  }).length;
  const outOfStockCount = medicines.filter((m) => (m.stockQuantity ?? m.stock ?? 0) === 0).length;
  const totalInventoryValue = medicines.reduce((sum, m) => {
    const qty = m.stockQuantity ?? m.stock ?? 0;
    const price = m.unitPrice ?? m.pricePerUnit ?? 0;
    return sum + qty * price;
  }, 0);

  const categories = Array.from(new Set(medicines.map((m) => m.category)));

  const filteredMedicines = medicines.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.genericName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.batchNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.manufacturer.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === 'All' || m.category === categoryFilter;

    const qty = m.stockQuantity ?? m.stock ?? 0;
    const threshold = m.minThreshold ?? m.reorderLevel ?? 20;

    let matchesStock = true;
    if (stockFilter === 'In Stock') matchesStock = qty > threshold;
    if (stockFilter === 'Low Stock') matchesStock = qty <= threshold && qty > 0;
    if (stockFilter === 'Out of Stock') matchesStock = qty === 0;

    return matchesSearch && matchesCategory && matchesStock;
  });

  const handleOpenAdd = () => {
    setNewMedForm({
      name: '',
      genericName: '',
      category: 'Antibiotics',
      stock: 150,
      unit: 'Tablets',
      pricePerUnit: 18,
      batchNumber: `BT-${Math.floor(1000 + Math.random() * 9000)}`,
      expiryDate: '2028-06-30',
      reorderLevel: 40,
      manufacturer: 'Cipla Ltd',
    });
    setIsAddModalOpen(true);
  };

  const handleOpenStock = (m: Medicine) => {
    setSelectedMedicine(m);
    setStockAdjustment(50);
    setIsStockModalOpen(true);
  };

  const handleSubmitAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedForm.name.trim()) return;

    const qty = newMedForm.stock;
    const threshold = newMedForm.reorderLevel;
    let status: 'In Stock' | 'Low Stock' | 'Out of Stock' = 'In Stock';
    if (qty === 0) status = 'Out of Stock';
    else if (qty <= threshold) status = 'Low Stock';

    addMedicine({
      name: newMedForm.name,
      genericName: newMedForm.genericName,
      category: newMedForm.category as any,
      manufacturer: newMedForm.manufacturer,
      batchNumber: newMedForm.batchNumber,
      expiryDate: newMedForm.expiryDate,
      stockQuantity: newMedForm.stock,
      minThreshold: newMedForm.reorderLevel,
      unitPrice: newMedForm.pricePerUnit,
      location: 'Shelf A-1',
      dosageForm: (newMedForm.unit === 'Tablets' ? 'Tablet' : 'Syrup') as any,
      stock: newMedForm.stock,
      reorderLevel: newMedForm.reorderLevel,
      pricePerUnit: newMedForm.pricePerUnit,
      unit: newMedForm.unit,
      status,
    });

    addToast('Medicine Added', `${newMedForm.name} added to pharmacy inventory.`, 'success');
    setIsAddModalOpen(false);
  };

  const handleSubmitStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMedicine) return;

    const newStock = selectedMedicine.stock + Number(stockAdjustment);
    if (newStock < 0) {
      addToast('Invalid Quantity', 'Stock cannot be negative.', 'error');
      return;
    }

    updateMedicineStock(selectedMedicine.id, newStock);
    addToast('Stock Updated', `${selectedMedicine.name} stock updated to ${newStock} units.`, 'success');
    setIsStockModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Pill className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('pharm.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Pharmacy medication inventory, batch tracking, expiry monitoring, and stock alerts
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-md transition-all active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{t('pharm.add')}</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total SKUs
          </span>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            {totalStockItems} Items
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">{categories.length} Drug categories</p>
        </div>

        <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
            Inventory Valuation
          </span>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1 truncate">
            ₹{totalInventoryValue.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-300 mt-0.5">Asset value</p>
        </div>

        <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Low Stock Alerts
          </span>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">
            {lowStockCount}
          </div>
          <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">Needs reorder</p>
        </div>

        <div className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400">
            Out of Stock
          </span>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-1">
            {outOfStockCount}
          </div>
          <p className="text-[11px] text-rose-700 dark:text-rose-300 mt-0.5">Urgent purchase</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search brand name, generic name, batch number, manufacturer..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:outline-none"
          >
            <option value="All">All Stock Levels</option>
            <option value="In Stock">In Stock</option>
            <option value="Low Stock">Low Stock</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
        </div>
      </div>

      {/* Medicines Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Medicine & Formulation</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Batch & Expiry</th>
                <th className="py-3.5 px-4">Current Stock</th>
                <th className="py-3.5 px-4">Unit Price</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No medications found matching the filters.
                  </td>
                </tr>
              ) : (
                filteredMedicines.map((med) => (
                  <tr
                    key={med.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <Pill className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                        <span>{med.name}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {med.genericName} • {med.manufacturer}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-md font-medium text-[11px]">
                        {med.category}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-800 dark:text-slate-200">
                        {med.batchNumber}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>Exp: {med.expiryDate}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white text-sm">
                        {med.stockQuantity ?? med.stock ?? 0}{' '}
                        <span className="text-[10px] text-slate-400 font-normal">
                          {med.dosageForm ?? med.unit ?? 'Units'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Reorder at &le; {med.minThreshold ?? med.reorderLevel ?? 20}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-teal-700 dark:text-teal-400">
                        ₹{med.unitPrice ?? med.pricePerUnit ?? 0}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      {(() => {
                        const qty = med.stockQuantity ?? med.stock ?? 0;
                        const threshold = med.minThreshold ?? med.reorderLevel ?? 20;
                        const status = qty === 0 ? 'Out of Stock' : qty <= threshold ? 'Low Stock' : 'In Stock';
                        return (
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              status === 'In Stock'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : status === 'Low Stock'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            }`}
                          >
                            {status}
                          </span>
                        );
                      })()}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenStock(med)}
                          className="px-2 py-1 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          title="Adjust Stock"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Restock</span>
                        </button>
                        <button
                          onClick={() => {
                            setSelectedMedicine(med);
                            setIsDeleteConfirmOpen(true);
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Delete Medicine"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Medicine Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title={t('pharm.add')}
        subtitle="Add a new pharmaceutical product to inventory."
        maxWidth="xl"
      >
        <form onSubmit={handleSubmitAdd} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Brand Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Augmentin 625 Duo"
                value={newMedForm.name}
                onChange={(e) => setNewMedForm({ ...newMedForm, name: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Generic Formula *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Amoxicillin + Clavulanic Acid"
                value={newMedForm.genericName}
                onChange={(e) => setNewMedForm({ ...newMedForm, genericName: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                value={newMedForm.category}
                onChange={(e) => setNewMedForm({ ...newMedForm, category: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="Antibiotic">Antibiotic</option>
                <option value="Cardiovascular">Cardiovascular</option>
                <option value="Antidiabetic">Antidiabetic</option>
                <option value="Analgesic">Analgesic (Pain Relief)</option>
                <option value="Respiratory">Respiratory</option>
                <option value="Gastrointestinal">Gastrointestinal</option>
                <option value="Antiviral">Antiviral</option>
                <option value="Injectable">Injectable / IV Solution</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Unit of Measure
              </label>
              <select
                value={newMedForm.unit}
                onChange={(e) => setNewMedForm({ ...newMedForm, unit: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              >
                <option value="Tablets">Tablets</option>
                <option value="Capsules">Capsules</option>
                <option value="Vial">Vials</option>
                <option value="Ampoules">Ampoules</option>
                <option value="Bottles">Bottles (Syrup)</option>
                <option value="Ointment">Tubes (Ointment)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Initial Stock Quantity *
              </label>
              <input
                type="number"
                min="0"
                required
                value={newMedForm.stock}
                onChange={(e) => setNewMedForm({ ...newMedForm, stock: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Unit Retail Price (₹) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={newMedForm.pricePerUnit}
                onChange={(e) => setNewMedForm({ ...newMedForm, pricePerUnit: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Batch Number
              </label>
              <input
                type="text"
                value={newMedForm.batchNumber}
                onChange={(e) => setNewMedForm({ ...newMedForm, batchNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Expiry Date
              </label>
              <input
                type="date"
                required
                value={newMedForm.expiryDate}
                onChange={(e) => setNewMedForm({ ...newMedForm, expiryDate: e.target.value })}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
            >
              Save to Pharmacy
            </button>
          </div>
        </form>
      </Modal>

      {/* Adjust Stock Modal */}
      {selectedMedicine && (
        <Modal
          isOpen={isStockModalOpen}
          onClose={() => setIsStockModalOpen(false)}
          title={`Restock: ${selectedMedicine.name}`}
          subtitle={`Current stock: ${selectedMedicine.stock} ${selectedMedicine.unit}`}
          maxWidth="md"
        >
          <form onSubmit={handleSubmitStockAdjustment} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Add Units to Stock (+/-)
              </label>
              <input
                type="number"
                required
                value={stockAdjustment}
                onChange={(e) => setStockAdjustment(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:border-teal-500 focus:outline-none font-bold text-sm"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                New calculated stock will be:{' '}
                <strong className="text-teal-600">
                  {selectedMedicine.stock + Number(stockAdjustment)} {selectedMedicine.unit}
                </strong>
              </p>
            </div>

            <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsStockModalOpen(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200"
              >
                {t('common.cancel')}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs"
              >
                Apply Restock
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Confirmation */}
      {selectedMedicine && (
        <ConfirmDialog
          isOpen={isDeleteConfirmOpen}
          onClose={() => setIsDeleteConfirmOpen(false)}
          onConfirm={() => {
            deleteMedicine(selectedMedicine.id);
            addToast('Deleted', `${selectedMedicine.name} removed from inventory.`, 'warning');
          }}
          title="Remove Medicine"
          message={`Are you sure you want to remove ${selectedMedicine.name} (${selectedMedicine.batchNumber}) from inventory?`}
          confirmText="Delete"
          isDestructive={true}
        />
      )}
    </div>
  );
};

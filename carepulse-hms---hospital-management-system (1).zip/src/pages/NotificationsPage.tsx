import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  CheckCheck,
  Trash2,
  AlertCircle,
  Clock,
  ExternalLink,
  ShieldAlert,
  Calendar,
  BedDouble,
  Pill,
  Receipt,
  FlaskConical,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { useTranslation } from '../i18n/translations';

export const NotificationsPage: React.FC = () => {
  const {
    language,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearAllNotifications,
    addToast,
  } = useHospital();

  const t = useTranslation(language);
  const navigate = useNavigate();

  const [filter, setFilter] = useState<'All' | 'Unread' | 'Emergency' | 'Billing' | 'Pharmacy' | 'Bed'>('All');

  const filteredNotifications = notifications.filter((n) => {
    if (filter === 'Unread') return !n.read;
    if (filter === 'Emergency') return n.type === 'emergency' || n.severity === 'danger';
    if (filter === 'Billing') return n.title.toLowerCase().includes('bill') || n.title.toLowerCase().includes('payment');
    if (filter === 'Pharmacy') return n.title.toLowerCase().includes('stock') || n.title.toLowerCase().includes('medicine');
    if (filter === 'Bed') return n.title.toLowerCase().includes('bed') || n.title.toLowerCase().includes('icu');
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleNotificationClick = (n: typeof notifications[0]) => {
    if (!n.read) markNotificationAsRead(n.id);
    if (n.link) navigate(n.link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            {t('notif.title')}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {unreadCount} unread clinical alerts and operational updates
          </p>
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={() => {
                markAllNotificationsAsRead();
                addToast('All Read', 'Marked all notifications as read.', 'info');
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 hover:bg-teal-100 rounded-xl text-xs font-bold transition-colors"
            >
              <CheckCheck className="w-4 h-4" />
              <span>{t('notif.mark_all_read')}</span>
            </button>
          )}

          {notifications.length > 0 && (
            <button
              onClick={() => {
                clearAllNotifications();
                addToast('Cleared', 'All notifications cleared.', 'info');
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-600 rounded-xl text-xs font-bold transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t('notif.clear_all')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 p-1 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-x-auto">
        {['All', 'Unread', 'Emergency', 'Billing', 'Pharmacy', 'Bed'].map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab as any)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              filter === tab
                ? 'bg-teal-600 text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              {t('notif.no_notifications')}
            </h3>
            <p className="text-xs text-slate-400 mt-1">You are all caught up on hospital events.</p>
          </div>
        ) : (
          filteredNotifications.map((item) => (
            <div
              key={item.id}
              onClick={() => handleNotificationClick(item)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                item.read
                  ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-teal-500/50'
                  : 'bg-teal-50/40 dark:bg-teal-950/20 border-teal-200 dark:border-teal-900/60 shadow-xs hover:border-teal-500'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-white font-bold text-xs ${
                  item.severity === 'danger' || item.type === 'emergency'
                    ? 'bg-rose-500'
                    : item.severity === 'warning'
                    ? 'bg-amber-500'
                    : item.severity === 'success'
                    ? 'bg-emerald-500'
                    : 'bg-teal-600'
                }`}
              >
                {item.severity === 'danger' || item.type === 'emergency' ? (
                  <ShieldAlert className="w-4 h-4" />
                ) : (
                  <Bell className="w-4 h-4" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {item.title}
                  </h4>
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 shrink-0">
                    <Clock className="w-3 h-3" />
                    {item.time}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {item.message}
                </p>

                {item.link && (
                  <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-teal-600 dark:text-teal-400">
                    <span>View details</span>
                    <ExternalLink className="w-3 h-3" />
                  </div>
                )}
              </div>

              {!item.read && (
                <span className="w-2.5 h-2.5 rounded-full bg-teal-600 shrink-0 self-center" />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

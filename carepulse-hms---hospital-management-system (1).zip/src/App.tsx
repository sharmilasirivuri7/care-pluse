import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { HospitalProvider, useHospital } from './context/HospitalContext';

// Common Components
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { ToastContainer } from './components/common/ToastContainer';
import { VoiceAssistantModal } from './components/ai/VoiceAssistantModal';
import { ChatbotDrawer } from './components/ai/ChatbotDrawer';

// Pages
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { PatientsPage } from './pages/PatientsPage';
import { DoctorsPage } from './pages/DoctorsPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { DepartmentsPage } from './pages/DepartmentsPage';
import { AdmissionsPage } from './pages/AdmissionsPage';
import { BedManagementPage } from './pages/BedManagementPage';
import { BillingPage } from './pages/BillingPage';
import { PharmacyPage } from './pages/PharmacyPage';
import { LaboratoryPage } from './pages/LaboratoryPage';
import { MedicalRecordsPage } from './pages/MedicalRecordsPage';
import { PrescriptionsPage } from './pages/PrescriptionsPage';
import { StaffPage } from './pages/StaffPage';
import { ReportsPage } from './pages/ReportsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { SettingsPage } from './pages/SettingsPage';

// Main App Layout Wrapper
const AppLayout: React.FC = () => {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login';

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  if (isLoginPage) {
    return (
      <>
        <ToastContainer />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Toast Notification Container */}
      <ToastContainer />

      {/* Main Header */}
      <Header
        onOpenSidebar={() => setSidebarOpen(true)}
        onOpenVoice={() => setIsVoiceModalOpen(true)}
        onOpenChat={() => setIsChatbotOpen(true)}
      />

      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Sidebar Navigation */}
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/patients" element={<PatientsPage />} />
            <Route path="/doctors" element={<DoctorsPage />} />
            <Route path="/appointments" element={<AppointmentsPage />} />
            <Route path="/departments" element={<DepartmentsPage />} />
            <Route path="/admissions" element={<AdmissionsPage />} />
            <Route path="/beds" element={<BedManagementPage />} />
            <Route path="/billing" element={<BillingPage />} />
            <Route path="/pharmacy" element={<PharmacyPage />} />
            <Route path="/laboratory" element={<LaboratoryPage />} />
            <Route path="/records" element={<MedicalRecordsPage />} />
            <Route path="/prescriptions" element={<PrescriptionsPage />} />
            <Route path="/staff" element={<StaffPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/notifications" element={<NotificationsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>

      {/* AI Modals */}
      <VoiceAssistantModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
      />

      <ChatbotDrawer
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        onOpenVoice={() => setIsVoiceModalOpen(true)}
      />
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <HospitalProvider>
        <AppLayout />
      </HospitalProvider>
    </Router>
  );
}

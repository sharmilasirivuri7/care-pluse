import { Language, Patient, Doctor, Appointment, Bed, Invoice, Medicine, LabTest } from '../types';

export interface ProcessedAIResponse {
  spokenText: string;
  displayText: string;
  suggestedRoute?: string;
  dataPayload?: any;
  actionType?: string;
  isConfirmation?: boolean;
  detectedLang?: Language;
  pendingAction?: {
    actionType: 'delete_patient' | 'delete_doctor' | 'delete_medicine' | 'cancel_appointment' | 'discharge_patient' | 'delete_invoice';
    targetId: string;
    targetName: string;
    description: string;
  };
  quickSuggestions?: { label: string; query: string }[];
}

export interface HospitalDataContext {
  patients: Patient[];
  doctors: Doctor[];
  appointments: Appointment[];
  beds: Bed[];
  invoices: Invoice[];
  medicines: Medicine[];
  labTests: LabTest[];
}

/**
 * Auto-detect user language from input text (Telugu, Hindi, English, or Mixed Telugu/Hindi)
 */
export function detectLanguage(text: string, defaultLang: Language): Language {
  const teluguScript = /[\u0C00-\u0C7F]/;
  const hindiScript = /[\u0900-\u097F]/;

  if (teluguScript.test(text)) return 'te';
  if (hindiScript.test(text)) return 'hi';

  const lower = text.toLowerCase();
  
  // Common transliterated Telugu words in mixed queries (e.g., "Today appointments enni unnayi?")
  const teluguKeywords = [
    'enni', 'unnayi', 'unnam', 'evaru', 'doktar', 'doktarlu', 'namaskaram',
    'roju', 'ivvala', 'ippudu', 'yevaru', 'pediyatriks', 'pariiksha', 'billu',
    'khali', 'kavali', 'chupinchu', 'cheppu', 'unara', 'vundhi', 'undhi', 'pedatamu'
  ];
  
  // Common transliterated Hindi words in mixed queries (e.g., "Rahul patient record dikhao")
  const hindiKeywords = [
    'kitne', 'dikhao', 'batao', 'aaj', 'kaun', 'doctoron', 'dawa', 'mante',
    'chahiye', 'kaise', 'kaha', 'namaste', 'hai', 'hain', 'mery', 'mujhe',
    'bol', 'karo', 'meri', 'kab'
  ];

  let teScore = 0;
  let hiScore = 0;

  for (const kw of teluguKeywords) {
    if (lower.includes(kw)) teScore += 1;
  }
  for (const kw of hindiKeywords) {
    if (lower.includes(kw)) hiScore += 1;
  }

  if (teScore > hiScore && teScore > 0) return 'te';
  if (hiScore > teScore && hiScore > 0) return 'hi';

  return defaultLang;
}

export function processHospitalQuery(
  rawQuery: string,
  userSelectedLang: Language,
  data: HospitalDataContext
): ProcessedAIResponse {
  const query = rawQuery.trim().toLowerCase();
  const lang = detectLanguage(rawQuery, userSelectedLang);

  // Helper selectors
  const getBedsAvailable = () => data.beds.filter((b) => b.status === 'Available');
  const getOccupiedBeds = () => data.beds.filter((b) => b.status === 'Occupied');
  const getTodayAppts = () => {
    const today = new Date().toISOString().split('T')[0];
    return data.appointments.filter((a) => a.date === today || a.date === '2026-08-27');
  };
  const getPendingInvoices = () => data.invoices.filter((inv) => inv.status === 'Pending' || inv.status === 'Partially Paid');
  const getLowStockMeds = () => data.medicines.filter((m) => (m.stockQuantity ?? m.stock ?? 0) <= (m.minThreshold ?? m.reorderLevel ?? 20));

  // 1. SYMPTOM GUIDANCE AND DEPARTMENT ADVICE
  if (
    query.includes('symptom') || query.includes('fever') || query.includes('headache') ||
    query.includes('chest pain') || query.includes('cough') || query.includes('stomach') ||
    query.includes('జ్వరం') || query.includes('తలనొప్పి') || query.includes('గుండె నొప్పి') ||
    query.includes('దగ్గు') || query.includes('కడుపునొప్పి') || query.includes('సమస్య') ||
    query.includes('बुखार') || query.includes('सिरदर्द') || query.includes('सीने में दर्द') ||
    query.includes('खांसी') || query.includes('पेट दर्द') || query.includes('तकलीफ')
  ) {
    let deptSuggestion = 'General Medicine';
    let urgency = 'Standard Consultation';

    if (query.includes('chest pain') || query.includes('గుండె') || query.includes('सीने')) {
      deptSuggestion = 'Cardiology & Emergency Ward';
      urgency = 'IMMEDIATE EMERGENCY CARE REQUIRED';
    } else if (query.includes('headache') || query.includes('తలనొప్పి') || query.includes('सिरदर्द')) {
      deptSuggestion = 'Neurology / General Medicine';
    } else if (query.includes('stomach') || query.includes('కడుపు') || query.includes('पेट')) {
      deptSuggestion = 'Gastroenterology';
    }

    if (lang === 'te') {
      return {
        spokenText: `మీ లక్షణాల ఆధారంగా, మీరు ${deptSuggestion} విభాగాన్ని సంప్రదించాల్సిందిగా సూచిస్తున్నాము. ఇది ప్రాథమిక సూచన మాత్రమే, దయచేసి డాక్టర్‌ను నేరుగా సంప్రదించండి.`,
        displayText: `🩺 **లక్షణాల మార్గదర్శకం (Symptom Guidance)**\n\n- 🏥 **సిఫార్సు చేసిన విభాగం**: **${deptSuggestion}**\n- ⚠️ **అత్యవసర స్థాయి**: ${urgency}\n\n*గమనిక: ఇది కేవలం సమాచారం మాత్రమే. ఖచ్చితమైన రోగ నిర్ధారణ కోసం మా నిపుణులైన డాక్టర్లను సంప్రదించండి.*\n\nమీరు వెంటనే అపాయింట్‌మెంట్ బుక్ చేసుకోవాలనుకుంటున్నారా?`,
        suggestedRoute: '/doctors',
        detectedLang: lang,
        quickSuggestions: [
          { label: 'డాక్టర్ అపాయింట్‌మెంట్ బుక్ చేయండి', query: 'book appointment' },
          { label: 'అందుబాటులో ఉన్న డాక్టర్లు', query: 'show available doctors' }
        ]
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `आपके लक्षणों के आधार पर, हम आपको ${deptSuggestion} विभाग से परामर्श करने की सलाह देते हैं। यह केवल प्राथमिक मार्गदर्शन है।`,
        displayText: `🩺 **लक्षण मार्गदर्शन (Symptom Guidance)**\n\n- 🏥 **अनुशंसित विभाग**: **${deptSuggestion}**\n- ⚠️ **आपातकालीन स्थिति**: ${urgency}\n\n*नोट: यह केवल प्राथमिक सलाह है। सटीक निदान के लिए हमारे विशेषज्ञ डॉक्टरों से परामर्श लें।*\n\nक्या आप डॉक्टर से परामर्श बुक करना चाहते हैं?`,
        suggestedRoute: '/doctors',
        detectedLang: lang,
        quickSuggestions: [
          { label: 'डॉक्टर अपॉइंटमेंट बुक करें', query: 'book appointment' },
          { label: 'उपलब्ध डॉक्टर्स देखें', query: 'show available doctors' }
        ]
      };
    } else {
      return {
        spokenText: `Based on your symptoms, we recommend consulting the ${deptSuggestion} department. Please visit a doctor for confirmation.`,
        displayText: `🩺 **Symptom Guidance & Department Recommendation**\n\n- 🏥 **Recommended Department**: **${deptSuggestion}**\n- ⚠️ **Care Level**: ${urgency}\n\n*Note: This is automated general guidance. Please consult a medical professional for clinical diagnosis.*\n\nWould you like to check doctor availability or schedule a consultation?`,
        suggestedRoute: '/doctors',
        detectedLang: lang,
        quickSuggestions: [
          { label: 'Book Doctor Appointment', query: 'book appointment' },
          { label: 'Show Available Doctors', query: 'show available doctors' }
        ]
      };
    }
  }

  // 2. DANGEROUS ACTION: DELETE PATIENT CONFIRMATION
  if (
    query.includes('delete patient') ||
    query.includes('remove patient') ||
    query.includes('పేషెంట్ని తొలగించు') ||
    query.includes('పేషెంట్‌ను డిలీట్') ||
    query.includes('మరీజ్ కో హటాఓ') ||
    query.includes('मरीज़ को हटाओ') ||
    query.includes('मरीज को डिलीट')
  ) {
    const foundPatient = data.patients.find((p) =>
      query.includes(p.name.toLowerCase()) || query.includes(p.patientId.toLowerCase())
    ) || data.patients[0];

    if (foundPatient) {
      if (lang === 'te') {
        return {
          spokenText: `నేను పేషెంట్ ${foundPatient.name} ను కనుగొన్నాను. మీరు ఖచ్చితంగా ఈ పేషెంట్ రికార్డును తొలగించాలనుకుంటున్నారా?`,
          displayText: `నేను పేషెంట్ **${foundPatient.name} (${foundPatient.patientId})** ను గుర్తించాను. మీరు ఖచ్చితంగా ఈ రికార్డును తొలగించాలనుకుంటున్నారా?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'delete_patient',
            targetId: foundPatient.id,
            targetName: foundPatient.name,
            description: `Delete patient record for ${foundPatient.name} (${foundPatient.patientId})`,
          },
        };
      } else if (lang === 'hi') {
        return {
          spokenText: `मुझे मरीज़ ${foundPatient.name} मिला। क्या आप वाकई इस मरीज़ का रिकॉर्ड हटाना चाहते हैं?`,
          displayText: `मुझे मरीज़ **${foundPatient.name} (${foundPatient.patientId})** मिला। क्या आप वाकई इस रिकॉर्ड को हटाना चाहते हैं?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'delete_patient',
            targetId: foundPatient.id,
            targetName: foundPatient.name,
            description: `Delete patient record for ${foundPatient.name} (${foundPatient.patientId})`,
          },
        };
      } else {
        return {
          spokenText: `I found patient ${foundPatient.name}. Are you sure you want to delete this patient record?`,
          displayText: `I found patient **${foundPatient.name} (${foundPatient.patientId})**. Are you sure you want to delete this patient record?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'delete_patient',
            targetId: foundPatient.id,
            targetName: foundPatient.name,
            description: `Delete patient record for ${foundPatient.name} (${foundPatient.patientId})`,
          },
        };
      }
    }
  }

  // 3. DANGEROUS ACTION: CANCEL APPOINTMENT
  if (
    query.includes('cancel appointment') ||
    query.includes('అపాయింట్మెంట్ రద్దు') ||
    query.includes('अपॉइंटमेंट रद्द')
  ) {
    const targetAppt = data.appointments.find((a) => a.status !== 'Cancelled') || data.appointments[0];
    if (targetAppt) {
      if (lang === 'te') {
        return {
          spokenText: `అపాయింట్మెంట్ ${targetAppt.appointmentId} రద్దు చేయాలా? నిర్ధారించండి.`,
          displayText: `అపాయింట్మెంట్ **${targetAppt.appointmentId}** (${targetAppt.patientName} తో డాక్టర్ ${targetAppt.doctorName}) రద్దు చేయాలనుకుంటున్నారా?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'cancel_appointment',
            targetId: targetAppt.id,
            targetName: `${targetAppt.patientName} - ${targetAppt.doctorName}`,
            description: `Cancel appointment ${targetAppt.appointmentId}`,
          },
        };
      } else if (lang === 'hi') {
        return {
          spokenText: `क्या आप अपॉइंटमेंट ${targetAppt.appointmentId} को रद्द करना चाहते हैं? पुष्टि करें।`,
          displayText: `क्या आप **${targetAppt.appointmentId}** (${targetAppt.patientName} - ${targetAppt.doctorName}) को रद्द करना चाहते हैं?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'cancel_appointment',
            targetId: targetAppt.id,
            targetName: `${targetAppt.patientName} - ${targetAppt.doctorName}`,
            description: `Cancel appointment ${targetAppt.appointmentId}`,
          },
        };
      } else {
        return {
          spokenText: `Are you sure you want to cancel appointment ${targetAppt.appointmentId} for ${targetAppt.patientName}?`,
          displayText: `Are you sure you want to cancel appointment **${targetAppt.appointmentId}** for **${targetAppt.patientName}** with ${targetAppt.doctorName}?`,
          isConfirmation: true,
          detectedLang: lang,
          pendingAction: {
            actionType: 'cancel_appointment',
            targetId: targetAppt.id,
            targetName: `${targetAppt.patientName} - ${targetAppt.doctorName}`,
            description: `Cancel appointment ${targetAppt.appointmentId}`,
          },
        };
      }
    }
  }

  // 4. AVAILABLE BEDS / BED OCCUPANCY
  if (
    query.includes('bed') ||
    query.includes('బెడ్') ||
    query.includes('ఖాళీగా') ||
    query.includes('బడ్లు') ||
    query.includes('बेड') ||
    query.includes('कितने बेड') ||
    query.includes('खाली')
  ) {
    const available = getBedsAvailable();
    const count = available.length;
    const icuCount = available.filter((b) => b.type === 'ICU').length;
    const genCount = available.filter((b) => b.type === 'General').length;

    if (lang === 'te') {
      return {
        spokenText: `ప్రస్తుతం ఆసుపత్రిలో ${count} బెడ్లు అందుబాటులో ఉన్నాయి. ఇందులో ${icuCount} ఐసీయూ బెడ్లు మరియు ${genCount} జనరల్ వార్డు బెడ్లు ఉన్నాయి.`,
        displayText: `ప్రస్తుతం **${count} బెడ్లు అందుబాటులో ఉన్నాయి**:\n- 🏥 **ICU బెడ్లు**: ${icuCount} అందుబాటులో ఉన్నాయి\n- 🛏️ **జనరల్ వార్డు**: ${genCount} అందుబాటులో ఉన్నాయి\n- 📊 **మొత్తం ఆక్యుపెన్సీ**: ${getOccupiedBeds().length}/${data.beds.length} బెడ్లు వినియోగంలో ఉన్నాయి.`,
        suggestedRoute: '/beds',
        dataPayload: available,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'బెడ్ మేనేజ్‌మెంట్ చూడండి', query: 'open bed management' },
          { label: 'పేషెంట్‌ను అడ్మిట్ చేయండి', query: 'admit patient' },
        ],
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `वर्तमान में अस्पताल में ${count} बेड उपलब्ध हैं। इनमें ${icuCount} आईसीयू और ${genCount} जनरल बेड शामिल हैं।`,
        displayText: `वर्तमान में **${count} बेड उपलब्ध हैं**:\n- 🏥 **ICU बेड्स**: ${icuCount} उपलब्ध\n- 🛏️ **जनरल वार्ड**: ${genCount} उपलब्ध\n- 📊 **कुल ऑक्यूपेंसी**: ${getOccupiedBeds().length}/${data.beds.length} बेड भरे हुए हैं।`,
        suggestedRoute: '/beds',
        dataPayload: available,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'बेड प्रबंधन देखें', query: 'open bed management' },
          { label: 'मरीज़ भर्ती करें', query: 'admit patient' },
        ],
      };
    } else {
      return {
        spokenText: `${count} beds are currently available in the hospital.`,
        displayText: `**${count} beds are currently available** across all wards:\n- 🏥 **ICU Units**: ${icuCount} available\n- 🛏️ **General Wards**: ${genCount} available\n- 📊 **Total Hospital Occupancy**: ${getOccupiedBeds().length}/${data.beds.length} active beds.`,
        suggestedRoute: '/beds',
        dataPayload: available,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'View Bed Grid', query: 'open bed management' },
          { label: 'Admit Patient', query: 'open admissions' },
        ],
      };
    }
  }

  // 5. TODAY'S APPOINTMENTS / APPOINTMENTS (INCLUDING MIXED QUERIES like "Today appointments enni unnayi?")
  if (
    query.includes('appointment') ||
    query.includes('అపాయింట్మెంట్') ||
    query.includes('అపాయింట్‌మెంట్') ||
    query.includes('ఈరోజు') ||
    query.includes('अपॉइंटमेंट') ||
    query.includes('आज की') ||
    query.includes('enni') ||
    query.includes('unnayi')
  ) {
    const todayAppts = getTodayAppts();
    const count = todayAppts.length;

    if (lang === 'te') {
      return {
        spokenText: `ఈరోజు మొత్తం ${count} అపాయింట్‌మెంట్లు షెడ్యూల్ చేయబడ్డాయి.`,
        displayText: `ఈరోజు **${count} అపాయింట్‌మెంట్లు** షెడ్యూల్ చేయబడ్డాయి:\n${todayAppts.map((a) => `• 🕒 **${a.time}** — ${a.patientName} (${a.department} - ${a.doctorName}) [${a.status}]`).join('\n')}`,
        suggestedRoute: '/appointments',
        dataPayload: todayAppts,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'అపాయింట్‌మెంట్స్ చూడండి', query: 'open appointments' },
          { label: 'కొత్త అపాయింట్‌మెంట్ బుక్ చేయండి', query: 'book appointment' },
        ],
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `आज कुल ${count} अपॉइंटमेंट्स निर्धारित हैं।`,
        displayText: `आज कुल **${count} अपॉइंटमेंट्स** निर्धारित हैं:\n${todayAppts.map((a) => `• 🕒 **${a.time}** — ${a.patientName} (${a.department} - ${a.doctorName}) [${a.status}]`).join('\n')}`,
        suggestedRoute: '/appointments',
        dataPayload: todayAppts,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'अपॉइंटमेंट्स देखें', query: 'open appointments' },
          { label: 'नई अपॉइंटमेंट बुक करें', query: 'book appointment' },
        ],
      };
    } else {
      return {
        spokenText: `There are ${count} appointments scheduled for today.`,
        displayText: `There are **${count} appointments scheduled for today**:\n${todayAppts.map((a) => `• 🕒 **${a.time}** — ${a.patientName} with ${a.doctorName} (${a.department}) — *Status: ${a.status}*`).join('\n')}`,
        suggestedRoute: '/appointments',
        dataPayload: todayAppts,
        detectedLang: lang,
        quickSuggestions: [
          { label: 'Go to Appointments', query: 'open appointments' },
          { label: 'Book New Appointment', query: 'book appointment' },
        ],
      };
    }
  }

  // 6. FIND PATIENT BY NAME / ID
  for (const patient of data.patients) {
    const pName = patient.name.toLowerCase();
    const pFirst = pName.split(' ')[0];
    if (query.includes(pFirst) || query.includes(pName) || query.includes(patient.patientId.toLowerCase())) {
      const emergencyStr = typeof patient.emergencyContact === 'object' && patient.emergencyContact !== null
        ? `${patient.emergencyContact.name} (${patient.emergencyContact.phone})`
        : (patient.emergencyPhone || patient.phone);

      if (lang === 'te') {
        return {
          spokenText: `నేను పేషెంట్ ${patient.name} రికార్డును కనుగొన్నాను. విభాగం ${patient.department}, స్థితి ${patient.status}.`,
          displayText: `📋 **పేషెంట్ వివరాలు: ${patient.name} (${patient.patientId})**\n- 👤 **వయస్సు / లింగం**: ${patient.age} సం. / ${patient.gender}\n- 🩸 **రక్త గ్రూపు**: ${patient.bloodGroup}\n- 🩺 **విభాగం**: ${patient.department}\n- 👨‍⚕️ **డాక్టర్**: ${patient.assignedDoctorName || 'Not assigned'}\n- 🏥 **స్థితి**: ${patient.status}\n- 📞 **ఫోన్**: ${patient.phone}\n- 🚨 **అత్యవసర కాంటాక్ట్**: ${emergencyStr}\n- ⚠️ **అలెర్జీలు**: ${patient.allergies.join(', ') || 'None'}`,
          suggestedRoute: `/patients?search=${encodeURIComponent(patient.name)}`,
          dataPayload: patient,
          detectedLang: lang,
        };
      } else if (lang === 'hi') {
        return {
          spokenText: `मुझे मरीज़ ${patient.name} का रिकॉर्ड मिला। विभाग ${patient.department}, स्थिति ${patient.status} है।`,
          displayText: `📋 **मरीज़ विवरण: ${patient.name} (${patient.patientId})**\n- 👤 **आयु / लिंग**: ${patient.age} वर्ष / ${patient.gender}\n- 🩸 **ब्लड ग्रुप**: ${patient.bloodGroup}\n- 🩺 **विभाग**: ${patient.department}\n- 👨‍⚕️ **डॉक्टर**: ${patient.assignedDoctorName || 'Not assigned'}\n- 🏥 **स्थिति**: ${patient.status}\n- 📞 **फ़ोन**: ${patient.phone}\n- 🚨 **इमरजेंसी संपर्क**: ${emergencyStr}\n- ⚠️ **एलर्जी**: ${patient.allergies.join(', ') || 'None'}`,
          suggestedRoute: `/patients?search=${encodeURIComponent(patient.name)}`,
          dataPayload: patient,
          detectedLang: lang,
        };
      } else {
        return {
          spokenText: `I found patient ${patient.name}. Status is ${patient.status} in ${patient.department}.`,
          displayText: `📋 **Patient Record: ${patient.name} (${patient.patientId})**\n- 👤 **Age / Gender**: ${patient.age} yrs / ${patient.gender}\n- 🩸 **Blood Group**: ${patient.bloodGroup}\n- 🩺 **Department**: ${patient.department}\n- 👨‍⚕️ **Assigned Doctor**: ${patient.assignedDoctorName || 'Unassigned'}\n- 🏥 **Status**: ${patient.status}\n- 📞 **Phone**: ${patient.phone}\n- 🚨 **Emergency Contact**: ${emergencyStr}\n- ⚠️ **Allergies**: ${patient.allergies.join(', ') || 'None recorded'}`,
          suggestedRoute: `/patients?search=${encodeURIComponent(patient.name)}`,
          dataPayload: patient,
          detectedLang: lang,
        };
      }
    }
  }

  // 7. DOCTORS / SPECIALTY FINDER
  if (
    query.includes('doctor') ||
    query.includes('డాక్టర్') ||
    query.includes('డాక్టర్లు') ||
    query.includes('डॉक्टर') ||
    query.includes('cardiolog') ||
    query.includes('neurolog') ||
    query.includes('pediatric') ||
    query.includes('orthoped') ||
    query.includes('evaru') ||
    query.includes('kaun')
  ) {
    let filteredDoctors = data.doctors;
    if (query.includes('cardio')) filteredDoctors = data.doctors.filter((d) => d.department.toLowerCase().includes('cardio'));
    if (query.includes('neuro')) filteredDoctors = data.doctors.filter((d) => d.department.toLowerCase().includes('neuro'));
    if (query.includes('pediatric')) filteredDoctors = data.doctors.filter((d) => d.department.toLowerCase().includes('pediatric'));
    if (query.includes('ortho')) filteredDoctors = data.doctors.filter((d) => d.department.toLowerCase().includes('ortho'));

    const availableCount = filteredDoctors.filter((d) => d.availability === 'Available').length;

    if (lang === 'te') {
      return {
        spokenText: `${availableCount} మంది డాక్టర్లు ప్రస్తుతం అందుబాటులో ఉన్నారు.`,
        displayText: `👨‍⚕️ **వైద్యుల జాబితా (${filteredDoctors.length} మంది డాక్టర్లు):**\n${filteredDoctors.map((d) => `• **${d.name}** — ${d.specialization} (${d.department}) | ఫీజు: ₹${d.consultationFee} | స్థితి: *${d.availability}*`).join('\n')}`,
        suggestedRoute: '/doctors',
        dataPayload: filteredDoctors,
        detectedLang: lang,
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `${availableCount} डॉक्टर्स वर्तमान में उपलब्ध हैं।`,
        displayText: `👨‍⚕️ **डॉक्टर्स की सूची (${filteredDoctors.length} डॉक्टर्स):**\n${filteredDoctors.map((d) => `• **${d.name}** — ${d.specialization} (${d.department}) | फ़ीस: ₹${d.consultationFee} | स्थिति: *${d.availability}*`).join('\n')}`,
        suggestedRoute: '/doctors',
        dataPayload: filteredDoctors,
        detectedLang: lang,
      };
    } else {
      return {
        spokenText: `${availableCount} doctors are currently available for consultation.`,
        displayText: `👨‍⚕️ **Doctors Information (${filteredDoctors.length} specialist doctors):**\n${filteredDoctors.map((d) => `• **${d.name}** — ${d.specialization} (${d.department}) | Room: ${d.roomNumber} | Fee: ₹${d.consultationFee} | *Status: ${d.availability}*`).join('\n')}`,
        suggestedRoute: '/doctors',
        dataPayload: filteredDoctors,
        detectedLang: lang,
      };
    }
  }

  // 8. PENDING BILLS / BILLING
  if (
    query.includes('bill') ||
    query.includes('invoice') ||
    query.includes('pending') ||
    query.includes('బిల్లు') ||
    query.includes('పెండింగ్') ||
    query.includes('बिल') ||
    query.includes('पेंडिंग')
  ) {
    const pending = getPendingInvoices();
    const totalRemaining = pending.reduce((sum, inv) => sum + inv.remainingAmount, 0);

    if (lang === 'te') {
      return {
        spokenText: `మొత్తం ${pending.length} పెండింగ్ బిల్లులు ఉన్నాయి. మొత్తం బకాయి ₹${totalRemaining.toLocaleString()} రూపాయలు.`,
        displayText: `💳 **పెండింగ్ బిల్లుల సారాంశం:**\n- 📑 **పెండింగ్ ఇన్వాయిస్‌లు**: ${pending.length}\n- 💰 **మొత్తం బకాయి మొత్తం**: ₹${totalRemaining.toLocaleString()}\n${pending.map((i) => `• ${i.invoiceId}: ${i.patientName} — బకాయి: ₹${i.remainingAmount.toLocaleString()} [${i.status}]`).join('\n')}`,
        suggestedRoute: '/billing?filter=Pending',
        dataPayload: pending,
        detectedLang: lang,
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `कुल ${pending.length} पेंडिंग बिल हैं। कुल बकाया राशि ₹${totalRemaining.toLocaleString()} है।`,
        displayText: `💳 **पेंडिंग बिल का विवरण:**\n- 📑 **पेंडिंग इनवॉइस**: ${pending.length}\n- 💰 **कुल बकाया राशि**: ₹${totalRemaining.toLocaleString()}\n${pending.map((i) => `• ${i.invoiceId}: ${i.patientName} — बकाया: ₹${i.remainingAmount.toLocaleString()} [${i.status}]`).join('\n')}`,
        suggestedRoute: '/billing?filter=Pending',
        dataPayload: pending,
        detectedLang: lang,
      };
    } else {
      return {
        spokenText: `There are ${pending.length} pending invoices totaling ₹${totalRemaining.toLocaleString()}.`,
        displayText: `💳 **Pending Bills Overview:**\n- 📑 **Pending Invoices**: ${pending.length}\n- 💰 **Total Outstanding Amount**: ₹${totalRemaining.toLocaleString()}\n${pending.map((i) => `• **${i.invoiceId}** (${i.patientName}) — Due: ₹${i.remainingAmount.toLocaleString()} | Status: ${i.status}`).join('\n')}`,
        suggestedRoute: '/billing?filter=Pending',
        dataPayload: pending,
        detectedLang: lang,
      };
    }
  }

  // 9. PHARMACY / MEDICINES STOCK
  if (
    query.includes('pharmacy') ||
    query.includes('medicine') ||
    query.includes('stock') ||
    query.includes('మందులు') ||
    query.includes('ఫార్మసీ') ||
    query.includes('దవా') ||
    query.includes('दवा') ||
    query.includes('फार्मेसी')
  ) {
    const lowStock = getLowStockMeds();
    const outOfStock = data.medicines.filter((m) => (m.stockQuantity ?? m.stock ?? 0) === 0);

    if (lang === 'te') {
      return {
        spokenText: `ఫార్మసీలో ${lowStock.length} మందులు తక్కువ స్టాక్‌లో ఉన్నాయి. ${outOfStock.length} మందులు నిండుకున్నాయి.`,
        displayText: `💊 **ఫార్మసీ స్టాక్ వివరాలు:**\n- ⚠️ **తక్కువ స్టాక్ ఉన్నవి**: ${lowStock.length} మందులు\n- 🚫 **పూర్తిగా అయిపోయినవి**: ${outOfStock.length} మందులు\n${lowStock.map((m) => `• **${m.name}**: మిగిలిన స్టాక్: ${m.stockQuantity ?? m.stock ?? 0} (కనీస పరిమితి: ${m.minThreshold ?? m.reorderLevel ?? 20})`).join('\n')}`,
        suggestedRoute: '/pharmacy',
        detectedLang: lang,
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `फार्मेसी में ${lowStock.length} दवाएं कम स्टॉक में हैं।`,
        displayText: `💊 **फार्मेसी स्टॉक चेतावनी:**\n- ⚠️ **कम स्टॉक वाली दवाएं**: ${lowStock.length}\n- 🚫 **स्टॉक खत्म**: ${outOfStock.length}\n${lowStock.map((m) => `• **${m.name}**: शेष स्टॉक: ${m.stockQuantity ?? m.stock ?? 0} (न्यूनतम सीमा: ${m.minThreshold ?? m.reorderLevel ?? 20})`).join('\n')}`,
        suggestedRoute: '/pharmacy',
        detectedLang: lang,
      };
    } else {
      return {
        spokenText: `Pharmacy alert: ${lowStock.length} medicines are running low in stock.`,
        displayText: `💊 **Pharmacy Inventory Status:**\n- ⚠️ **Low Stock Alert**: ${lowStock.length} items require re-order\n- 🚫 **Out of Stock**: ${outOfStock.length} item(s)\n${lowStock.map((m) => `• **${m.name}**: Current Stock: ${m.stockQuantity ?? m.stock ?? 0} units (Min: ${m.minThreshold ?? m.reorderLevel ?? 20})`).join('\n')}`,
        suggestedRoute: '/pharmacy',
        detectedLang: lang,
      };
    }
  }

  // 10. LABORATORY & DIAGNOSTIC REPORTS
  if (
    query.includes('lab') ||
    query.includes('test') ||
    query.includes('ల్యాబ్') ||
    query.includes('పరీక్ష') ||
    query.includes('ల్యాబొరేటరీ') ||
    query.includes('लैब') ||
    query.includes('परीक्षण')
  ) {
    const completed = data.labTests.filter((t) => t.status === 'Completed').length;
    const pending = data.labTests.filter((t) => t.status !== 'Completed').length;

    if (lang === 'te') {
      return {
        spokenText: `ల్యాబ్‌లో ${data.labTests.length} పరీక్షలు నమోదు చేయబడ్డాయి. ${completed} పరీక్షలు పూర్తయ్యాయి.`,
        displayText: `🧪 **ల్యాబొరేటరీ నివేదిక:**\n- ✅ **పూర్తయిన నివేదికలు**: ${completed}\n- ⏳ **ప్రాసెసింగ్‌లో ఉన్నవి**: ${pending}\n${data.labTests.map((t) => `• ${t.testId}: ${t.testName} (${t.patientName}) — [${t.status}]`).join('\n')}`,
        suggestedRoute: '/laboratory',
        detectedLang: lang,
      };
    } else if (lang === 'hi') {
      return {
        spokenText: `लैब में ${data.labTests.length} परीक्षण पंजीकृत हैं। ${completed} पूर्ण हो चुके हैं।`,
        displayText: `🧪 **प्रयोगशाला रिपोर्ट:**\n- ✅ **पूर्ण रिपोर्ट्स**: ${completed}\n- ⏳ **प्रक्रियाधीन**: ${pending}\n${data.labTests.map((t) => `• ${t.testId}: ${t.testName} (${t.patientName}) — [${t.status}]`).join('\n')}`,
        suggestedRoute: '/laboratory',
        detectedLang: lang,
      };
    } else {
      return {
        spokenText: `The laboratory has ${data.labTests.length} test records. ${completed} reports are ready.`,
        displayText: `🧪 **Diagnostic Laboratory Status:**\n- ✅ **Completed Reports**: ${completed}\n- ⏳ **In Progress / Samples**: ${pending}\n${data.labTests.map((t) => `• **${t.testId}** — ${t.testName} for ${t.patientName} (*${t.status}*)`).join('\n')}`,
        suggestedRoute: '/laboratory',
        detectedLang: lang,
      };
    }
  }

  // 11. DIRECT NAVIGATION ROUTING
  if (query.includes('patient') && (query.includes('open') || query.includes('go') || query.includes('పేజీ'))) {
    return {
      spokenText: lang === 'te' ? 'పేషెంట్ మేనేజ్‌మెంట్ పేజీ తెరవబడింది.' : lang === 'hi' ? 'मरीज़ प्रबंधन पृष्ठ खोला गया।' : 'Opening Patient Management.',
      displayText: 'Navigating to **Patient Management**...',
      suggestedRoute: '/patients',
      detectedLang: lang,
    };
  }

  if (query.includes('doctor') && (query.includes('open') || query.includes('go') || query.includes('పేజీ'))) {
    return {
      spokenText: lang === 'te' ? 'డాక్టర్ల జాబితా తెరవబడింది.' : lang === 'hi' ? 'डॉक्टर सूची खोली गई।' : 'Opening Doctors Portal.',
      displayText: 'Navigating to **Doctors Management**...',
      suggestedRoute: '/doctors',
      detectedLang: lang,
    };
  }

  if (query.includes('settings') || query.includes('సెట్టింగ్‌లు') || query.includes('सेटिंग्स')) {
    return {
      spokenText: lang === 'te' ? 'సెట్టింగ్‌ల పేజీ తెరవబడింది.' : lang === 'hi' ? 'सेटिंग्स पृष्ठ खोला गया।' : 'Opening Hospital Settings.',
      displayText: 'Navigating to **Settings**...',
      suggestedRoute: '/settings',
      detectedLang: lang,
    };
  }

  // 12. GENERAL MULTILINGUAL SMART FALLBACK
  if (lang === 'te') {
    return {
      spokenText: 'నేను కేర్‌పల్స్ AI హాస్పిటల్ అసిస్టెంట్‌ని. మీరు అపాయింట్‌మెంట్లు, బెడ్ల లభ్యత, పేషెంట్ లేదా బిల్లుల గురించి అడగవచ్చు.',
      displayText: `👋 **కేర్‌పల్స్ AI హాస్పిటల్ అసిస్టెంట్‌కు స్వాగతం!** నేను ఈ క్రింది విషయాల్లో సహాయం చేయగలను:\n- 📅 *"ఈరోజు అపాయింట్మెంట్స్ చూపించు"*\n- 🛏️ *"ఎన్ని బెడ్స్ ఖాళీగా ఉన్నాయి?"*\n- 🔍 *"రాహుల్ అనే పేషెంట్ని వెతుకు"*\n- 👨‍⚕️ *"అందుబాటులో ఉన్న డాక్టర్లను చూపించు"*\n- 💳 *"పెండింగ్ బిల్లులు చూపించు"*\n- 💊 *"ఫార్మసీ మందుల స్టాక్"*\n- 🩺 *"నాకు తలనొప్పి, జ్వరం ఉంది" (లక్షణాల సలహా)*`,
      detectedLang: lang,
      quickSuggestions: [
        { label: 'ఈరోజు అపాయింట్మెంట్స్', query: 'ఈరోజు అపాయింట్మెంట్స్ చూపించు' },
        { label: 'ఖాళీగా ఉన్న బెడ్స్', query: 'ఎన్ని బెడ్స్ ఖాళీగా ఉన్నాయి?' },
        { label: 'పెండింగ్ బిల్లులు', query: 'పెండింగ్ బిల్లులు చూపించు' },
        { label: 'ఫార్మసీ స్టాక్', query: 'ఫార్మసీ మందులు' },
      ],
    };
  } else if (lang === 'hi') {
    return {
      spokenText: 'मैं केयरपल्स AI अस्पताल सहायक हूँ। आप अपॉइंटमेंट्स, खाली बेड, मरीज़ या बिलिंग के बारे में पूछ सकते हैं।',
      displayText: `👋 **केयरपल्स AI अस्पताल सहायक में आपका स्वागत है!** मैं आपकी सहायता कर सकता हूँ:\n- 📅 *"आज की अपॉइंटमेंट दिखाओ"*\n- 🛏️ *"कितने बेड खाली हैं?"*\n- 🔍 *"राहुल मरीज को खोजो"*\n- 👨‍⚕️ *"उपलब्ध डॉक्टर दिखाओ"*\n- 💳 *"पेंडिंग बिल दिखाओ"*\n- 💊 *"फार्मेसी स्टॉक देखें"*\n- 🩺 *"बुखार और सिरदर्द का मार्गदर्शन"*`,
      detectedLang: lang,
      quickSuggestions: [
        { label: 'आज की अपॉइंटमेंट्स', query: 'आज की अपॉइंटमेंट दिखाओ' },
        { label: 'उपलब्ध बेड्स', query: 'कितने बेड खाली हैं?' },
        { label: 'पेंडिंग बिल', query: 'पेंडिंग बिल दिखाओ' },
        { label: 'दवाओं का स्टॉक', query: 'फार्मेसी दवाएं' },
      ],
    };
  } else {
    return {
      spokenText: 'I can assist you with appointments, available beds, patient records, doctor availability, symptoms, and billing.',
      displayText: `👋 **Welcome to Medicover AI Hospital Assistant.** I can help you with:\n- 📅 *"Show today's appointments"*\n- 🛏️ *"How many beds are available?"*\n- 🔍 *"Find patient Rahul"*\n- 👨‍⚕️ *"Show available doctors"*\n- 💳 *"Show pending bills"*\n- 💊 *"Check pharmacy low stock"*\n- 🩺 *"I have fever and headache" (Symptom Help)*`,
      detectedLang: lang,
      quickSuggestions: [
        { label: "Today's Appointments", query: "Show today's appointments" },
        { label: 'Available Beds', query: 'How many beds are available?' },
        { label: 'Find Patient', query: 'Find patient Rahul' },
        { label: 'Available Doctors', query: 'Show available doctors' },
        { label: 'Pending Bills', query: 'Show pending bills' },
      ],
    };
  }
}

// Text to Speech Synthesizer Helper with precise language codes (en-IN, te-IN, hi-IN)
export function speakText(text: string, lang: Language): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  try {
    window.speechSynthesis.cancel(); // Stop ongoing speech
    const cleanText = text.replace(/[*_#•\-]/g, ' ').replace(/₹/g, 'Rupees ');
    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Language mapping
    if (lang === 'te') {
      utterance.lang = 'te-IN';
    } else if (lang === 'hi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    // Pick suitable voice if available
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find((v) => v.lang.startsWith(utterance.lang.slice(0, 2)));
    if (voice) {
      utterance.voice = voice;
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
